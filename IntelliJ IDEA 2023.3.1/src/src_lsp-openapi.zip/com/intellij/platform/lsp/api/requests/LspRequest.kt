// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.platform.lsp.api.requests

import com.intellij.platform.lsp.api.LspServer
import com.intellij.platform.lsp.api.LspServerDescriptor
import java.util.concurrent.CompletableFuture

/**
 * A specific [request](https://microsoft.github.io/language-server-protocol/specification/#requestMessage) that can be sent to
 * the LSP server. This class can also (optionally) preprocess the received response, i.e., translate the object received from the `lsp4j`
 * library to some other object, which is more convenient to work with.
 *
 * @param <ServerResponse> object created by the `lsp4j` library, which encapsulates the response from the LSP server
 * @param <Result> any object based on the received [ServerResponse], or simply the [ServerResponse] itself
 */
abstract class LspRequest<ServerResponse, Result>(val lspServer: LspServer) {
  override fun toString(): String = javaClass.simpleName // for logging

  /**
   * Example of the function implementation for standard requests, documented in the
   * [LSP specification](https://microsoft.github.io/language-server-protocol/specification):
   *
   *     lspServer.lsp4jServer.textDocumentService.completion(params)
   *
   * Example of the function implementation for custom undocumented requests:
   *
   *     (lspServer.lsp4jServer as FooLanguageServer).customRequest(params)
   *
   *  In this example, `FooLanguageServer` is a sub-interface of [org.eclipse.lsp4j.services.LanguageServer],
   *  as documented in [LspServerDescriptor.lsp4jServerClass].
   */
  abstract fun sendRequest(): CompletableFuture<ServerResponse>

  /**
   * Objects received from the `lsp4j` library are not always convenient to work with. So, this function can
   * optionally translate the received [ServerResponse] into any other object, which is more convenient for further usage.
   */
  abstract fun preprocessResponse(serverResponse: ServerResponse): Result
}