// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.platform.lsp.api.requests

import com.intellij.platform.lsp.api.LspServer
import com.intellij.platform.lsp.api.LspServerDescriptor

/**
 * A [notification](https://microsoft.github.io/language-server-protocol/specification/#notificationMessage) that the IDE sends
 * to the LSP server, for example, one of the
 * [text document synchronization](https://microsoft.github.io/language-server-protocol/specification/#textDocument_synchronization)
 * notifications.
 */
abstract class LspClientNotification(val lspServer: LspServer) {
  /**
   * Example of the function implementation for standard notifications, documented in the
   * [LSP specification](https://microsoft.github.io/language-server-protocol/specification):
   *
   *     lspServer.lsp4jServer.textDocumentService.didOpen(params)
   *
   * Example of the function implementation for custom undocumented notifications:
   *
   *     (lspServer.lsp4jServer as FooLanguageServer).customNotification(params)
   *
   *  In this example, `FooLanguageServer` is a sub-interface of [org.eclipse.lsp4j.services.LanguageServer],
   *  as documented in [LspServerDescriptor.lsp4jServerClass].
   */
  abstract fun sendNotification()
}