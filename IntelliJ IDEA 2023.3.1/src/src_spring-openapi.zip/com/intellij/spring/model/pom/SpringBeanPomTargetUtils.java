// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.pom;

import com.intellij.jam.JamElement;
import com.intellij.jam.JamPomTarget;
import com.intellij.pom.PomTarget;
import com.intellij.pom.PomTargetPsiElement;
import com.intellij.psi.PsiElement;
import com.intellij.psi.targets.AliasingPsiTarget;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPsiTarget;
import com.intellij.spring.model.jam.JamPsiMemberSpringBean;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.SpringJamUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.UClass;
import org.jetbrains.uast.UastContextKt;

/**
 * @author Yann C&eacute;bron
 */
public final class SpringBeanPomTargetUtils {

  private SpringBeanPomTargetUtils() {
  }

  @Nullable
  public static CommonSpringBean getSpringBean(PsiElement element) {
    if (!(element instanceof PomTargetPsiElement pomTargetPsiElement)) {
      return null;
    }

    final PomTarget target = pomTargetPsiElement.getTarget();
    if (!target.isValid()) {
      return null;
    }

    return getSpringBean(target);
  }

  @Nullable
  public static CommonSpringBean getSpringBean(@NotNull PomTarget target) {
    if (target instanceof AliasingPsiTarget) {
      final PsiElement navigationElement = ((AliasingPsiTarget)target).getNavigationElement();
      UClass uClass = UastContextKt.toUElement(navigationElement, UClass.class);
      if (uClass == null) return null;

      final SpringStereotypeElement stereotypeElement = SpringJamUtils.getInstance().findStereotypeElement(uClass.getJavaPsi());
      if (stereotypeElement != null &&
          stereotypeElement.getPsiTarget() instanceof AliasingPsiTarget) {
        return stereotypeElement;
      }

      return null;
    }

    if (target instanceof SpringBeanPsiTarget) {
      return ((SpringBeanPsiTarget)target).getSpringBean();
    }

    if (target instanceof JamPomTarget) {
      final JamElement jamElement = ((JamPomTarget)target).getJamElement();
      if (jamElement instanceof JamPsiMemberSpringBean) {
        return ((JamPsiMemberSpringBean<?>)jamElement);
      }
    }

    return null;
  }
}
