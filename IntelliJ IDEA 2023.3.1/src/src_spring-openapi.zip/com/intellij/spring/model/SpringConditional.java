// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model;

import com.intellij.jam.JamElement;
import com.intellij.jam.JamService;
import com.intellij.semantic.SemKey;

public interface SpringConditional extends JamElement {
  SemKey<SpringConditional> SPRING_CONDITIONAL_JAM_ELEMENT_KEY =
    JamService.JAM_ELEMENT_KEY.subKey("ConditionalJamElement");
}
