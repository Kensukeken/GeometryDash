// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.converters;

import com.intellij.psi.PsiClassType;
import com.intellij.util.xml.ConvertContext;
import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @author Yann C&eacute;bron
 */
public abstract class PropertyLocalSpringBeanResolveConverter extends SpringBeanResolveConverter {
  @Override
  @NotNull
  public List<PsiClassType> getRequiredClasses(ConvertContext context) {
    return getValueClasses(context);
  }
}
