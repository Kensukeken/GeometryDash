// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.converters;

import com.intellij.codeInsight.ExpectedTypeInfo;
import com.intellij.codeInsight.daemon.QuickFixBundle;
import com.intellij.codeInsight.daemon.impl.quickfix.CreateMethodFromUsageFix;
import com.intellij.codeInsight.intention.preview.IntentionPreviewInfo;
import com.intellij.codeInspection.LocalQuickFix;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.ide.highlighter.JavaFileType;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.util.PsiUtil;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class SpringCreateStaticMethodQuickFix implements LocalQuickFix {
  private final String myTargetClass;
  private final String myMethodName;

  private final List<Pair<String, String>> myTypes; // Pair<PsiType, Name>
  private final boolean myStatic;

  public SpringCreateStaticMethodQuickFix(@NotNull String aClass,
                                          @NotNull String name,
                                          @NotNull List<Pair<String, String>> types,
                                          boolean isStatic) {
    myTargetClass = aClass;
    myMethodName = name;
    myTypes = types;
    myStatic = isStatic;
  }

  @NotNull
  @Override
  public String getFamilyName() {
    return QuickFixBundle.message("create.method.from.usage.family");
  }

  @Override
  public void applyFix(@NotNull final Project project, @NotNull ProblemDescriptor descriptor) {
    final PsiClass targetClass = JavaPsiFacade.getInstance(project).findClass(myTargetClass, GlobalSearchScope.allScope(project));

    if (targetClass == null) return;

    boolean java8Interface = false;
    if (targetClass.isInterface()) {
      if (PsiUtil.isLanguageLevel8OrHigher(targetClass)) {
        java8Interface = true;
      }
      else {
        return;
      }
    }

    PsiMethod method = CreateMethodFromUsageFix.createMethod(targetClass, null, null, myMethodName);
    if (method == null) return;

    if (!java8Interface) {
      PsiUtil.setModifierProperty(method, PsiModifier.PUBLIC, true);
    }
    if (myStatic)  PsiUtil.setModifierProperty(method, PsiModifier.STATIC, true);

    List<Pair<PsiExpression, PsiType>> args =
      ContainerUtil.map(myTypes, s -> new Pair<>(null, PsiType.getTypeByName(s.first, project, GlobalSearchScope.allScope(project))));
    CreateMethodFromUsageFix.doCreate(targetClass, method, false,
                                      args,
                                      PsiSubstitutor.UNKNOWN,
                                      ExpectedTypeInfo.EMPTY_ARRAY,
                                      null);
  }

  @Override
  public @NotNull IntentionPreviewInfo generatePreview(@NotNull Project project, @NotNull ProblemDescriptor previewDescriptor) {
    return new IntentionPreviewInfo.CustomDiff(JavaFileType.INSTANCE, StringUtil.getShortName(myTargetClass), "", getMethodText());
  }

  @NotNull
  private String getMethodText() {
    StringBuilder sb = new StringBuilder();
    sb.append("public ");
    if (myStatic) sb.append("static ");
    sb.append(StringUtil.getShortName("BeanType "));
    sb.append(myMethodName);
    sb.append("(");
    boolean first = true;
    for (Pair<String, String> type : myTypes) {
      if (!first) sb.append(", ");  else first = false;
      final String typeName = type.first;
      sb.append(StringUtil.getShortName(typeName));
      sb.append(" ");
      sb.append(type.second);
    }

    sb.append(")");
    sb.append(" {\n  //TODO \n}");

    return sb.toString();
  }
}
