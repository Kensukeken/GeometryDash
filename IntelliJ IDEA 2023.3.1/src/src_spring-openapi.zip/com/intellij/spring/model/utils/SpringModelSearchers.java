// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.utils;

import com.intellij.psi.PsiClass;
import com.intellij.spring.CommonSpringModel;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.SpringModelSearchParameters;
import com.intellij.util.CommonProcessors;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

import static com.intellij.spring.contexts.model.ModelTraverse.traverseModel;

/**
 * Provides convenience methods to find or check existence of beans with specific type/name.
 * <p/>
 * All methods must be invoked under read-action.
 */
public final class SpringModelSearchers {

  @NotNull
  @SuppressWarnings("unchecked")
  public static List<SpringBeanPointer<?>> findBeans(@NotNull CommonSpringModel model,
                                                     @NotNull SpringModelSearchParameters.BeanClass parameters) {
    if (!parameters.canSearch()) {
      return Collections.emptyList();
    }

    ExplicitRedefinitionAwareBeansCollector processor = new ExplicitRedefinitionAwareBeansCollector();
    traverseModel(model, true, m -> m.traverseByClass(parameters, processor));

    return List.copyOf(processor.getResult());
  }

  public static @Nullable SpringBeanPointer<?> findBean(@NotNull CommonSpringModel model, @NotNull String beanName) {
    CommonProcessors.FindFirstProcessor<SpringBeanPointer<?>> findFirstProcessor =
      new CommonProcessors.FindFirstProcessor<>();

    SpringModelSearchParameters.BeanName parameters = SpringModelSearchParameters.byName(beanName);
    traverseModel(model, true, m -> m.traverseByName(parameters, findFirstProcessor));

    return findFirstProcessor.getFoundValue();
  }

  @NotNull
  public static Collection<SpringBeanPointer<?>> findBeans(@NotNull CommonSpringModel model, @NotNull String beanName) {
    CommonProcessors.CollectProcessor<SpringBeanPointer<?>> collectProcessor = new CommonProcessors.CollectProcessor<>();

    SpringModelSearchParameters.BeanName parameters = SpringModelSearchParameters.byName(beanName);
    traverseModel(model, true, m -> m.traverseByName(parameters, collectProcessor));

    return collectProcessor.getResults();
  }

  public static boolean doesBeanExist(@NotNull CommonSpringModel model,
                                      @NotNull SpringModelSearchParameters.BeanClass parameters) {
    return containsBean(model, parameters);
  }

  /**
   * Checks whether a bean with the given class (actual, inheritor or effective type) exists.
   * <p/>
   * NOTE: Expensive operation. Use {@link #doesBeanExist(CommonSpringModel, SpringModelSearchParameters.BeanClass)} for "plain" class
   * search.
   */
  public static boolean doesBeanExist(@NotNull CommonSpringModel model, @NotNull PsiClass beanClass) {
    return containsBean(model, SpringModelSearchParameters.byClass(beanClass).withInheritors().effectiveBeanTypes());
  }

  private static boolean containsBean(@NotNull CommonSpringModel model,
                                      @NotNull SpringModelSearchParameters.BeanClass parameters) {
    if (!parameters.canSearch()) {
      return false;
    }

    CommonProcessors.FindFirstProcessor<SpringBeanPointer<?>> findFirstProcessor =
      new CommonProcessors.FindFirstProcessor<>();

    traverseModel(model, true, m -> m.traverseByClass(parameters, findFirstProcessor));

    return findFirstProcessor.isFound();
  }
}