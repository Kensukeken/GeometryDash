package com.intellij.spring.model.utils;

import com.intellij.java.library.JavaLibraryModificationTracker;
import com.intellij.model.search.SearchContext;
import com.intellij.model.search.SearchService;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.Pair;
import com.intellij.patterns.uast.UCallExpressionPattern;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.LocalSearchScope;
import com.intellij.psi.search.SearchScope;
import com.intellij.psi.search.searches.MethodReferencesSearch;
import com.intellij.psi.util.CachedValueProvider.Result;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.uast.UastModificationTracker;
import com.intellij.util.CommonProcessors;
import com.intellij.util.Processor;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.*;

import java.util.*;
import java.util.stream.Collectors;

import static com.intellij.spring.model.utils.SpringCommonUtils.findLibraryClass;

public final class SpringFunctionalSearchersUtils {
  @NotNull
  private static Set<UCallExpression> findMethodsCalls(PsiMethod[] psiMethods, @Nullable SearchScope scope) {
    Set<UCallExpression> calls = new HashSet<>();
    for (PsiMethod method : psiMethods) {
      calls.addAll(findMethodCalls(method, scope));
    }
    return calls;
  }

  @NotNull
  public static Set<UCallExpression> findMethodCallsInModuleSearchScope(@NotNull UCallExpressionSearchParams params) {
    final Module module = params.module();
    return CachedValuesManager.getManager(module.getProject()).getCachedValue(module, () -> {
      Map<UCallExpressionSearchParams, Set<UCallExpression>> concurrentMap =
        ConcurrentFactoryMap.createMap(
          searchParams -> findMethodsCalls(findMethods(searchParams), GlobalSearchScope.moduleScope(searchParams.module())));
      return Result.create(concurrentMap,
                           UastModificationTracker.getInstance(module.getProject()),
                           JavaLibraryModificationTracker.getInstance(params.module().getProject()));
    }).get(params);
  }

  @NotNull
  public static Set<UCallExpression> findMethodCallsInLocalSearchScope(@NotNull UCallExpressionSearchParams params,
                                                                       @NotNull LocalSearchScope scope) {
    Set<UCallExpression> allCalls = new HashSet<>();
    for (PsiElement element : scope.getScope()) {
      ContainerUtil.addAllNotNull(allCalls, CachedValuesManager.getCachedValue(element, () -> {
        Map<UCallExpressionSearchParams, Set<UCallExpression>> concurrentMap =
          ConcurrentFactoryMap.createMap(searchParams -> findMethodsCalls(findMethods(searchParams), new LocalSearchScope(element)));
        return new Result<>(concurrentMap, element.getContainingFile(),
                            JavaLibraryModificationTracker.getInstance(params.module().getProject()));
      }).get(params));
    }
    return allCalls;
  }

  @NotNull
  public static Set<UCallExpression> findMethodCalls(@Nullable PsiMethod psiMethod, @Nullable SearchScope scope) {
    return findMethodCalls(psiMethod, scope, false);
  }

  @NotNull
  public static Set<UCallExpression> findMethodCalls(@Nullable PsiMethod psiMethod,
                                                     @Nullable SearchScope scope,
                                                     boolean strictSignatureSearch) {
    if (psiMethod == null || scope == null) return Collections.emptySet();
    return MethodReferencesSearch.search(psiMethod, scope, strictSignatureSearch).findAll().stream()
      .map(reference -> {
        return
          UastContextKt.getUastParentOfType(reference.getElement(), UCallExpression.class);
      })
      .filter(Objects::nonNull)
      .collect(Collectors.toSet());
  }

  @NotNull
  public static Collection<? extends UCallExpression> findMethodCallsWithSearchService(@Nullable PsiMethod psiMethod,
                                                                                       @Nullable SearchScope scope) {
    if (psiMethod == null || scope == null) return Collections.emptySet();

    return SearchService.getInstance().searchWord(psiMethod.getProject(), psiMethod.getName())
      .inContexts(SearchContext.IN_CODE)
      .inScope(scope).buildQuery(occurrence -> {
        if (occurrence.getOffsetInStart() != 0) return Collections.emptySet();
        final UCallExpression uCallExpression = UastContextKt.getUastParentOfType(occurrence.getStart(), UCallExpression.class);
        return uCallExpression != null && psiMethod.equals(uCallExpression.resolve()) ?
               Collections.singleton(uCallExpression) : Collections.emptySet();
      }).findAll();
  }

  @Nullable
  public static PsiMethod findMethod(@NotNull String name, @Nullable PsiClass psiClass) {
    if (psiClass == null) return null;
    for (PsiMethod psiMethod : psiClass.findMethodsByName(name, true)) {
      if (psiMethod != null) return psiMethod;
    }
    return null;
  }

  private static PsiMethod @NotNull [] findMethods(@NotNull UCallExpressionSearchParams uCallExpressionSearchParams) {
    if (uCallExpressionSearchParams.classname() == null) return PsiMethod.EMPTY_ARRAY;
    return findMethods(uCallExpressionSearchParams.classname(), uCallExpressionSearchParams.methodName(),
                       uCallExpressionSearchParams.module());
  }

  private static PsiMethod @NotNull [] findMethods(@Nullable String className, @NotNull String methodName, @NotNull Module module) {
    if (className == null) return PsiMethod.EMPTY_ARRAY;

    return CachedValuesManager.getManager(module.getProject()).getCachedValue(module, () -> {
      Map<Pair<String, String>, PsiMethod[]> concurrentMap =
        ConcurrentFactoryMap.createMap(searchParams -> findMethods(searchParams.second, findLibraryClass(module, searchParams.first)));
      return Result.create(concurrentMap,
                           UastModificationTracker.getInstance(module.getProject()),
                           JavaLibraryModificationTracker.getInstance(module.getProject()));
    }).get(Pair.create(className, methodName));
  }

  public static PsiMethod @NotNull [] findMethods(@NotNull String name, @Nullable PsiClass psiClass) {
    if (psiClass == null) return PsiMethod.EMPTY_ARRAY;
    return psiClass.findMethodsByName(name, false);
  }

  public static UExpression getFirstInChain(@Nullable UExpression expression) {
    if (expression instanceof UCallExpression) {
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      return receiver == null ? expression : getFirstInChain(receiver);
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return getFirstInChain(((UQualifiedReferenceExpression)expression).getReceiver());
    }
    return expression;
  }

  @Nullable
  public static UCallExpression findFirstCallExpressionInChain(@Nullable UExpression expression) {
    if (expression instanceof UCallExpression) {
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      if (receiver == null || findFirstCallExpressionInChain(receiver) == null) return (UCallExpression)expression;
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return findFirstCallExpressionInChain(((UQualifiedReferenceExpression)expression).getSelector());
    }
    return null;
  }

  @Nullable
  public static UCallExpression getNextCallInChain(@NotNull UExpression expression) {
    final UElement uastParent = expression.getUastParent();
    if (uastParent != null) {
      final UElement parentQualifiedReferenceExpression = uastParent.getUastParent();
      if (parentQualifiedReferenceExpression instanceof UQualifiedReferenceExpression) {
        final UExpression selector = ((UQualifiedReferenceExpression)parentQualifiedReferenceExpression).getSelector();
        if (selector instanceof UCallExpression) return (UCallExpression)selector;
      }
    }
    return null;
  }

  public static Collection<UCallExpression> collectCallExpressionsInChain(@Nullable UExpression expression,
                                                                          UCallExpressionPattern... patterns) {
    CommonProcessors.CollectProcessor<UCallExpression> processor = new CommonProcessors.CollectProcessor<>(new ArrayList<>());
    processCallExpressionsInChain(expression, processor, patterns);
    return processor.getResults();
  }

  @Nullable
  public static UCallExpression findFirstCallExpressionsInChain(@Nullable UExpression expression,
                                                                UCallExpressionPattern... patterns) {
    CommonProcessors.FindFirstProcessor<UCallExpression> processor = new CommonProcessors.FindFirstProcessor<>();
    processCallExpressionsInChain(expression, processor, patterns);
    return processor.getFoundValue();
  }

  public static boolean processCallExpressionsInChain(@Nullable UExpression expression,
                                                      @NotNull Processor<UCallExpression> patternProcessor,
                                                      UCallExpressionPattern... patterns) {
    if (expression instanceof UCallExpression) {
      if (!processCallExpression((UCallExpression)expression, patternProcessor, patterns)) return false;
      UExpression receiver = ((UCallExpression)expression).getReceiver();
      if (receiver != null) return processCallExpressionsInChain(receiver, patternProcessor, patterns);
    }
    if (expression instanceof UQualifiedReferenceExpression) {
      return processCallExpressionsInChain(((UQualifiedReferenceExpression)expression).getSelector(), patternProcessor, patterns);
    }
    return true;
  }

  public static boolean processCallExpression(@Nullable UCallExpression expression,
                                              @NotNull Processor<UCallExpression> processor,
                                              UCallExpressionPattern... patterns) {
    if (expression == null) return true;
    for (UCallExpressionPattern pattern : patterns) {
      if (pattern.accepts(expression) && !processor.process(expression)) return false;
    }
    return true;
  }

  @Nullable
  public static String getUExpressionText(@NotNull UExpression expression) {
    return UastUtils.evaluateString(expression);
  }
}
