package com.intellij.spring.model.utils;

import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public record UCallExpressionSearchParams(@NotNull Module module, @Nullable String classname, @NotNull String methodName) {
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof UCallExpressionSearchParams params)) return false;

    if (!module.equals(params.module)) return false;
    if (!Objects.equals(classname, params.classname)) return false;
    if (!methodName.equals(params.methodName)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = module.hashCode();
    result = 31 * result + (classname != null ? classname.hashCode() : 0);
    result = 31 * result + methodName.hashCode();
    return result;
  }

  public static UCallExpressionSearchParams create(@NotNull Module module, @Nullable String classname, @NotNull String methodName) {
    return new UCallExpressionSearchParams(module, classname, methodName);
  }
}
