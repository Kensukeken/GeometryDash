package com.intellij.spring.model.highlighting.jam;

import com.intellij.codeInsight.MetaAnnotationUtil;
import com.intellij.codeInspection.InspectionManager;
import com.intellij.codeInspection.ProblemDescriptor;
import com.intellij.codeInspection.ProblemsHolder;
import com.intellij.psi.*;
import com.intellij.psi.search.LocalSearchScope;
import com.intellij.spring.model.utils.SpringFunctionalSearchersUtils;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.uast.*;

import java.util.Collection;
import java.util.List;

public abstract class SpringSelfInvocationMethodCallsInspection extends SpringUastInspectionBase {

  protected abstract @NonNls Collection<String> getAnnotations();

  @NotNull
  protected abstract @Nls String getProblemMessage();

  @Override
  public ProblemDescriptor @Nullable [] checkClass(@NotNull UClass uClass, @NotNull InspectionManager manager, boolean isOnTheFly) {
    PsiClass aClass = UElementKt.getAsJavaPsiElement(uClass, PsiClass.class);
    if (aClass == null || isMetaAnnotated(aClass)) return null;

    final List<PsiMethod>
      annotatedMethods = ContainerUtil.filter(aClass.getAllMethods(), method -> {
      return !method.hasModifierProperty(PsiModifier.STATIC) && !method.hasModifierProperty(PsiModifier.FINAL) && isMetaAnnotated(method);
    });

    if (annotatedMethods.isEmpty()) return null;

    final ProblemsHolder holder = new ProblemsHolder(manager, aClass.getContainingFile(), isOnTheFly);
    LocalSearchScope localSearchScope = new LocalSearchScope(aClass);
    for (PsiMethod psiMethod : annotatedMethods) {
      checkAnnotatedMethodCalls(holder, psiMethod, localSearchScope);
    }
    return holder.getResultsArray();
  }


  private boolean isMetaAnnotated(@NotNull PsiModifierListOwner listOwner) {
    return MetaAnnotationUtil.isMetaAnnotated(listOwner, getAnnotations());
  }

  private void checkAnnotatedMethodCalls(@NotNull ProblemsHolder holder,
                                         @NotNull PsiMethod psiMethod,
                                         @NotNull LocalSearchScope searchScope) {
    for (UCallExpression methodCall : SpringFunctionalSearchersUtils.findMethodCalls(psiMethod, searchScope, true)) {
      if (isThisObjectCall(methodCall)) {
        final UMethod containingMethod = UastUtils.getParentOfType(methodCall, UMethod.class);
        if (containingMethod != null) {
          if (!MetaAnnotationUtil.isMetaAnnotated(containingMethod.getJavaPsi(), getAnnotations())) {
            final UIdentifier identifier = methodCall.getMethodIdentifier();
            if (identifier != null) {
              final PsiElement psi = identifier.getSourcePsi();
              if (psi != null) {
                holder.registerProblem(psi, getProblemMessage());
              }
            }
          }
        }
      }
    }
  }

  private static boolean isThisObjectCall(@NotNull UCallExpression call) {
    final UExpression receiver = call.getReceiver();

    return receiver == null || receiver instanceof UThisExpression;
  }
}