/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model;

import com.intellij.ide.presentation.Presentation;
import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiType;
import com.intellij.spring.SpringPresentationProvider;
import com.intellij.spring.contexts.model.CacheableCommonSpringModel;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

@Presentation(provider = SpringPresentationProvider.class)
public interface CommonSpringBean extends CommonModelElement {

  @Nullable @NlsSafe
  String getBeanName();

  /**
   * Return aliases defined in the bean definition, not including the bean name.
   *
   * @return bean aliases
   * @see CacheableCommonSpringModel#getAllBeanNames(SpringBeanPointer)
   */
  String @NotNull [] getAliases();

  @Nullable
  PsiType getBeanType(boolean considerFactories);

  @Nullable
  PsiType getBeanType();

  @NotNull
  Collection<SpringQualifier> getSpringQualifiers();

  @NotNull
  SpringProfile getProfile();

  boolean isPrimary();

  @NotNull
  @Override
  PsiFile getContainingFile();
}
