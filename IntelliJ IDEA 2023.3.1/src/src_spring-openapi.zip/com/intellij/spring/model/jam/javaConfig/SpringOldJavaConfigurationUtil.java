// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.javaConfig;

import com.intellij.jam.JamService;
import com.intellij.java.library.JavaLibraryUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.xml.XmlTag;
import com.intellij.spring.SpringManager;
import com.intellij.spring.SpringModelVisitorUtils;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.contexts.model.SpringModel;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.SpringModelSearchParameters;
import com.intellij.spring.model.utils.SpringBeanUtils;
import com.intellij.spring.model.utils.SpringModelSearchers;
import com.intellij.spring.search.SpringGlobalSearchScopes;
import com.intellij.util.SmartList;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static java.util.Collections.emptyList;

public final class SpringOldJavaConfigurationUtil {

  public static List<JavaConfigConfiguration> getJavaConfigurations(@NotNull Module module) {
    if (!JavaLibraryUtil.hasLibraryClass(module, SpringAnnotationsConstants.JAVA_CONFIG_CONFIGURATION)) return emptyList();

    JamService jamService = JamService.getJamService(module.getProject());

    return jamService.getJamClassElements(JavaConfigConfiguration.META,
                                          SpringAnnotationsConstants.JAVA_CONFIG_CONFIGURATION,
                                          SpringGlobalSearchScopes.runtime(module));
  }

  @NotNull
  public static List<SpringBeanPointer<?>> findExternalBeans(final PsiMethod psiMethod) {
    final Module module = ModuleUtilCore.findModuleForPsiElement(psiMethod);
    final PsiClass psiClass = psiMethod.getContainingClass();
    if (module == null || psiClass == null) {
      return emptyList();
    }
    if (getExternalBean(psiMethod) == null) {
      return emptyList();
    }
    List<SpringBeanPointer<?>> extBeans = new SmartList<>();
    for (SpringModel model : SpringManager.getInstance(psiMethod.getProject()).getAllModels(module)) {
      boolean hasJavaConfigBean = SpringModelSearchers.doesBeanExist(model, SpringModelSearchParameters.byClass(psiClass));
      if (hasJavaConfigBean) {
        final String externalBeanName = psiMethod.getName();
        for (SpringBeanPointer<?> springBean : SpringModelVisitorUtils.getAllDomBeans(model)) {
          final String beanName = springBean.getName();
          if (externalBeanName.equals(beanName) || Arrays.asList(springBean.getAliases()).contains(externalBeanName)) {
            extBeans.add(springBean);
          }
        }
      }
    }

    if (extBeans.isEmpty()) return emptyList();

    return extBeans;
  }

  @NotNull
  public static List<SpringJavaExternalBean> findExternalBeanReferences(CommonSpringBean springBean) {
    final XmlTag element = springBean.getXmlTag();
    if (element == null) {
      return emptyList();
    }
    final Module module = ModuleUtilCore.findModuleForPsiElement(element);
    if (module == null) {
      return emptyList();
    }

    final Set<String> beanNames = SpringBeanUtils.getInstance().findBeanNames(springBean);
    if (beanNames.isEmpty()) {
      return emptyList();
    }

    List<SpringJavaExternalBean> extBeans = new ArrayList<>();
    for (JavaConfigConfiguration javaConfiguration : getJavaConfigurations(module)) {
      for (SpringJavaExternalBean externalBean : javaConfiguration.getExternalBeans()) {
        final PsiMethod psiMethod = externalBean.getPsiElement();
        if (beanNames.contains(psiMethod.getName())) {
          extBeans.add(externalBean);
        }
      }
    }
    return extBeans;
  }

  @Nullable
  public static SpringJavaExternalBean getExternalBean(final PsiMethod psiMethod) {
    final Module module = ModuleUtilCore.findModuleForPsiElement(psiMethod);
    if (module != null) {
      for (JavaConfigConfiguration javaConfiguration : getJavaConfigurations(module)) {
        if (psiMethod.getContainingFile().equals(javaConfiguration.getPsiClass().getContainingFile())) {
          for (SpringJavaExternalBean externalBean : javaConfiguration.getExternalBeans()) {
            if (psiMethod.equals(externalBean.getPsiElement())) {
              return externalBean;
            }
          }
        }
      }
    }
    return null;
  }
}
