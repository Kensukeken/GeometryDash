package com.intellij.spring.model.jam.testContexts.junit;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.jam.model.util.JamCommonUtil;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.jam.reflect.JamMemberMeta;
import com.intellij.patterns.PatternCondition;
import com.intellij.patterns.PsiClassPattern;
import com.intellij.psi.*;
import com.intellij.semantic.SemKey;
import com.intellij.spring.model.jam.testContexts.ContextConfiguration;
import com.intellij.spring.model.jam.testContexts.CustomContextConfiguration;
import com.intellij.util.ProcessingContext;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static com.intellij.patterns.PsiJavaPatterns.psiClass;
import static com.intellij.spring.constants.SpringAnnotationsConstants.*;
import static com.intellij.spring.model.aliasFor.SpringAliasForUtils.findDefiningMetaAnnotation;

/**
 * JUnit @ExtendsWith(SpringExtension.class)
 */
public final class ExtendsWithSpringExtension extends CustomContextConfiguration {
  public static final PsiClassPattern EXTENDS_WITH_SPRING_PATTERN =
    psiClass().nonAnnotationType().withoutModifiers(PsiModifier.PRIVATE).with(new PatternCondition<>("withAnnotation") {
      @Override
      public boolean accepts(@NotNull final PsiClass psiClass, final ProcessingContext context) {
        if (AnnotationUtil.findAnnotation(psiClass, CONTEXT_CONFIGURATION) != null) return false; //
        return isJUnitSpringExtension(AnnotationUtil.findAnnotation(psiClass, JUNIT_EXTEND_WITH));
      }
    });
  public static final SemKey<ExtendsWithSpringExtension> JAM_KEY = CONTEXT_CONFIGURATION_JAM_KEY.subKey("SpringBootstrapWithTest");
  public static final SemKey<JamMemberMeta<PsiClass, ExtendsWithSpringExtension>> META_KEY =
    ContextConfiguration.CONTEXT_CONFIGURATION_META_KEY.subKey("ExtendsWithSpringExtension");
  public static final JamClassMeta<ExtendsWithSpringExtension> META = new JamClassMeta<>(null, ExtendsWithSpringExtension::new, JAM_KEY);


  public ExtendsWithSpringExtension(String anno, @NotNull PsiClass psiClassAnchor) {
    super(anno, PsiElementRef.real(psiClassAnchor));
  }

  private ExtendsWithSpringExtension(@NotNull PsiElementRef<?> psiRef) {
    super(JUNIT_EXTEND_WITH, psiRef);
  }

  private boolean isJunitExtendWithSpringExtension(@Nullable String annoName) {
    return annoName != null && (JUNIT_EXTEND_WITH.equals(annoName) ||
                                isJUnitSpringExtension(findDefiningMetaAnnotation(getPsiElement(), annoName, JUNIT_EXTEND_WITH)));
  }

  @Override
  public boolean isValidContextConfiguration() {
    //  @ExtendWith is JUnit annotation and has low priority in our test models (@ContextConfiguration(+meta), @BootstrapWith(+meta))
    //  it's context configuration when:
    //    - it's the only @ExtendWith(SpringExtension.class) on class
    //    - it's meta annotation of @ExtendWith(SpringExtension.class) and this meta anno doesn't have other spring annotations (for instance, @BootstrapWith)
    final String annoName = myAnnotationChildLink.getAnnotationQualifiedName();
    if (getPsiElement().hasAnnotation(CONTEXT_CONFIGURATION)) return false;
    return isJunitExtendWithSpringExtension(annoName)
           && findDefiningMetaAnnotation(getPsiElement(), annoName, SPRING_BOOTSTRAP_WITH_ANNO) == null;
  }

  private static boolean isJUnitSpringExtension(@Nullable PsiAnnotation annotation) {
    if (annotation == null) return false;
    final PsiType psiType = JamCommonUtil.getObjectValue(annotation.findAttributeValue("value"), PsiClassType.class);
    if (psiType != null && JUNIT_SPRING_EXTENSION.equals(psiType.getCanonicalText())) return true;

    final PsiClass aClass = JamCommonUtil.getObjectValue(annotation.findAttributeValue("value"), PsiClass.class);
    return aClass != null && JUNIT_SPRING_EXTENSION.equals(aClass.getQualifiedName());
  }
}