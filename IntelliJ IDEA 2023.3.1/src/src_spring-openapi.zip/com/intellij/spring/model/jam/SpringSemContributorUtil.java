// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam;

import com.intellij.codeInsight.MetaAnnotationUtil;
import com.intellij.jam.JamElement;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamMemberMeta;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.project.DumbService;
import com.intellij.openapi.project.Project;
import com.intellij.patterns.ElementPattern;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiMember;
import com.intellij.psi.impl.compiled.ClsMemberImpl;
import com.intellij.semantic.SemKey;
import com.intellij.semantic.SemRegistrar;
import com.intellij.semantic.SemService;
import com.intellij.spring.SpringLibraryUtil;
import com.intellij.spring.constants.SpringJavaeeConstants;
import com.intellij.spring.model.aliasFor.SpringAliasForUtils;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.JamAnnotationTypeUtil;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.intellij.spring.constants.SpringAnnotationsConstants.*;
import static com.intellij.util.containers.ContainerUtil.addIfNotNull;
import static java.util.Collections.emptySet;

public final class SpringSemContributorUtil {
  // predefined component annotations
  @NonNls
  public static final String[] DEFAULT_SPRING_COMPONENTS =
    {COMPONENT, CONTROLLER, REPOSITORY, SERVICE, JAVA_CONFIG_CONFIGURATION, JAVA_SPRING_CONFIGURATION, SpringJavaeeConstants.JAVAX_NAMED,
      SpringJavaeeConstants.JAKARTA_NAMED};

  public static <T extends JamElement, Psi extends PsiMember> void registerMetaComponents(@NotNull SemService semService,
                                                                                          @NotNull SemRegistrar registrar,
                                                                                          @NotNull ElementPattern<? extends Psi> place,
                                                                                          @NotNull SemKey<JamMemberMeta<Psi, T>> metaKey,
                                                                                          @NotNull SemKey<T> semKey,
                                                                                          @NotNull Function<? super Psi, ? extends JamMemberMeta<Psi, T>> metaFunction) {
    registrar.registerSemElementProvider(metaKey, place, metaFunction);

    registrar.registerSemElementProvider(semKey, place,
                                         member -> {
                                           JamMemberMeta<Psi, T> memberMeta = semService.getSemElement(metaKey, member);
                                           return memberMeta != null ? memberMeta.createJamElement(PsiElementRef.real(member)) : null;
                                         }
    );
  }

  public static <T extends JamElement, Psi extends PsiMember> void registerRepeatableMetaComponents(@NotNull SemService semService,
                                                                                                    @NotNull SemRegistrar registrar,
                                                                                                    @NotNull ElementPattern<? extends Psi> place,
                                                                                                    @NotNull SemKey<JamMemberMeta<Psi, T>> metaKey,
                                                                                                    @NotNull SemKey<T> semKey,
                                                                                                    @NotNull Function<? super Psi, ? extends Collection<JamMemberMeta<Psi, T>>> metaFunction) {
    registrar.registerRepeatableSemElementProvider(metaKey, place, metaFunction);

    registrar.registerRepeatableSemElementProvider(semKey, place,
                                                   member -> {
                                                     List<JamMemberMeta<Psi, T>> memberMetas = semService.getSemElements(metaKey, member);
                                                     Collection<T> metas = new HashSet<>();
                                                     for (JamMemberMeta<Psi, T> memberMeta : memberMetas) {
                                                       addIfNotNull(metas, memberMeta.createJamElement(PsiElementRef.real(member)));
                                                     }
                                                     return metas.isEmpty() ? null : metas;
                                                   }
    );
  }

  public static <T extends JamElement, Psi extends PsiMember> Function<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull SemKey<T> semKey,
                                                                                                                  @NotNull Collection<String> metaAnnotations,
                                                                                                                  @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                                                  @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                  boolean includeRootAnnotations) {
    return createFunction(semKey, metaAnnotations, producer, metaConsumer, null, includeRootAnnotations, true);
  }

  public static <T extends JamElement, Psi extends PsiMember> Function<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull SemKey<T> semKey,
                                                                                                                  @NotNull Collection<String> metaAnnotations,
                                                                                                                  @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                                                  @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                  boolean includeRootAnnotations,
                                                                                                                  boolean filterCustomJamImplementations) {
    return createFunction(semKey, metaAnnotations, producer, metaConsumer, null, includeRootAnnotations, filterCustomJamImplementations);
  }

  public static <T extends JamElement, Psi extends PsiMember> Function<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull SemKey<T> semKey,
                                                                                                                  @NotNull Collection<String> metaAnnotations,
                                                                                                                  @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                                                  @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                  @Nullable BiFunction<String, Project, ? extends JamAnnotationMeta> annotationMeta,
                                                                                                                  boolean includeRootAnnotations) {
    return createFunction(semKey, metaAnnotations, producer, metaConsumer, annotationMeta, includeRootAnnotations, true);
  }

  /**
   * @see SpringAliasForUtils#getAnnotationMetaProducer(SemKey, JamMemberMeta[])
   */
  public static <T extends JamElement, Psi extends PsiMember> Function<Psi, JamMemberMeta<Psi, T>> createFunction(@NotNull SemKey<T> semKey,
                                                                                                                  @NotNull Collection<String> metaAnnotations,
                                                                                                                  @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                                                  @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                  @Nullable BiFunction<String, Project, ? extends JamAnnotationMeta> annotationMeta,
                                                                                                                  boolean includeRootAnnotations,
                                                                                                                  boolean filterCustomJamImplementations) {
    return psiMember -> {
      Project project = psiMember.getProject();
      if (DumbService.isDumb(project)) return null;
      if (psiMember instanceof PsiClass && ((PsiClass)psiMember).isAnnotationType()) return null;
      if (!SpringLibraryUtil.hasSpringLibrary(project)) return null;

      Module module = ModuleUtilCore.findModuleForPsiElement(psiMember);
      if (module != null && !SpringLibraryUtil.hasSpringLibrary(module)) return null;

      Set<String> jamCustomFqns;
      if (filterCustomJamImplementations) {
        jamCustomFqns = getJamCustomFQNs(module, metaAnnotations.iterator().next(), true);
      }
      else {
        jamCustomFqns = emptySet();
      }

      PsiClass annotationClass = MetaAnnotationUtil.findAnnotationsByMeta(psiMember, metaAnnotations)
        .filter(annoClass -> {
          if (includeRootAnnotations) return true;

          var qualifiedName = annoClass.getQualifiedName();
          if (jamCustomFqns.contains(qualifiedName)) return false;

          return qualifiedName != null && !metaAnnotations.contains(qualifiedName);
        })
        .findFirst()
        .orElse(null);

      if (annotationClass != null) {
        return getMeta(semKey, producer, metaConsumer, annotationMeta, psiMember, annotationClass.getQualifiedName());
      }

      if (psiMember instanceof ClsMemberImpl && includeRootAnnotations) {
        return getMetaForPsiMemberFromLibrary(semKey, metaAnnotations, producer, metaConsumer, annotationMeta, psiMember);
      }
      return null;
    };
  }

  @Nullable
  private static <T extends JamElement, Psi extends PsiMember> JamMemberMeta<Psi, T> getMetaForPsiMemberFromLibrary(@NotNull SemKey<T> semKey,
                                                                                                                    Collection<String> metaAnnotations,
                                                                                                                    @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                                                    @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                                                    @Nullable BiFunction<String, Project, ? extends JamAnnotationMeta> annotationMeta,
                                                                                                                    @NotNull Psi aPsiMember) {
    if (aPsiMember instanceof ClsMemberImpl) {
      for (PsiAnnotation psiAnnotation : aPsiMember.getAnnotations()) {
        final String qualifiedName = psiAnnotation.getQualifiedName();
        if (qualifiedName == null || isFrameworkAnnotation(qualifiedName)) continue;

        final PsiClass annotationType = psiAnnotation.resolveAnnotationType();
        if (annotationType != null) {
          // performance issue: only check first-level custom annotations (annotated @Component/@Service/@ComponentScan)
          for (String rootAnnotation : metaAnnotations) {
            if (annotationType.hasAnnotation(rootAnnotation)) {
              return getMeta(semKey, producer, metaConsumer, annotationMeta, aPsiMember, qualifiedName);
            }
          }
        }
      }
    }
    return null;
  }

  private static boolean isFrameworkAnnotation(@NotNull String qualifiedName) {
    return qualifiedName.startsWith("org.springframework.stereotype") ||
           qualifiedName.startsWith("org.springframework.context.annotation") ||
           qualifiedName.startsWith("javax") ||
           qualifiedName.startsWith("jakarta") ||
           qualifiedName.startsWith("java.lang") ||
           qualifiedName.startsWith("org.jetbrains");
  }

  public static <T extends JamElement, Psi extends PsiMember> Function<Psi, Collection<JamMemberMeta<Psi, T>>> createRepeatableFunction(
    @NotNull SemKey<T> semKey,
    @NotNull Collection<String> metaAnnotations,
    @NotNull BiFunction<String, Psi, ? extends T> producer,
    @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
    @Nullable BiFunction<String, Project, ? extends JamAnnotationMeta> annotationMeta) {
    return psiMember -> {
      Project project = psiMember.getProject();
      if (DumbService.isDumb(project)) return null;
      if (!SpringLibraryUtil.hasSpringLibrary(project)) return null;

      Module module = ModuleUtilCore.findModuleForPsiElement(psiMember);
      if (module != null && !SpringLibraryUtil.hasSpringLibrary(module)) return null;

      var metas = MetaAnnotationUtil.findAnnotationsByMeta(psiMember, metaAnnotations)
        .map(annoClass -> {
          String anno = annoClass.getQualifiedName();
          if (anno != null && !metaAnnotations.contains(anno)) {
            return getMeta(semKey, producer, metaConsumer, annotationMeta, psiMember, anno);
          }
          return null;
        })
        .filter(Objects::nonNull)
        .collect(Collectors.toSet());

      return metas.isEmpty() ? null : metas;
    };
  }

  @NotNull
  private static <T extends JamElement, Psi extends PsiMember> JamMemberMeta<Psi, T> getMeta(@NotNull SemKey<T> semKey,
                                                                                             @NotNull BiFunction<String, ? super Psi, ? extends T> producer,
                                                                                             @Nullable Consumer<? super JamMemberMeta<Psi, T>> metaConsumer,
                                                                                             @Nullable BiFunction<String, Project, ? extends JamAnnotationMeta> annotationMeta,
                                                                                             Psi psiMember, String anno) {
    JamMemberMeta<Psi, T> meta = new JamMemberMeta<>(null, semKey, ref -> producer.apply(anno, ref.getPsiElement()));
    if (metaConsumer != null) {
      metaConsumer.accept(meta);
    }
    if (annotationMeta != null) registerCustomAnnotationMeta(anno, meta, annotationMeta, psiMember.getProject());
    return meta;
  }

  private static <T extends JamElement, Psi extends PsiMember> void registerCustomAnnotationMeta(@NotNull String anno,
                                                                                                 @NotNull JamMemberMeta<Psi, T> meta,
                                                                                                 @NotNull BiFunction<String, Project, ? extends JamAnnotationMeta> metaNotNullFunction,
                                                                                                 @NotNull Project project) {
    List<JamAnnotationMeta> annotations = meta.getAnnotations();
    for (JamAnnotationMeta annotationMeta : annotations) {
      if (anno.equals(annotationMeta.getAnnoName())) return;
    }
    meta.addAnnotation(metaNotNullFunction.apply(anno, project));
  }

  /**
   * @return Consumer.
   * @see SpringStereotypeElement#addPomTargetProducer(JamMemberMeta)
   */
  public static <T extends SpringStereotypeElement, Psi extends
    PsiMember> Consumer<JamMemberMeta<Psi, T>> createStereotypeConsumer() {
    return SpringStereotypeElement::addPomTargetProducer;
  }

  /**
   * @param anno Annotation FQN.
   * @return Custom annotation types.
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno) {
    return getCustomMetaAnnotations(anno, false);
  }

  /**
   * Returns all custom meta annotations in defined scope.
   *
   * @param anno      Annotation FQN.
   * @param withTests Whether to include annotations located in test scope.
   * @return Custom annotation types.
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno, final boolean withTests) {
    return getCustomMetaAnnotations(anno, withTests, true);
  }

  /**
   * Returns all custom meta annotations in defined scope, optionally filtering custom JAM implementations.
   *
   * @param anno                           Annotation FQN.
   * @param withTests                      Whether to include annotations located in test scope.
   * @param filterCustomJamImplementations Whether to filter custom JAM implementations.
   * @return Custom annotation types.
   * @see JamCustomImplementationBean
   */
  public static Function<Module, Collection<String>> getCustomMetaAnnotations(@NotNull final String anno,
                                                                              final boolean withTests,
                                                                              final boolean filterCustomJamImplementations) {
    return new CustomMetaAnnotationsFunction(anno, filterCustomJamImplementations, withTests);
  }

  public static class CustomMetaAnnotationsFunction implements Function<Module, Collection<String>> {
    private final @NotNull String myRootAnnotation;
    private final boolean myFilterCustomJamImplementations;
    private final boolean myWithTests;

    public CustomMetaAnnotationsFunction(@NotNull String anno, boolean filterCustomJamImplementations, boolean withTests) {
      myRootAnnotation = anno;
      myFilterCustomJamImplementations = filterCustomJamImplementations;
      myWithTests = withTests;
    }

    @Override
    public Collection<String> apply(Module module) {
      if (module == null) return emptySet();

      Collection<String> psiClassNames = getAnnotationTypes(module, myRootAnnotation, myWithTests);
      final Set<String> customMetaFQNs = getJamCustomFQNs(module);

      return ContainerUtil.mapNotNull(psiClassNames, qualifiedName -> {
        if (myRootAnnotation.equals(qualifiedName)) return null;

        if (customMetaFQNs.contains(qualifiedName)) {
          return null;
        }
        return qualifiedName;
      });
    }

    private @NotNull Set<String> getJamCustomFQNs(Module module) {
      if (!myFilterCustomJamImplementations) {
        return emptySet();
      }
      return SpringSemContributorUtil.getJamCustomFQNs(module, myRootAnnotation, myWithTests);
    }
  }

  private static @NotNull Set<String> getJamCustomFQNs(Module module, String myRootAnnotation, boolean withTests) {
    Set<String> customMetaFQNs = null;
    for (JamCustomImplementationBean bean : JamCustomImplementationBean.EP_NAME.getExtensionList()) {
      if (myRootAnnotation.equals(bean.baseAnnotationFqn)) {
        String customMetaAnnotationFqn = bean.customMetaAnnotationFqn;
        if (customMetaFQNs == null) {
          customMetaFQNs = new HashSet<>();
        }
        customMetaFQNs.add(customMetaAnnotationFqn);

        Collection<String> customMetaClasses = getAnnotationTypes(module, customMetaAnnotationFqn, withTests);
        customMetaFQNs.addAll(customMetaClasses);
      }
    }
    if (customMetaFQNs == null) return emptySet();

    return customMetaFQNs;
  }

  private static Collection<String> getAnnotationTypes(Module module, String anno, boolean withTests) {
    if (!SpringLibraryUtil.hasSpringLibrary(module)) return Collections.emptyList();

    return withTests ?
           JamAnnotationTypeUtil.getInstance(module).getAnnotationNamesWithChildrenIncludingTests(anno) :
           JamAnnotationTypeUtil.getInstance(module).getAnnotationNamesWithChildren(anno);
  }
}
