// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.utils;

import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiClass;
import org.jetbrains.annotations.NotNull;

import java.util.Collection;
import java.util.List;

/**
 * @author Yann C&eacute;bron
 */
public abstract class JamAnnotationTypeUtil {

  public static JamAnnotationTypeUtil getInstance(Module module) {
    return module.getService(JamAnnotationTypeUtil.class);
  }

  public abstract @NotNull List<PsiClass> getQualifierAnnotationTypesWithChildren();

  public abstract @NotNull List<String> getQualifierAnnotationNamesWithChildren();

  public abstract @NotNull List<String> getUserDefinedCustomComponentAnnotations();

  public abstract Collection<PsiClass> getAnnotationTypesWithChildren(@NotNull String annotationName);

  public abstract Collection<PsiClass> getAnnotationTypesWithChildrenIncludingTests(@NotNull String annotationName);

  public abstract Collection<String> getAnnotationNamesWithChildren(@NotNull String annotationName);

  public abstract Collection<String> getAnnotationNamesWithChildrenIncludingTests(@NotNull String annotationName);
}
