/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.jam.stereotype;

import com.intellij.ide.presentation.Presentation;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.psi.PsiElementRef;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.model.jam.JamPsiMemberSpringBean;
import org.jetbrains.annotations.NotNull;

import static com.intellij.spring.constants.SpringCorePresentationConstants.COMPONENT;

@Presentation(typeName = COMPONENT)
public final class SpringComponent extends SpringStereotypeElement {

  public static final JamClassMeta<SpringComponent> META =
    new JamClassMeta<>(null, SpringComponent::new,
                       JamPsiMemberSpringBean.PSI_MEMBER_SPRING_BEAN_JAM_KEY.subKey("SpringComponent"));

  static {
    addPomTargetProducer(META);
  }

  private SpringComponent(@NotNull PsiElementRef<?> psiRef) {
    super(SpringAnnotationsConstants.COMPONENT, psiRef);
  }
}
