// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.javaConfig;

import com.intellij.spring.model.CommonSpringBean;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public interface ImplicitlyRegisteredBeansProvider {
  @NotNull
  Set<CommonSpringBean> getImplicitlyRegistered();
}
