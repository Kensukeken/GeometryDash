package com.intellij.spring.model.jam.stereotype;

import com.intellij.psi.DelegatePsiTarget;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPsiTarget;
import org.jetbrains.annotations.NotNull;

public class CustomSpringComponentPsiTarget extends DelegatePsiTarget implements SpringBeanPsiTarget {
  private final CustomSpringComponent myComponent;

  public CustomSpringComponentPsiTarget(@NotNull CustomSpringComponent component) {
    super(component.getPsiElement());
    myComponent = component;
  }

  @Override
  public String getName() {
    return myComponent.getBeanName();
  }

  @Override
  public boolean isWritable() {
    return getNavigationElement().isWritable();
  }

  @Override
  public SpringBeanPsiTarget setName(@NotNull String newName) {
    return this;
  }

  @Override
  public CommonSpringBean getSpringBean() {
    return myComponent;
  }
}
