package com.intellij.spring.model.jam.converters;

import com.intellij.jam.JamStringAttributeElement;
import com.intellij.psi.ElementManipulators;
import com.intellij.psi.PsiLanguageInjectionHost;
import com.intellij.psi.PsiReference;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.JavaClassReferenceProvider;
import com.intellij.psi.impl.source.resolve.reference.impl.providers.JavaClassReferenceSet;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.util.ArrayUtil;
import org.jetbrains.annotations.NotNull;

public class SpringBeanPointerOrClassConverter extends SpringBeanReferenceJamConverter {
  private static final JavaClassReferenceProvider PROVIDER = new JavaClassReferenceProvider();

  public SpringBeanPointerOrClassConverter(String... baseClasses) {
    super(baseClasses);
  }

  @Override
  public PsiReference @NotNull [] createReferences(@NotNull JamStringAttributeElement<SpringBeanPointer<?>> context,
                                                   @NotNull PsiLanguageInjectionHost injectionHost) {
    final String stringValue = context.getStringValue();
    if (stringValue != null && stringValue.contains(".")) {
      // 1. beanPointer with qualified name or  2. full qualified class name
      return ArrayUtil.append(new JavaClassReferenceSet(stringValue, injectionHost, ElementManipulators.getOffsetInElement(injectionHost),
                                                        false, PROVIDER).getAllReferences(), createReference(context, injectionHost),
                              PsiReference.class);
    }
    return super.createReferences(context, injectionHost);
  }
}
