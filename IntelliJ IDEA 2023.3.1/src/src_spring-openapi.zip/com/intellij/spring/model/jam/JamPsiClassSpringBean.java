// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

package com.intellij.spring.model.jam;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiModifier;
import com.intellij.psi.PsiType;
import com.intellij.psi.util.PsiTypesUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class JamPsiClassSpringBean extends JamPsiMemberSpringBean<PsiClass> {
  protected JamPsiClassSpringBean(PsiElementRef<?> ref) {
    super(ref);
  }

  @Override
  public @NotNull PsiClass getPsiElement() {
    // keep compatibility with 'com.github.bjansen.intellij.pebble' plugin
    return super.getPsiElement();
  }

  @Override
  @Nullable
  public String getBeanName() {
    if (!isValid()) return null;

    return StringUtil.decapitalize(StringUtil.notNullize(getName(getPsiElement())));
  }

  @Nullable
  private static String getName(@NotNull PsiClass psiClass) {
    if (psiClass.hasModifierProperty(PsiModifier.STATIC)) {
      PsiClass containingClass = psiClass.getContainingClass();
      if (containingClass != null) {
        return getName(containingClass) + "." + psiClass.getName();
      }
    }
    return psiClass.getName();
  }

  @Override
  @Nullable
  public PsiType getBeanType() {
    if (!isValid()) return null;

    return PsiTypesUtil.getClassType(getPsiElement());
  }
}