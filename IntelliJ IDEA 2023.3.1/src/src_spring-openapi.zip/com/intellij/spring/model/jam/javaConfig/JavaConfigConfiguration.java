// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.javaConfig;

import com.intellij.jam.reflect.JamChildrenQuery;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.psi.PsiElementRef;
import org.jetbrains.annotations.NotNull;

import java.util.List;

import static com.intellij.jam.reflect.JamChildrenQuery.annotatedMethods;

public final class JavaConfigConfiguration extends SpringJavaConfiguration {
  public static final JamClassMeta<JavaConfigConfiguration> META =
    new JamClassMeta<>(JavaConfigConfiguration.class, JavaConfigConfiguration::new);

  private static final JamChildrenQuery<JavaConfigJavaBean> BEANS_QUERY =
    annotatedMethods(JavaConfigJavaBean.META, JavaConfigJavaBean.class, ref -> new JavaConfigJavaBean(ref));

  private static final JamChildrenQuery<SpringJavaExternalBean> EXTERNAL_BEANS_QUERY =
    annotatedMethods(SpringJavaExternalBean.META, SpringJavaExternalBean.class, ref -> new SpringJavaExternalBean(ref));

  private JavaConfigConfiguration(@NotNull PsiElementRef<?> psiRef) {
    super(psiRef);
  }

  static {
    META.addChildrenQuery(BEANS_QUERY);
    META.addChildrenQuery(EXTERNAL_BEANS_QUERY);
  }

  @Override
  public List<? extends SpringJavaBean> getBeans() {
    return BEANS_QUERY.findChildren(PsiElementRef.real(getPsiElement()));
  }

  public List<? extends SpringJavaExternalBean> getExternalBeans() {
    return EXTERNAL_BEANS_QUERY.findChildren(PsiElementRef.real(getPsiElement()));
  }
}