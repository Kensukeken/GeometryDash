/*
 * Copyright 2000-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.model.jam;

import com.intellij.jam.JamBaseElement;
import com.intellij.jam.JamNumberAttributeElement;
import com.intellij.jam.reflect.*;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiModifierListOwner;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import org.jetbrains.annotations.Nullable;

/**
 * {@value SpringAnnotationsConstants#ORDER}
 */
public final class SpringOrder extends JamBaseElement<PsiModifierListOwner> {

  /**
   * org.springframework.core.Ordered
   */
  public static final Integer LOWEST_PRECEDENCE = Integer.MAX_VALUE;

  /**
   * org.springframework.core.Ordered
   */
  public static final Integer HIGHEST_PRECEDENCE = Integer.MIN_VALUE;

  private static final JamNumberAttributeMeta.Single<Integer> VALUE_ATTR_META =
    JamAttributeMeta.singleInteger("value");

  private static final JamAnnotationMeta ANNO_META =
    new JamAnnotationMeta(SpringAnnotationsConstants.ORDER).
      addAttribute(VALUE_ATTR_META);

  private static final JamMemberArchetype<PsiModifierListOwner, SpringOrder> ARCHETYPE =
    new JamMemberArchetype<PsiModifierListOwner, SpringOrder>()
      .addAnnotation(ANNO_META);

  public static final JamClassMeta<SpringOrder> CLASS_META =
    new JamClassMeta<>(ARCHETYPE, SpringOrder.class, SpringOrder::new);
  public static final JamFieldMeta<SpringOrder> FIELD_META =
    new JamFieldMeta<>(ARCHETYPE, SpringOrder.class, SpringOrder::new);
  public static final JamMethodMeta<SpringOrder> METHOD_META =
    new JamMethodMeta<>(ARCHETYPE, SpringOrder.class, SpringOrder::new);

  private SpringOrder(PsiElementRef<?> ref) {
    super(ref);
  }

  @Nullable
  public Integer getValue() {
    final JamNumberAttributeElement<Integer> jam = VALUE_ATTR_META.getJam(ANNO_META.getAnnotationRef(getPsiElement()));
    if (jam.getPsiElement() != null) {
      return jam.getValue();
    }
    return Integer.MAX_VALUE;
  }
}
