// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.converters;

import com.intellij.codeInsight.lookup.LookupElement;
import com.intellij.jam.JamSimpleReferenceConverter;
import com.intellij.jam.JamStringAttributeElement;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiAnnotationMemberValue;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.spring.CommonSpringModel;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.SpringModelSearchParameters;
import com.intellij.spring.model.converters.SpringConverterUtil;
import com.intellij.spring.model.utils.SpringModelSearchers;
import com.intellij.spring.model.utils.SpringModelUtils;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.stream.Collectors;

public class SpringBeanReferenceJamConverter extends JamSimpleReferenceConverter<SpringBeanPointer<?>> {
  private final Set<String> myBaseClasses = new HashSet<>();

  public SpringBeanReferenceJamConverter(String... baseClasses) {
    ContainerUtil.addAllNotNull(myBaseClasses, baseClasses);
  }

  public Set<String> getBaseClasses() {
    return myBaseClasses;
  }

  @Override
  public SpringBeanPointer<?>  fromString(@Nullable String s, JamStringAttributeElement<SpringBeanPointer<?>> context) {
    if (StringUtil.isEmptyOrSpaces(s)) {
      return null;
    }

    final CommonSpringModel model = getSpringModel(context.getPsiElement());
    return SpringModelSearchers.findBean(model, s);
  }

  @Override
  public Collection<SpringBeanPointer<?>> getVariants(JamStringAttributeElement<SpringBeanPointer<?>> context) {
    final PsiAnnotationMemberValue psiElement = context.getPsiElement();
    if (psiElement == null) return Collections.emptyList();

    if (myBaseClasses.isEmpty()) {
      final CommonSpringModel model = getSpringModel(psiElement);
      return model.getAllCommonBeans();
    }
    final CommonSpringModel model = getSpringModel(psiElement);

    return myBaseClasses.stream()
      .map(s -> JavaPsiFacade.getInstance(psiElement.getProject()).findClass(s, psiElement.getResolveScope()))
      .filter(Objects::nonNull)
      .flatMap(aClass -> findBeans(model, aClass).stream())
      .collect(Collectors.toList());
  }

  @NotNull
  private static List<SpringBeanPointer<?>> findBeans(@NotNull CommonSpringModel model, @NotNull PsiClass psiClass) {
    final SpringModelSearchParameters.BeanClass searchParameters =
      SpringModelSearchParameters.byClass(psiClass).withInheritors().effectiveBeanTypes();
    return SpringModelSearchers.findBeans(model, searchParameters);
  }

  @NotNull
  @Override
  protected LookupElement createLookupElementFor(@NotNull SpringBeanPointer<?>  target) {
    final LookupElement variant = SpringConverterUtil.createCompletionVariant(target);
    return variant != null ? variant : super.createLookupElementFor(target);
  }

  @Override
  protected PsiElement getPsiElementFor(@NotNull SpringBeanPointer<?>  target) {
    return target.getSpringBean().getIdentifyingPsiElement();
  }

  /**
   * Spring Model for converter.
   *
   * @param psiElement Current element.
   * @return Spring Model for resolving/completion.
   */
  @NotNull
  protected CommonSpringModel getSpringModel(PsiElement psiElement) {
    return SpringModelUtils.getInstance().getSpringModel(psiElement);
  }
}
