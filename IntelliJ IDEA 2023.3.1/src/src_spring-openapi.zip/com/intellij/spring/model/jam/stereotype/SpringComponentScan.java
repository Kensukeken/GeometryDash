// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.stereotype;

import com.intellij.jam.*;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamClassAttributeMeta;
import com.intellij.jam.reflect.JamStringAttributeMeta;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.ModificationTracker;
import com.intellij.openapi.util.Pair;
import com.intellij.psi.*;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.semantic.SemKey;
import com.intellij.spring.SpringModificationTrackersManager;
import com.intellij.spring.contexts.model.ComponentScanPackagesModel;
import com.intellij.spring.contexts.model.ComponentScanSearchContext;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.xml.context.SpringBeansPackagesScan;
import com.intellij.util.ArrayUtil;
import com.intellij.util.Processor;
import com.intellij.util.containers.ConcurrentFactoryMap;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Inheritors should register with {@link #COMPONENT_SCAN_META_KEY} to get builtin support
 * for component-scan-like annotations (e.g. goto annotated elements, highlighting of unresolved package definitions).
 */
public abstract class SpringComponentScan extends JamCommonModelElement<PsiClass> implements JamElement, SpringBeansPackagesScan {
  protected static final String VALUE_ATTR_NAME = "value";
  protected static final String BASE_PACKAGES_ATTR_NAME = "basePackages";
  protected static final String BASE_PACKAGE_CLASSES_ATTR_NAME = "basePackageClasses";

  public static final SemKey<JamAnnotationMeta> COMPONENT_SCAN_META_KEY = SemKey.createKey("SpringComponentScan");
  public static final SemKey<SpringComponentScan> COMPONENT_SCAN_JAM_KEY = JamService.JAM_ELEMENT_KEY.subKey("SpringComponentScan");

  private final CachedValue<Map<Pair<Module, Boolean>, Set<CommonSpringBean>>> myScanned;

  protected SpringComponentScan(@NotNull PsiElementRef<?> psiRef) {
    super(psiRef);

    Project project = Objects.requireNonNull(psiRef.getPsiElement()).getProject();
    myScanned = CachedValuesManager.getManager(project).createCachedValue(() -> {
      Map<Pair<Module, Boolean>, Set<CommonSpringBean>> map = ConcurrentFactoryMap.createMap(key -> getScannedBeans(key.first, key.second));
      PsiFile file = getPsiElement().getContainingFile();
      return CachedValueProvider.Result.create(map, file == null
                                                    ? new Object[]{ModificationTracker.EVER_CHANGED}
                                                    : getScannedElementsDependencies(file));
    }, false);
  }

  protected SpringComponentScan(@NotNull PsiClass psiElement) {
    this(PsiElementRef.real(psiElement));
  }

  @NotNull
  @Override
  public final Set<CommonSpringBean> getScannedElements(@NotNull final Module module, boolean includeTests) {
    if (module.isDisposed()) return Collections.emptySet();
    return myScanned.getValue().get(Pair.create(module, includeTests));
  }

  public static Object[] getScannedElementsDependencies(@NotNull PsiFile containingFile) {
    Object[] dependencies = SpringModificationTrackersManager.getInstance(containingFile.getProject()).getOuterModelsDependencies();
    dependencies = ArrayUtil.append(dependencies, containingFile);
    return dependencies;
  }

  @NotNull
  protected Set<CommonSpringBean> getScannedBeans(@NotNull Module module, boolean includeTests) {
    final ComponentScanSearchContext context = ComponentScanSearchContext.create(getPsiPackages(), module)
      .includeTests(includeTests)
      .useDefaultFilters(useDefaultFilters())
      .excludeContextFilters(getExcludeContextFilters())
      .includeContextFilters(getIncludeContextFilters());

    return ContainerUtil.map2LinkedSet(ComponentScanPackagesModel.getScannedComponents(context), SpringBeanPointer.TO_BEAN);
  }

  @NotNull
  protected abstract PsiElementRef<PsiAnnotation> getAnnotationRef();

  @Nullable
  public PsiAnnotation getAnnotation() { return getAnnotationRef().getPsiElement(); }

  @Override
  @NotNull
  public Set<PsiPackage> getPsiPackages() {
    Set<PsiPackage> definedPackages = getDefinedPackages();
    return definedPackages.isEmpty() ? getDefaultPsiPackages() : definedPackages;
  }

  @NotNull
  public Set<PsiPackage> getDefinedPackages() {
    Set<PsiPackage> allPackages = new LinkedHashSet<>();

    for (JamStringAttributeMeta.Collection<Collection<PsiPackage>> packageMeta : getPackageJamAttributes()) {
      addPackages(allPackages, packageMeta);
    }
    addBasePackageClasses(allPackages);
    return allPackages;
  }

  @NotNull
  private Set<PsiPackage> getDefaultPsiPackages() {
    PsiFile file = getPsiElement().getContainingFile();
    if (file instanceof PsiClassOwner) {
      final String packageName = ((PsiClassOwner)file).getPackageName();
      final PsiManager manager = getPsiElement().getManager();
      final PsiPackage psiPackage = JavaPsiFacade.getInstance(manager.getProject()).findPackage(packageName);
      if (psiPackage != null) {
        return Collections.singleton(psiPackage);
      }
    }
    return Collections.emptySet();
  }

  private void addBasePackageClasses(Set<PsiPackage> importedResources) {
    final List<JamClassAttributeElement> basePackageClasses = getBasePackageClassAttribute();
    for (JamClassAttributeElement bpc : basePackageClasses) {
      PsiClass psiClass = bpc.getValue();
      if (psiClass != null) {
        final PsiDirectory containingDirectory = psiClass.getContainingFile().getContainingDirectory();

        if (containingDirectory != null) {
          final PsiPackage psiPackage = JavaDirectoryService.getInstance().getPackage(containingDirectory);
          if (psiPackage != null) {
            importedResources.add(psiPackage);
          }
        }
      }
    }
  }

  @NotNull
  protected List<JamClassAttributeElement> getBasePackageClassAttribute() {
    final JamClassAttributeMeta.Collection meta = getBasePackageClassMeta();

    return meta != null ? meta.getJam(getAnnotationRef()) : Collections.emptyList();
  }

  @Nullable
  protected abstract JamClassAttributeMeta.Collection getBasePackageClassMeta();

  private void addPackages(@NotNull Set<PsiPackage> importedResources,
                           @NotNull JamStringAttributeMeta.Collection<Collection<PsiPackage>> attrMeta) {
    for (JamStringAttributeElement<Collection<PsiPackage>> element : attrMeta.getJam(getAnnotationRef())) {
      if (element != null) {
        Collection<PsiPackage> psiPackages = element.getValue();
        if (psiPackages != null) {
          ContainerUtil.addAllNotNull(importedResources, psiPackages);
        }
      }
    }
  }

  @NotNull
  protected abstract JamAnnotationMeta getAnnotationMeta();

  @NotNull
  public abstract List<JamStringAttributeMeta.Collection<Collection<PsiPackage>>> getPackageJamAttributes();

  public boolean processPsiPackages(@NotNull Processor<Pair<PsiPackage, ? extends PsiElement>> processor) {
    List<JamStringAttributeMeta.Collection<Collection<PsiPackage>>> packageJamAttributes = getPackageJamAttributes();
    List<JamClassAttributeElement> basePackageClasses = getBasePackageClassAttribute();

    int packageDefiningElementsCount = basePackageClasses.size();
    for (JamStringAttributeMeta.Collection<Collection<PsiPackage>> packageMeta : packageJamAttributes) {
      packageDefiningElementsCount += getAnnotationMeta().getAttribute(getPsiElement(), packageMeta).size();
    }

    boolean useCurrentPackageForScan = packageDefiningElementsCount == 0;
    boolean useAnnotationAsElement = packageDefiningElementsCount == 1;
    PsiElement annotationElement = getAnnotationMeta().getAnnotation(getPsiElement());

    for (JamStringAttributeMeta.Collection<Collection<PsiPackage>> packageMeta : packageJamAttributes) {
      for (JamStringAttributeElement<Collection<PsiPackage>> element : getAnnotationMeta().getAttribute(getPsiElement(), packageMeta)) {
        if (element != null) {
          Collection<PsiPackage> psiPackages = element.getValue();
          if (psiPackages != null) {
            for (PsiPackage psiPackage : psiPackages) {
              final PsiElement identifyingElement =
                useAnnotationAsElement && annotationElement != null ? annotationElement : element.getPsiElement();
              if (!processor.process(Pair.create(psiPackage, identifyingElement == null ? psiPackage : identifyingElement))) {
                return false;
              }
            }
          }
        }
      }
    }

    for (JamClassAttributeElement bpc : basePackageClasses) {
      PsiClass psiClass = bpc.getValue();
      if (psiClass != null) {
        final PsiDirectory containingDirectory = psiClass.getContainingFile().getContainingDirectory();

        if (containingDirectory != null) {
          final PsiPackage psiPackage = JavaDirectoryService.getInstance().getPackage(containingDirectory);
          if (psiPackage != null) {
            if (!processor.process(Pair.create(psiPackage, useAnnotationAsElement ? annotationElement : bpc.getPsiElement()))) {
              return false;
            }
          }
        }
      }
    }

    if (useCurrentPackageForScan) {
      PsiFile file = getPsiElement().getContainingFile();
      if (file instanceof PsiClassOwner) {
        final String packageName = ((PsiClassOwner)file).getPackageName();
        final PsiManager manager = getPsiElement().getManager();
        final PsiPackage psiPackage = JavaPsiFacade.getInstance(manager.getProject()).findPackage(packageName);
        if (psiPackage != null) {
          if (!processor.process(Pair.create(psiPackage, annotationElement))) {
            return false;
          }
        }
      }
    }

    return true;
  }

  @Override
  public PsiElement getIdentifyingPsiElement() {
    return getAnnotation();
  }
}
