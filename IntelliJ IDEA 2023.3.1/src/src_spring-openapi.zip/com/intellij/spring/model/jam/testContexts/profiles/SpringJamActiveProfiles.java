// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.jam.testContexts.profiles;

import com.intellij.ide.presentation.Presentation;
import com.intellij.jam.JamCommonModelElement;
import com.intellij.jam.JamConverter;
import com.intellij.jam.JamStringAttributeElement;
import com.intellij.jam.reflect.JamAnnotationArchetype;
import com.intellij.jam.reflect.JamAnnotationMeta;
import com.intellij.jam.reflect.JamClassMeta;
import com.intellij.jam.reflect.JamStringAttributeMeta;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiMember;
import com.intellij.semantic.SemKey;
import com.intellij.spring.constants.SpringAnnotationsConstants;
import com.intellij.spring.constants.SpringCorePresentationConstants;
import com.intellij.spring.model.jam.profile.SpringJamProfile;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

import static com.intellij.jam.reflect.JamAttributeMeta.collectionString;

@Presentation(typeName = SpringCorePresentationConstants.ACTIVE_PROFILES)
public final class SpringJamActiveProfiles extends JamCommonModelElement<PsiMember> implements SpringActiveProfile {

  private final PsiElementRef<PsiAnnotation> myPsiAnnotation;

  public static final SemKey<JamAnnotationMeta> JAM_ANNO_META_KEY = ACTIVE_PROFILE_JAM_ANNOTATION_KEY.subKey("SpringJamActiveProfiles");
  private static final SemKey<SpringJamActiveProfiles> JAM_KEY = ACTIVE_PROFILE_JAM_KEY.subKey("SpringJamActiveProfiles");

  public static final JamClassMeta<SpringJamActiveProfiles> META = new JamClassMeta<>(null, SpringJamActiveProfiles::new, JAM_KEY);
  private static final JamConverter<String> PROFILE_CONVERTER = new SpringJamProfile.SpringProfileConverter("", false);
  private static final JamStringAttributeMeta.Collection<String> VALUE_ATTR_META =
    collectionString(VALUE_ATTR_NAME, PROFILE_CONVERTER);
  private static final JamStringAttributeMeta.Collection<String> PROFILES_ATTR_META =
    collectionString(PROFILES_ATTR_NAME, PROFILE_CONVERTER);

  private static final JamAnnotationArchetype ARCHETYPE =
    new JamAnnotationArchetype().addAttribute(VALUE_ATTR_META).addAttribute(PROFILES_ATTR_META);
  public static final JamAnnotationMeta ANNO_META = new JamAnnotationMeta(SpringAnnotationsConstants.ACTIVE_PROFILES, ARCHETYPE, JAM_ANNO_META_KEY);

  static {
    META.addAnnotation(ANNO_META);
  }

  private SpringJamActiveProfiles(@NotNull PsiElementRef<?> psiRef) {
    super(psiRef);

    PsiMember psiMember = (PsiMember)Objects.requireNonNull(psiRef.getPsiElement());
    myPsiAnnotation = ANNO_META.getAnnotationRef(psiMember);
  }

  @Override
  @NotNull
  public Set<String> getActiveProfiles() {
    Set<String> profiles = new LinkedHashSet<>();

    addProfiles(profiles, VALUE_ATTR_META);
    addProfiles(profiles, PROFILES_ATTR_META);

    return profiles;
  }

  private void addProfiles(@NotNull Set<String> profiles,
                           @NotNull JamStringAttributeMeta.Collection<String> attrMeta) {
    for (JamStringAttributeElement<String> element : ANNO_META.getAttribute(getPsiElement(), attrMeta)) {
      if (element != null) {
        final String value = element.getValue();
        if (StringUtil.isNotEmpty(value)) profiles.add(value);
      }
    }
  }

  @Override
  @Nullable
  public PsiAnnotation getAnnotation() {
    return myPsiAnnotation.getPsiElement();
  }
}
