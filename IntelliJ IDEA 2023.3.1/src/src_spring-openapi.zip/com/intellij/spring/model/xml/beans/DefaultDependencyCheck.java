// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Thu Nov 09 17:15:14 MSK 2006
// DTD/Schema  :    http://www.springframework.org/schema/beans

package com.intellij.spring.model.xml.beans;

import com.intellij.util.xml.NamedEnum;

/**
 * http://www.springframework.org/schema/beans:default-dependency-checkAttrType enumeration.
 */
public enum DefaultDependencyCheck implements NamedEnum {
  ALL("all"),
  NONE("none"),
  OBJECTS("objects"),
  SIMPLE("simple");

  private final String value;

  DefaultDependencyCheck(String value) {
    this.value = value;
  }

  @Override
  public String getValue() {
    return value;
  }

}
