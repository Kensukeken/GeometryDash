// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

// Generated on Thu Nov 09 17:15:14 MSK 2006
// DTD/Schema  :    http://www.springframework.org/schema/tx

package com.intellij.spring.model.xml.tx;

import com.intellij.util.xml.NamedEnum;

/**
 * updated: spring-tx-4.1.xsd
 */
public enum Mode implements NamedEnum {
  ASPECTJ("aspectj"),
  PROXY("proxy");

  private final String value;

  Mode(String value) { this.value = value; }

  @Override
  public String getValue() { return value; }

}
