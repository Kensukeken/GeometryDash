// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.model.xml;

import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.spring.model.BeanService;
import com.intellij.spring.model.DefaultSpringBeanQualifier;
import com.intellij.spring.model.SpringQualifier;
import com.intellij.spring.model.utils.SpringCommonUtils;
import com.intellij.spring.model.xml.beans.Beans;
import com.intellij.util.ArrayUtilRt;
import com.intellij.util.xml.DomReflectionUtil;
import com.intellij.util.xml.DomUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;

public abstract class DomSpringBeanImpl extends AbstractDomSpringBean implements DomSpringBean {
  /**
   * Use {@link BeanName} to provide custom bean name.
   * Overriding recommended when {@link #setName(String)} is also changed.
   * NB: do not use any resolving when overriding.
   *
   * @return Bean name.
   */
  @Override
  @SuppressWarnings("unchecked")
  @Nullable
  public String getBeanName() {
    final BeanName beanName = DomReflectionUtil.findAnnotationDFS(getClass(), BeanName.class);
    if (beanName == null) {
      return DomUtil.hasXml(getId()) ? getId().getRawText() : null;
    }

    final String value = beanName.value();
    if (!value.isEmpty()) {
      return value;
    }

    // we already check in indexing, but if model version is not incremented such errors might be introduced
    final Class<? extends BeanNameProvider> providerClass = beanName.provider();
    if (providerClass == BeanNameProvider.class) {
      throw new IllegalStateException("@BeanName: no value() given, provider() must be set" + getDomElementType());
    }

    return SpringCommonUtils.getBeanNameProvider(providerClass).getBeanName(this);
  }

  @Override
  public void setName(@NotNull String newName) {
    if (DomUtil.hasXml(getId())) {
      getId().setStringValue(newName);
    }
  }

  /**
   * @return Bean's class name.
   * @see BeanType
   */
  @Override
  @SuppressWarnings("unchecked")
  @Nullable
  public final String getClassName() {
    final BeanType beanType = DomReflectionUtil.findAnnotationDFS(getClass(), BeanType.class);
    if (beanType == null) {
      return null;
    }

    final String value = beanType.value();
    if (!value.isEmpty()) {
      return value;
    }

    // we already check in indexing, but if model version is not incremented such errors might be introduced
    final Class<? extends BeanTypeProvider> providerClass = beanType.provider();
    if (providerClass == BeanTypeProvider.class) {
      throw new IllegalStateException("@BeanType: no value() given, provider() must be set" + getDomElementType());
    }

    return SpringCommonUtils.getBeanTypeProvider(providerClass).getBeanType(this);
  }

  @Override
  @NotNull
  public PsiFile getContainingFile() {
    return DomUtil.getFile(this);
  }

  @Override
  @Nullable
  public PsiElement getIdentifyingPsiElement() {
    if (!isValid()) return null;
    return BeanService.getInstance().convertToPsi(this);
  }

  @Override
  public String @NotNull [] getAliases() {
    return ArrayUtilRt.EMPTY_STRING_ARRAY;
  }

  @Override
  public PsiManager getPsiManager() {
    return PsiManager.getInstance(getManager().getProject());
  }

  @Override
  public Beans getBeansParent() {
    return DomUtil.getParentOfType(this, Beans.class, false);
  }

  @NotNull
  @Override
  public Collection<SpringQualifier> getSpringQualifiers() {
    return Collections.singleton(DefaultSpringBeanQualifier.create(this));
  }
}
