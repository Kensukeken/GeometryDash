// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.java;

import com.intellij.jam.JamStringAttributeElement;
import com.intellij.lang.xml.XMLLanguage;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Key;
import com.intellij.openapi.util.Pair;
import com.intellij.openapi.util.UserDataHolderEx;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.*;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider.Result;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.psi.util.PsiModificationTracker;
import com.intellij.spring.CommonSpringModel;
import com.intellij.spring.SpringModificationTrackersManager;
import com.intellij.spring.contexts.model.Direction;
import com.intellij.spring.contexts.model.LocalModel;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.SpringModelSearchParameters;
import com.intellij.spring.model.jam.JamPsiMemberSpringBean;
import com.intellij.spring.model.jam.JamSpringBeanPointer;
import com.intellij.spring.model.jam.javaConfig.ContextJavaBean;
import com.intellij.spring.model.utils.SpringBeanUtils;
import com.intellij.spring.model.utils.SpringConstructorArgUtils;
import com.intellij.spring.model.utils.SpringModelSearchers;
import com.intellij.spring.model.utils.SpringModelUtils;
import com.intellij.spring.model.xml.DomSpringBean;
import com.intellij.spring.model.xml.DomSpringBeanPointer;
import com.intellij.spring.model.xml.beans.*;
import com.intellij.util.CommonProcessors.CollectProcessor;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.containers.MultiMap;
import com.intellij.util.xml.DomManager;
import com.intellij.util.xml.DomUtil;
import com.intellij.util.xml.GenericAttributeValue;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Unmodifiable;

import java.util.*;
import java.util.function.Supplier;

import static com.intellij.spring.contexts.model.ModelTraverse.traverseModelPreventingRecursion;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptySet;

public final class SpringJavaClassInfo {
  private static final Key<CachedValue<MappedBeanInfo>> KEY = Key.create("Spring Java Class Info");

  private final CachedValue<MappedBeanInfo> myMappedInfo;

  public static @NotNull SpringJavaClassInfo getSpringJavaClassInfo(@NotNull PsiClass psiClass) {
    CachedValue<MappedBeanInfo> info = psiClass.getUserData(KEY);
    if (info == null) {
      info = createCachedValue(psiClass, psiClass.getProject());

      if (psiClass instanceof UserDataHolderEx) {
        info = ((UserDataHolderEx)psiClass).putUserDataIfAbsent(KEY, info);
      }
      else {
        psiClass.putUserData(KEY, info);
      }
    }
    return new SpringJavaClassInfo(info);
  }

  private SpringJavaClassInfo(@NotNull CachedValue<MappedBeanInfo> mappedInfo) {
    myMappedInfo = mappedInfo;
  }

  private static @NotNull CachedValue<MappedBeanInfo> createCachedValue(@NotNull PsiClass psiClass, @NotNull Project project) {
    return CachedValuesManager.getManager(project).createCachedValue(() -> {
      CommonSpringModel model = SpringModelUtils.getInstance().getPsiClassSpringModel(psiClass);
      SpringModelSearchParameters.BeanClass parameters = SpringModelSearchParameters.byClass(psiClass)
        .withInheritors()
        .effectiveBeanTypes();
      boolean isMapped = SpringModelSearchers.doesBeanExist(model, parameters);
      return Result.create(new MappedBeanInfo(psiClass, isMapped), getMappedDependencies(project));
    }, false);
  }

  private static void addStereotypeBeanMethod(@NotNull MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> map,
                                              @NotNull JamStringAttributeElement<PsiMethod> attributeElement,
                                              @NotNull SpringMethodType type) {
    PsiMethod psiMethod = attributeElement.getValue();
    if (psiMethod != null) {
      PsiAnnotationMemberValue identifyingElement = attributeElement.getPsiElement();
      if (identifyingElement != null) {
        map.putValue(psiMethod, Pair.create(identifyingElement.getParent(), type));
      }
    }
  }

  private static Collection<Object> getMappedDependencies(@NotNull Project project) {
    List<Object> dependencies = new ArrayList<>(
      Arrays.asList(SpringModificationTrackersManager.getInstance(project).getOuterModelsDependencies()));
    dependencies.add(PsiModificationTracker.getInstance(project).forLanguage(XMLLanguage.INSTANCE));
    return dependencies;
  }

  private static void addSpringBeanMethod(@NotNull MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> map,
                                          @NotNull List<PsiMethod> psiMethods,
                                          @NotNull SpringMethodType type,
                                          @NotNull GenericAttributeValue<PsiMethod> genericAttributeValue) {
    if (!DomUtil.hasXml(genericAttributeValue)) return;

    final PsiMethod psiMethod = genericAttributeValue.getValue();
    if (psiMethod != null && psiMethods.contains(psiMethod)) {
      map.putValue(psiMethod, Pair.create(genericAttributeValue.getXmlAttribute(), type));
    }
  }

  private static void addSpringBeanMethods(@NotNull MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> map,
                                           @NotNull List<PsiMethod> psiMethods,
                                           @NotNull SpringMethodType type,
                                           @NotNull GenericAttributeValue<Set<PsiMethod>> genericAttributeValue) {
    if (!DomUtil.hasXml(genericAttributeValue)) return;

    final Set<PsiMethod> methods = genericAttributeValue.getValue();
    if (methods != null) {
      for (PsiMethod psiMethod : methods) {
        if (psiMethods.contains(psiMethod)) {
          map.putValue(psiMethod, Pair.create(genericAttributeValue.getXmlAttribute(), type));
        }
      }
    }
  }

  public boolean isCalculatedMapped() {
    Supplier<MappedBeanInfo> getter = myMappedInfo.getUpToDateOrNull();
    return getter != null && getter.get().isMapped();
  }

  public boolean isResolved() {
    return myMappedInfo.hasUpToDateValue();
  }

  public MappedBeanInfo resolve() {
    return myMappedInfo.getValue();
  }

  public enum SpringMethodType {
    INIT("init"), DESTROY("destroy"), FACTORY("factory"), LOOKUP("lookup");
    private final String myName;

    SpringMethodType(String name) {
      myName = name;
    }

    public String getName() {
      return myName;
    }
  }

  private static final class MappedMembersInfo {
    final MultiMap<String, SpringPropertyDefinition> properties;
    final MultiMap<PsiMethod, SpringBeanPointer<?>> constructors;
    final MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> methods;

    MappedMembersInfo(MultiMap<String, SpringPropertyDefinition> properties,
                      MultiMap<PsiMethod, SpringBeanPointer<?>> constructors,
                      MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> methods) {
      this.properties = properties;
      this.constructors = constructors;
      this.methods = methods;
    }
  }

  public static final class MappedBeanInfo {
    private final PsiClass myPsiClass;
    private final boolean myMapped;
    private final CachedValue<Set<SpringBeanPointer<?>>> myBeans;
    private final CachedValue<MappedMembersInfo> myMembersInfo;

    public MappedBeanInfo(PsiClass aClass, boolean isMapped) {
      myPsiClass = aClass;
      myMapped = isMapped;

      myMembersInfo = CachedValuesManager.getManager(aClass.getProject()).createCachedValue(() -> {
        MappedMembersInfo info = new MappedMembersInfo(
          findMappedProperties(),
          findMappedConstructors(),
          findMappedMethods()
        );

        Project project = myPsiClass.getProject();
        return Result.create(info,
                             DomManager.getDomManager(project),
                             SpringModificationTrackersManager.getInstance(project).getOuterModelsModificationTracker(),
                             myPsiClass);
      });

      myBeans = CachedValuesManager.getManager(aClass.getProject()).createCachedValue(() -> {
        CommonSpringModel model = SpringModelUtils.getInstance().getPsiClassSpringModel(aClass);
        SpringModelSearchParameters.BeanClass parameters =
          SpringModelSearchParameters.byClass(aClass).withInheritors().effectiveBeanTypes();
        List<SpringBeanPointer<?>> byInheritance = SpringModelSearchers.findBeans(model, parameters);
        Set<SpringBeanPointer<?>> beans = byInheritance.size() <= 1 ? Set.copyOf(byInheritance) : new LinkedHashSet<>(byInheritance);
        return Result.create(beans, getBeanDependencies(aClass.getProject(), model));
      });
    }

    public boolean isMapped() {
      return myMapped;
    }

    public Set<SpringBeanPointer<?>> getBeans() {
      if (!myMapped) return emptySet();

      return myBeans.getValue();
    }

    public boolean isMappedProperty(PsiMethod method) {
      if (!myMapped) return false;

      String propertyName = StringUtil.getPropertyName(method.getName());
      if (propertyName == null) return false;
      return !getMappedProperties(propertyName).isEmpty();
    }

    public boolean isMappedConstructor(@NotNull PsiMethod method) {
      if (!myMapped) return false;
      if (!method.isConstructor()) return false;

      return getMappedConstructors().containsKey(method);
    }

    public boolean isMappedDomBean() {
      if (!myMapped) return false;

      return ContainerUtil.findInstance(myBeans.getValue(), DomSpringBeanPointer.class) != null;
    }

    @Unmodifiable
    public @NotNull List<DomSpringBeanPointer> getMappedDomBeans() {
      if (!myMapped) return emptyList();

      return ContainerUtil.findAll(myBeans.getValue(), DomSpringBeanPointer.class);
    }

    public boolean isStereotypeJavaBean() {
      if (!myMapped) return false;

      return ContainerUtil.findInstance(myBeans.getValue(), JamSpringBeanPointer.class) != null;
    }

    public @NotNull List<JamSpringBeanPointer> getStereotypeMappedBeans() {
      if (!myMapped) return emptyList();

      return ContainerUtil.findAll(myBeans.getValue(), JamSpringBeanPointer.class);
    }

    private static Collection<Object> getBeanDependencies(@NotNull Project project, @NotNull CommonSpringModel model) {
      Set<Object> dependencies = new LinkedHashSet<>();

      ContainerUtil.addAll(dependencies, SpringModificationTrackersManager.getInstance(project).getOuterModelsDependencies());

      CollectProcessor<PsiFile> configFilesProcessor = new CollectProcessor<>();
      traverseModelPreventingRecursion(model, true, m -> {
        if (m instanceof LocalModel<?>) {
          return ((LocalModel<?>)m).traverseConfigDependencies(configFilesProcessor);
        }
        return Direction.TRAVERSE;
      });
      ContainerUtil.addAll(dependencies, configFilesProcessor.getResults());

      return dependencies;
    }

    public boolean isAutowired() {
      if (!myMapped) return false;

      final List<DomSpringBeanPointer> pointers = getMappedDomBeans();
      for (DomSpringBeanPointer pointer : pointers) {
        final DomSpringBean springBean = pointer.getSpringBean();
        if (springBean instanceof SpringBean) {
          final Autowire autowire = ((SpringBean)springBean).getBeanAutowire();
          if (autowire.isAutowired()) {
            return true;
          }
        }
      }
      return false;
    }

    public @NotNull Set<Autowire> getAutowires() {
      if (!myMapped) return emptySet();

      Set<Autowire> autowires = EnumSet.noneOf(Autowire.class);
      for (DomSpringBeanPointer pointer : getMappedDomBeans()) {
        final DomSpringBean springBean = pointer.getSpringBean();
        if (springBean instanceof SpringBean) {
          final Autowire autowire = ((SpringBean)springBean).getBeanAutowire();
          if (autowire.isAutowired()) {
            autowires.add(autowire);
          }
        }
      }
      return autowires;
    }

    public @NotNull Collection<SpringPropertyDefinition> getMappedProperties(String propertyName) {
      if (!myMapped) return emptySet();

      MultiMap<String, SpringPropertyDefinition> value = getMappedProperties();
      if (value == null) {
        return emptyList();
      }
      return value.get(propertyName);
    }

    public @NotNull Collection<SpringBeanPointer<?>> getMappedConstructorDefinitions(@NotNull PsiMethod psiMethod) {
      if (!myMapped) return emptyList();

      MultiMap<PsiMethod, SpringBeanPointer<?>> value = getMappedConstructors();
      if (value == null) {
        return emptyList();
      }
      return value.get(psiMethod);
    }

    public @NotNull Collection<Pair<PsiElement, SpringMethodType>> getMethodTypes(@NotNull PsiMethod psiMethod) {
      // do not check myMapped, since XML factories may have mapped methods and not be mapped as beans

      MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> value = getMappedMethods();
      if (value == null) {
        return emptyList();
      }
      return value.get(psiMethod);
    }

    public MultiMap<String, SpringPropertyDefinition> getMappedProperties() {
      if (!myMapped) return MultiMap.empty();

      return myMembersInfo.getValue().properties;
    }

    private MultiMap<String, SpringPropertyDefinition> findMappedProperties() {
      List<DomSpringBeanPointer> list = getMappedDomBeans();
      MultiMap<String, SpringPropertyDefinition> map = MultiMap.create();
      for (DomSpringBeanPointer beanPointer : list) {
        if (!beanPointer.isValid()) continue;

        DomSpringBean bean = beanPointer.getSpringBean();
        if (bean instanceof SpringBean) {
          List<SpringPropertyDefinition> properties = ((SpringBean)bean).getAllProperties();
          for (SpringPropertyDefinition property : properties) {
            String propertyName = property.getPropertyName();
            if (propertyName != null) {
              map.putValue(propertyName, property);
            }
          }
        }
      }
      return map;
    }

    private MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> getMappedMethods() {
      // do not check myMapped, since XML factories may have mapped methods and not be mapped as beans

      return myMembersInfo.getValue().methods;
    }

    private MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> findMappedMethods() {
      List<PsiMethod> psiMethods = Arrays.asList(myPsiClass.getMethods());

      MultiMap<PsiMethod, Pair<PsiElement, SpringMethodType>> map = MultiMap.create();

      for (JamSpringBeanPointer pointer : getStereotypeMappedBeans()) {
        JamPsiMemberSpringBean<?> bean = pointer.getSpringBean();
        if (bean instanceof ContextJavaBean) {
          addStereotypeBeanMethod(map, ((ContextJavaBean)bean).getInitMethodAttributeElement(), SpringMethodType.INIT);
          addStereotypeBeanMethod(map, ((ContextJavaBean)bean).getDestroyMethodAttributeElement(), SpringMethodType.DESTROY);
        }
      }

      List<DomSpringBeanPointer> list = getMappedDomBeans();
      for (DomSpringBeanPointer beanPointer : list) {
        if (!beanPointer.isValid()) continue;

        DomSpringBean bean = beanPointer.getSpringBean();
        if (bean instanceof SpringBean springBean) {
          final Beans beans = DomUtil.getParentOfType(bean, Beans.class, false);
          if (beans != null) {
            addSpringBeanMethods(map, psiMethods, SpringMethodType.INIT, beans.getDefaultInitMethod());
            addSpringBeanMethods(map, psiMethods, SpringMethodType.DESTROY, beans.getDefaultDestroyMethod());
          }

          addSpringBeanMethod(map, psiMethods, SpringMethodType.INIT, springBean.getInitMethod());
          addSpringBeanMethod(map, psiMethods, SpringMethodType.DESTROY, springBean.getDestroyMethod());

          for (LookupMethod lookupMethod : springBean.getLookupMethods()) {
            addSpringBeanMethod(map, psiMethods, SpringMethodType.LOOKUP, lookupMethod.getName());
          }
        }
      }

      CollectProcessor<SpringBeanPointer<?>> processor = new CollectProcessor<>();
      SpringBeanUtils.getInstance().processXmlFactoryBeans(myPsiClass.getProject(), myPsiClass.getResolveScope(), processor);
      for (SpringBeanPointer<?> pointer : processor.getResults()) {
        if (!pointer.isValid()) continue;

        CommonSpringBean commonSpringBean = pointer.getSpringBean();
        if (commonSpringBean instanceof SpringBean springBean && commonSpringBean.isValid()) {
          GenericAttributeValue<PsiMethod> domFactoryMethod = springBean.getFactoryMethod();
          if (DomUtil.hasXml(domFactoryMethod)) {
            PsiMethod factoryMethod = domFactoryMethod.getValue();
            if (factoryMethod != null && psiMethods.contains(factoryMethod)) {
              addSpringBeanMethod(map, psiMethods, SpringMethodType.FACTORY, domFactoryMethod);
            }
          }
        }
      }

      return map;
    }

    public MultiMap<PsiMethod, SpringBeanPointer<?>> getMappedConstructors() {
      if (!myMapped) return MultiMap.empty();

      return myMembersInfo.getValue().constructors;
    }

    private MultiMap<PsiMethod, SpringBeanPointer<?>> findMappedConstructors() {
      List<DomSpringBeanPointer> list = getMappedDomBeans();
      MultiMap<PsiMethod, SpringBeanPointer<?>> map = MultiMap.create();
      for (DomSpringBeanPointer beanPointer : list) {
        if (!beanPointer.isValid()) continue;

        DomSpringBean bean = beanPointer.getSpringBean();
        if (bean instanceof SpringBean) {
          CommonSpringModel model = SpringModelUtils.getInstance().getPsiClassSpringModel(myPsiClass);
          PsiMethod constructor = SpringConstructorArgUtils.getInstance().getSpringBeanConstructor((SpringBean)bean, model);
          if (constructor != null) {
            map.putValue(constructor, beanPointer);
          }
        }
      }
      return map;
    }
  }
}
