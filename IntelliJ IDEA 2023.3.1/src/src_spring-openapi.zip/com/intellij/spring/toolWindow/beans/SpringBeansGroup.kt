package com.intellij.spring.toolWindow.beans

import com.intellij.openapi.module.Module
import com.intellij.spring.CommonSpringModel

data class SpringBeansGroup(val module: Module, val model: CommonSpringModel)