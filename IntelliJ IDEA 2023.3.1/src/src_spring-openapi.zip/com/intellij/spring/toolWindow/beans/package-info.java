@ApiStatus.Experimental
package com.intellij.spring.toolWindow.beans;

import org.jetbrains.annotations.ApiStatus;