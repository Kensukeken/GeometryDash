package com.intellij.spring.toolWindow.beans

import com.intellij.microservices.jvm.beans.BeanStereotype
import com.intellij.openapi.module.Module
import com.intellij.psi.PsiElement
import com.intellij.spring.model.SpringBeanPointer
import org.jetbrains.annotations.Nls
import java.util.function.Supplier
import javax.swing.Icon

abstract class SpringBeanStereotype(queryTag: String,
                                    icon: Icon?,
                                    localizedMessage: Supplier<@Nls String>) : BeanStereotype(queryTag, icon, localizedMessage) {
  abstract fun accept(pointer: SpringBeanPointer<*>, module: Module): Boolean

  open fun getDocumentationElement(pointer: SpringBeanPointer<*>): PsiElement? = pointer.springBean.identifyingPsiElement
}