package com.intellij.spring.toolWindow.beans

import com.intellij.spring.model.SpringBeanPointer

data class SpringBeanItem(val pointer: SpringBeanPointer<*>, val stereotype: SpringBeanStereotype?)