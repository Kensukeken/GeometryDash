package com.intellij.spring.search;

import com.intellij.openapi.module.Module;
import com.intellij.psi.search.GlobalSearchScope;
import org.jetbrains.annotations.NotNull;

public final class SpringGlobalSearchScopes {
  @NotNull
  public static GlobalSearchScope runtime(@NotNull Module module) {
    return runtime(module, true);
  }

  @NotNull
  public static GlobalSearchScope runtime(@NotNull Module module, final boolean includeTests) {
    return module.getModuleRuntimeScope(includeTests);
  }

  @NotNull
  public static GlobalSearchScope moduleWithDependencies(@NotNull Module module) {
    return GlobalSearchScope.moduleWithDependenciesScope(module);
  }
}
