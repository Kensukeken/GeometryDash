package com.intellij.spring.facet;

import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Set;

public interface SpringFileSetData {

  boolean isRemoved();

  @NotNull String getId();

  String getName();

  void setName(@NotNull final String name);

  @NotNull List<String> getFiles();

  void setActiveProfiles(@NotNull Set<String> activeProfiles);

  @NotNull Set<String> getActiveProfiles();

  Set<String> getDependencies();

  void addDependency(final String dep);

  void addFile(@NonNls String url);

  void removeFile(@NonNls String url);

  void setRemoved(final boolean removed);

  static SpringFileSetData create(@NonNls @NotNull String id, @NotNull String name) {
    return new SpringFileSetDataImpl(id, name);
  }

  static @NotNull SpringFileSetData create(SpringFileSetData original) {
    return SpringFileSetDataImpl.copy(original);
  }
}