// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.facet;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.util.SmartList;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;

final class SpringFileSetDataImpl implements SpringFileSetData {

  private final String myId;
  private String myName;
  private final List<String> myFiles = new SmartList<>();
  private final Set<String> myDependencies = new LinkedHashSet<>();
  private Set<String> myActiveProfiles = new LinkedHashSet<>();
  private boolean myRemoved;

  SpringFileSetDataImpl(@NonNls @NotNull String id, @NotNull String name) {
    myId = id;
    myName = name;
  }

  @Override
  public boolean isRemoved() {
    return myRemoved;
  }

  @Override
  @NotNull
  public String getId() {
    return myId;
  }

  @Override
  public String getName() {
    return myName;
  }

  @Override
  public void setName(@NotNull final String name) {
    myName = name;
  }

  @Override
  @NotNull
  public List<String> getFiles() {
    return myFiles;
  }

  @Override
  public void setActiveProfiles(@NotNull Set<String> activeProfiles) {
    myActiveProfiles = activeProfiles;
  }

  @Override
  @NotNull
  public Set<String> getActiveProfiles() {
    return myActiveProfiles;
  }

  @Override
  public Set<String> getDependencies() {
    return myDependencies;
  }

  @Override
  public void addDependency(final String dep) {
    myDependencies.add(dep);
  }

  @Override
  public void addFile(@NonNls String url) {
    if (!StringUtil.isEmptyOrSpaces(url)) {
      myFiles.add(url);
    }
  }

  @Override
  public void removeFile(@NonNls String url) {
    myFiles.remove(url);
  }

  @Override
  public void setRemoved(final boolean removed) {
    myRemoved = removed;
  }

  static SpringFileSetDataImpl copy(SpringFileSetData origin) {
    SpringFileSetDataImpl springFileSetData = new SpringFileSetDataImpl(origin.getId(), origin.getName());
    springFileSetData.setRemoved(origin.isRemoved());
    springFileSetData.getDependencies().addAll(origin.getDependencies());
    springFileSetData.getFiles().addAll(origin.getFiles());
    springFileSetData.getActiveProfiles().addAll(origin.getActiveProfiles());
    return springFileSetData;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    SpringFileSetData data = (SpringFileSetData)o;

    if (!myId.equals(data.getId())) return false;
    if (!Objects.equals(myName, data.getName())) return false;

    return true;
  }

  @Override
  public int hashCode() {
    int result = myId.hashCode();
    result = 31 * result + (myName != null ? myName.hashCode() : 0);
    return result;
  }
}
