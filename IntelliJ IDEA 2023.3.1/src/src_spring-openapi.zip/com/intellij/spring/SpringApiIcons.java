// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.spring;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class SpringApiIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, SpringApiIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon AbstractBean = load("icons/abstractBean.svg", 1762471437, 0);
  /** 16x16 */ public static final @NotNull Icon FactoryMethodBean = load("icons/factoryMethodBean.svg", -281304371, 0);
  /** 16x16 */ public static final @NotNull Icon FileSet = load("icons/fileSet.svg", -1345420285, 0);

  public static final class Gutter {
    /** 12x12 */ public static final @NotNull Icon FactoryMethodBean = load("icons/gutter/factoryMethodBean.svg", 623824631, 0);
    /** 12x12 */ public static final @NotNull Icon InfrastructureBean = load("icons/gutter/infrastructureBean.svg", 1907303386, 0);
    /** 12x12 */ public static final @NotNull Icon Listener = load("icons/gutter/listener.svg", -1637277841, 0);
    /** 12x12 */ public static final @NotNull Icon ParentBeanGutter = load("icons/gutter/parentBeanGutter.svg", 628506372, 2);
    /** 12x12 */ public static final @NotNull Icon Publisher = load("icons/gutter/publisher.svg", 793961869, 0);
    /** 12x12 */ public static final @NotNull Icon RequestMapping = load("icons/gutter/requestMapping.svg", 167807236, 0);
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredCandidates = load("icons/gutter/showAutowiredCandidates.svg", 439276724, 0);
    /** 12x12 */ public static final @NotNull Icon ShowAutowiredDependencies = load("icons/gutter/showAutowiredDependencies.svg", 275005125, 0);
    /** 12x12 */ public static final @NotNull Icon ShowCacheable = load("icons/gutter/showCacheable.svg", 995092988, 0);
    /** 12x12 */ public static final @NotNull Icon Spring = load("icons/gutter/spring.svg", -1909532309, 0);
    /** 12x12 */ public static final @NotNull Icon SpringBean = load("icons/gutter/springBean.svg", -1589112912, 0);
    /** 12x12 */ public static final @NotNull Icon SpringBeanMethod = load("icons/gutter/springBeanMethod.svg", -1635110211, 0);
    /** 12x12 */ public static final @NotNull Icon SpringConfig = load("icons/gutter/springConfig.svg", 797803216, 0);
    /** 12x12 */ public static final @NotNull Icon SpringJavaBean = load("icons/gutter/springJavaBean.svg", 2095761669, 0);
    /** 12x12 */ public static final @NotNull Icon SpringProperty = load("icons/gutter/springProperty.svg", 175423560, 0);
    /** 12x12 */ public static final @NotNull Icon SpringScan = load("icons/gutter/springScan.svg", 1986666881, 0);
  }

  /** 16x16 */ public static final @NotNull Icon ImplicitBean = load("icons/implicitBean.svg", -885940256, 0);
  /** 16x16 */ public static final @NotNull Icon InfrastructureBean = load("icons/infrastructureBean.svg", -233065531, 0);
  /** 16x16 */ public static final @NotNull Icon Listener = load("icons/listener.svg", -2011548643, 0);
  /** 16x16 */ public static final @NotNull Icon PrototypeBean = load("icons/prototypeBean.svg", -1404885153, 0);
  /** 16x16 */ public static final @NotNull Icon RequestMapping = load("icons/RequestMapping.svg", -1820952113, 0);
  /** 16x16 */ public static final @NotNull Icon ShowAutowiredDependencies = load("icons/showAutowiredDependencies.svg", -1448657617, 0);
  /** 16x16 */ public static final @NotNull Icon ShowCacheable = load("icons/showCacheable.svg", -2043016367, 0);
  /** 16x16 */ public static final @NotNull Icon Spring = load("icons/spring.svg", -672401873, 0);
  /** 16x16 */ public static final @NotNull Icon SpringBean = load("icons/springBean.svg", -80547400, 0);
  /** 16x16 */ public static final @NotNull Icon SpringConfig = load("icons/springConfig.svg", 868249439, 0);
  /** 16x16 */ public static final @NotNull Icon SpringJavaBean = load("icons/springJavaBean.svg", -306463081, 0);
  /** 16x16 */ public static final @NotNull Icon SpringJavaConfig = load("icons/springJavaConfig.svg", 321667440, 0);
  /** 16x16 */ public static final @NotNull Icon SpringProfile = load("icons/SpringProfile.svg", 741239424, 0);
  /** 16x16 */ public static final @NotNull Icon SpringProperty = load("icons/springProperty.svg", 868672604, 0);
  /** 13x13 */ public static final @NotNull Icon SpringToolWindow = load("icons/springToolWindow.svg", 1683336173, 2);
  /** 16x16 */ public static final @NotNull Icon SpringWeb = load("icons/SpringWeb.svg", -1042383949, 0);
}
