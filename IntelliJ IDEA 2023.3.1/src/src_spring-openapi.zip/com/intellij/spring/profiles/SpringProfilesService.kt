package com.intellij.spring.profiles

import com.intellij.openapi.components.service
import com.intellij.openapi.module.Module
import com.intellij.openapi.project.Project

interface SpringProfilesService {
  companion object {
    @JvmStatic
    fun getInstance(project: Project): SpringProfilesService = project.service()
  }

  fun setActiveProfiles(module: Module, activeProfiles: Set<String>)

  fun getActiveProfiles(module: Module): Set<String>
}