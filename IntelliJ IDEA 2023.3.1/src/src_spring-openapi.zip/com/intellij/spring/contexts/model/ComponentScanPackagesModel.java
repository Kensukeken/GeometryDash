// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.contexts.model;

import com.intellij.jam.JamService;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.NotNullLazyValue;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.PackageScope;
import com.intellij.psi.util.PsiModificationTracker;
import com.intellij.spring.model.BeanService;
import com.intellij.spring.model.CommonSpringBean;
import com.intellij.spring.model.SpringBeanPointer;
import com.intellij.spring.model.SpringQualifier;
import com.intellij.spring.model.jam.JamPsiMemberSpringBean;
import com.intellij.spring.model.jam.SpringJamModel;
import com.intellij.spring.model.jam.javaConfig.ImplicitlyRegisteredBeansProvider;
import com.intellij.spring.model.jam.javaConfig.SpringJavaBean;
import com.intellij.spring.model.jam.stereotype.SpringStereotypeElement;
import com.intellij.spring.model.jam.utils.SpringJamUtils;
import com.intellij.spring.model.utils.SpringProfileUtils;
import com.intellij.spring.search.SpringGlobalSearchScopes;
import com.intellij.util.NotNullFunction;
import com.intellij.util.SmartList;
import com.intellij.util.containers.ConcurrentFactoryMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.TestOnly;

import java.util.*;

public class ComponentScanPackagesModel extends CacheableCommonSpringModel {

  private final NotNullLazyValue<? extends Set<PsiPackage>> myPackages;
  private volatile Collection<SpringBeanPointer<?>> myScannedBeans;
  private final Map<SpringQualifier, List<SpringBeanPointer<?>>> myLocalBeansByQualifier;
  protected final boolean includeTests;

  @NotNull
  private final Module myModule;

  public ComponentScanPackagesModel(@NotNull NotNullLazyValue<? extends Set<PsiPackage>> packages, @NotNull Module module, boolean includeTests) {
    myPackages = packages;
    myModule = module;
    myLocalBeansByQualifier = ConcurrentFactoryMap.createMap(key -> findLocalBeansByQualifier(this, key));
    this.includeTests = includeTests;
  }

  @Override
  public Collection<SpringBeanPointer<?>> getLocalBeans() {
    return myScannedBeans == null ? myScannedBeans = calculateLocalBeans(includeTests) : myScannedBeans;
  }

  protected final Collection<SpringBeanPointer<?>> calculateLocalBeans(boolean includeTests) {
    Collection<SpringBeanPointer<?>> pointers = calculateScannedBeans(includeTests);

    Set<CommonSpringBean> javaBeans = new LinkedHashSet<>();
    for (SpringBeanPointer<?> pointer : pointers) {
      CommonSpringBean springBean = pointer.getSpringBean();
      if (springBean instanceof SpringStereotypeElement stereotypeElement) {
        PsiClass psiClass = stereotypeElement.getPsiElement();
        if (JamService.getJamService(psiClass.getProject())
              .getJamElement(JamPsiMemberSpringBean.PSI_MEMBER_SPRING_BEAN_JAM_KEY, psiClass) != null) {
          continue;
        }
        for (SpringJavaBean springJavaBean : stereotypeElement.getBeans()) {
          javaBeans.add(springJavaBean);
          if (springJavaBean instanceof ImplicitlyRegisteredBeansProvider) {
            javaBeans.addAll(((ImplicitlyRegisteredBeansProvider)springJavaBean).getImplicitlyRegistered());
          }
        }
      }
    }

    Set<SpringBeanPointer<?>> beans = new LinkedHashSet<>();
    beans.addAll(pointers);
    beans.addAll(BeanService.getInstance().mapSpringBeans(javaBeans));

    return beans;
  }

  protected Collection<SpringBeanPointer<?>> calculateScannedBeans(boolean includeTests) {
    return getScannedComponents(ComponentScanSearchContext.create(myPackages.getValue(), getModule()).profiles(getActiveProfiles()).includeTests(includeTests));
  }

  public static Collection<SpringBeanPointer<?>> getScannedComponents(@NotNull ComponentScanSearchContext context) {
    return BeanService.getInstance()
      .mapSpringBeans(getScannedComponents(scope -> SpringJamModel.getModel(context.getModule()).getStereotypeComponents(scope), context));
  }

  public static <T extends SpringStereotypeElement> List<CommonSpringBean> getScannedComponents(@NotNull NotNullFunction<? super GlobalSearchScope, ? extends List<T>> components,
                                                                                                @NotNull ComponentScanSearchContext context) {
    if (context.getModule().isDisposed() || context.getPackages().isEmpty()) return new SmartList<>();

    assertDefaultPackagesInTests(context.getPackages());

    final GlobalSearchScope effectiveSearchScope = getEffectiveScanScope(context);

    final List<T> allPointers = components.fun(effectiveSearchScope);

    Set<CommonSpringBean> filteredBeans =
      SpringJamUtils.getInstance().filterComponentScannedStereotypes(context.getModule(), allPointers, context.getPackages(),
                                                                     context.isUseDefaultFilters(),
                                                                     context.getExcludeContextFilters(), context.getIncludeContextFilters());

    return SpringProfileUtils.filterBeansInActiveProfiles(filteredBeans, context.getProfiles());
  }

  private static void assertDefaultPackagesInTests(@NotNull Set<PsiPackage> packages) {
    for (PsiPackage psiPackage : packages) {
      if (psiPackage.getQualifiedName().isEmpty() && ApplicationManager.getApplication().isUnitTestMode() &&
          !ourAllowDefaultPackageForTests) {
        throw new IllegalArgumentException("Do not use component-scan with <default> package in tests");
      }
    }
  }

  @NotNull
  private static GlobalSearchScope getEffectiveScanScope(@NotNull ComponentScanSearchContext context) {
    GlobalSearchScope[] scopes = context.getPackages().stream()
      .map(psiPackage -> PackageScope.packageScope(psiPackage, true))
      .toArray(GlobalSearchScope[]::new);

    return SpringGlobalSearchScopes.runtime(context.getModule(), context.isIncludeTests()).intersectWith(GlobalSearchScope.union(scopes));
  }

  private static boolean ourAllowDefaultPackageForTests = false;

  /**
   * Override assertion to use default package in tests.
   * This is disabled by default to avoid performance problems.
   */
  @TestOnly
  public static void setAllowDefaultPackageForTests(boolean value) {
    ourAllowDefaultPackageForTests = value;
  }

  @NotNull
  @Override
  public Module getModule() {
    return myModule;
  }

  @Override
  protected Collection<Object> getCachingProcessorsDependencies() {
    return Collections.singleton(PsiModificationTracker.MODIFICATION_COUNT);
  }

  @NotNull
  @Override
  public List<SpringBeanPointer<?>> findQualified(@NotNull SpringQualifier qualifier) {
    return myLocalBeansByQualifier.get(qualifier);
  }
}
