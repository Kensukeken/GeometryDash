/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring.contexts.model;

import com.intellij.openapi.module.Module;
import com.intellij.psi.xml.XmlFile;
import com.intellij.spring.facet.SpringFileSet;
import com.intellij.spring.model.xml.beans.Beans;
import com.intellij.util.xml.DomFileElement;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

/**
 * @author Yann C&eacute;bron
 */
public abstract class XmlSpringModel extends SpringModel {

  protected XmlSpringModel(@NotNull Module module, SpringFileSet fileSet) {
    super(module, fileSet);
  }

  public abstract Set<LocalXmlModel> getLocalSpringModels();

  @NotNull
  public abstract Set<XmlFile> getXmlConfigFiles();

  public abstract Set<DomFileElement<Beans>> getLocalModelsRoots();

  @SuppressWarnings("ConstantConditions")
  @NotNull
  @Override
  public Module getModule() {
    return super.getModule();
  }
}
