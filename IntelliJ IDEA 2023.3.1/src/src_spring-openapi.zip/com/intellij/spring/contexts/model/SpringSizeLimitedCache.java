// Copyright 2000-2021 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.contexts.model;

import com.intellij.openapi.util.Condition;
import it.unimi.dsi.fastutil.objects.Object2ObjectLinkedOpenHashMap;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class SpringSizeLimitedCache<K, V> {
  protected final Object2ObjectLinkedOpenHashMap<K, V> myQueue;
  private @NotNull final Condition<? super K> myKeyValidityCheck;
  private final int myMaxQueueSize;
  private final Object myLock = new Object();

  protected SpringSizeLimitedCache(final int maxQueueSize, @NotNull Condition<? super K> keyValidityCheck) {
    //noinspection SSBasedInspection
    myQueue = new Object2ObjectLinkedOpenHashMap<>(10) {
      @Override
      public V get(Object k) {
        return getAndMoveToLast((K)k);
      }

      @Override
      public V put(K k, V v) {
        return putAndMoveToLast(k, v);
      }
    };
    myKeyValidityCheck = keyValidityCheck;
    myMaxQueueSize = maxQueueSize;
  }

  @Nullable
  protected V getCachedValue(K key) {
    V value;
    synchronized (myLock) {
      value = myQueue.getAndMoveToLast(key);
    }
    return value;
  }

  @NotNull
  protected abstract V createValue(K key);

  @NotNull
  public V get(K key) {
    V value = getCachedValue(key);
    if (value != null) {
      return value;
    }

    final V newValue = createValue(key);
    synchronized (myLock) {
      if (myQueue.size() >= myMaxQueueSize) {
        if (containsInvalidKeys()) {
          myQueue.clear();
        }
        else {
          V val = myQueue.removeFirst();
          if (val == null) {
            myQueue.clear();
          }
        }
      }
      myQueue.putAndMoveToLast(key, newValue);
    }

    return newValue;
  }

  private boolean containsInvalidKeys() {
    for (K k : myQueue.keySet()) {
      if (!myKeyValidityCheck.value(k)) {
        return true;
      }
    }
    return false;
  }
}
