@file:JvmName("ModelTraverse")

package com.intellij.spring.contexts.model

import com.intellij.openapi.progress.ProgressManager
import com.intellij.openapi.util.RecursionManager
import com.intellij.spring.CommonSpringModel
import java.util.function.Function

enum class Direction {
  /**
   * Traverse related models of the currently processed model
   */
  TRAVERSE,

  /**
   * Move to the next model, without processing related models for the current model
   */
  PROCEED,

  /**
   * Stop processing
   */
  STOP
}

fun traverseModelPreventingRecursion(parentModel: CommonSpringModel,
                                     visitParentModel: Boolean,
                                     apply: Function<CommonSpringModel, Direction>): Boolean {
  val aBoolean = RecursionManager.doPreventingRecursion(parentModel, false) {
    traverseModel(parentModel, visitParentModel, apply)
  }
  return aBoolean ?: true
}

fun traverseModel(parentModel: CommonSpringModel,
                  visitParentModel: Boolean,
                  apply: Function<CommonSpringModel, Direction>): Boolean {
  val visited = HashSet<CommonSpringModel>()
  if (visitParentModel) {
    val direction = visitModel(parentModel, visited, apply)

    if (direction == Direction.STOP) return false
    if (direction == Direction.PROCEED) return true // do not ask for related models
  }

  return visitRelated(parentModel, visited, apply)
}

private fun visitRelated(parentModel: CommonSpringModel,
                         visited: MutableSet<CommonSpringModel>,
                         apply: Function<CommonSpringModel, Direction>): Boolean {
  val relatedModels = parentModel.relatedModels
  for (relatedModel in relatedModels) {
    val direction = visitModel(relatedModel, visited, apply)

    if (direction == Direction.PROCEED) continue
    if (direction == Direction.STOP) return false
    if (direction == Direction.TRAVERSE
        && !visitRelated(relatedModel, visited, apply)) {
      return false
    }
  }

  return true
}

private fun visitModel(model: CommonSpringModel,
                       visited: MutableSet<CommonSpringModel>,
                       traverse: Function<CommonSpringModel, Direction>): Any {
  if (visited.contains(model)) return true
  ProgressManager.checkCanceled()

  visited.add(model)

  return traverse.apply(model)
}