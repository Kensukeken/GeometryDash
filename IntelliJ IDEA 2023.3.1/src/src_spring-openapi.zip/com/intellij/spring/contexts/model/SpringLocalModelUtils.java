package com.intellij.spring.contexts.model;

import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiClassOwner;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiManager;
import com.intellij.psi.xml.XmlFile;
import com.intellij.spring.CommonSpringModel;
import com.intellij.spring.SpringLocalModelFactory;
import com.intellij.spring.model.utils.SpringCommonUtils;
import org.jetbrains.annotations.NotNull;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public final class SpringLocalModelUtils {

  @NotNull
  public static Set<CommonSpringModel> getLocalAnnotationModels(@NotNull Module module,
                                                                @NotNull Set<PsiClass> classes,
                                                                @NotNull Set<String> activeProfiles) {
    return classes.stream()
      .map(file -> SpringLocalModelFactory.getInstance().getOrCreateLocalAnnotationModel(file, module, activeProfiles))
      .filter(Objects::nonNull)
      .collect(Collectors.toSet());
  }

  @NotNull
  public static Set<XmlFile> getXmlFiles(Project project, @NotNull Set<VirtualFile> files) {
    Set<XmlFile> xmlConfigs = new HashSet<>();
    for (VirtualFile file : files) {
      if (file != null) {
        PsiFile psiFile = PsiManager.getInstance(project).findFile(file);
        if (psiFile instanceof XmlFile) {
          xmlConfigs.add((XmlFile)psiFile);
        }
      }
    }
    return xmlConfigs;
  }

  public static Set<PsiClass> getConfigClasses(@NotNull Project project, @NotNull Set<VirtualFile> files) {
    Set<PsiClass> configurations = new LinkedHashSet<>();
    for (VirtualFile file : files) {
      if (file != null) {
        PsiFile psiFile = PsiManager.getInstance(project).findFile(file);
        if (psiFile instanceof PsiClassOwner) {
          configurations.addAll(getConfigurationPsiClasses((PsiClassOwner)psiFile));
        }
      }
    }
    return configurations;
  }

  public static void addConfigurations(@NotNull Set<PsiClass> configurations, @NotNull PsiClass psiClass) {
    if (configurations.contains(psiClass)) return;

    configurations.add(psiClass);
    for (PsiClass innerClass : psiClass.getInnerClasses()) {
      if (SpringCommonUtils.isConfigurationOrMeta(innerClass)) {
        addConfigurations(configurations, innerClass);
      }
    }
  }

  public static Set<PsiClass> getConfigurationPsiClasses(PsiClassOwner psiClassOwner) {
    final Set<PsiClass> configurations = new LinkedHashSet<>();
    PsiClass[] classes = psiClassOwner.getClasses();
    if (classes.length == 1) {
      addConfigurations(configurations, classes[0]);
    }
    else {
      for (PsiClass psiClass : classes) {
        if (SpringCommonUtils.isConfigurationOrMeta(psiClass)) {
          addConfigurations(configurations, psiClass);
        }
      }
    }
    return configurations;
  }
}
