package com.intellij.spring.contexts.model;

import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiPackage;
import com.intellij.spring.model.jam.utils.filters.SpringContextFilter;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.Set;

public class ComponentScanSearchContext {
  private final Set<PsiPackage> packages;
  private final Module module;
  private @NotNull Set<SpringContextFilter.Exclude> excludeContextFilters = Collections.emptySet();
  private @NotNull Set<SpringContextFilter.Include> includeContextFilters = Collections.emptySet();
  private @Nullable Set<String> profiles = Collections.emptySet();
  private boolean useDefaultFilters = true;
  private boolean includeTests = true;


  public static ComponentScanSearchContext create(@NotNull Set<PsiPackage> packages,
                                                  @NotNull Module module) {
    return new ComponentScanSearchContext(packages, module);
  }

  private ComponentScanSearchContext(@NotNull Set<PsiPackage> packages,
                                     @NotNull Module module) {
    this.packages = packages;
    this.module = module;
  }

  public ComponentScanSearchContext excludeContextFilters(@NotNull Set<SpringContextFilter.Exclude> excludeContextFilters) {
    this.excludeContextFilters = excludeContextFilters;
    return this;
  }

  public ComponentScanSearchContext includeContextFilters(@NotNull Set<SpringContextFilter.Include> includeContextFilters) {
    this.includeContextFilters = includeContextFilters;
    return this;
  }

  public ComponentScanSearchContext profiles(@Nullable Set<String> profiles) {
    this.profiles = profiles;
    return this;
  }

  public ComponentScanSearchContext useDefaultFilters(boolean useDefaultFilters) {
    this.useDefaultFilters = useDefaultFilters;
    return this;
  }

  public ComponentScanSearchContext includeTests(boolean includeTests) {
    this.includeTests = includeTests;
    return this;
  }

  public Set<PsiPackage> getPackages() {
    return packages;
  }

  public Module getModule() {
    return module;
  }

  public @NotNull Set<SpringContextFilter.Exclude> getExcludeContextFilters() {
    return excludeContextFilters;
  }

  public @NotNull Set<SpringContextFilter.Include> getIncludeContextFilters() {
    return includeContextFilters;
  }

  public @Nullable Set<String> getProfiles() {
    return profiles;
  }

  public boolean isUseDefaultFilters() {
    return useDefaultFilters;
  }

  public boolean isIncludeTests() {
    return includeTests;
  }
}
