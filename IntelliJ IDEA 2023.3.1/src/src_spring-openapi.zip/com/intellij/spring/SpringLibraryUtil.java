/*
 * Copyright 2000-2018 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.spring;

import com.intellij.java.library.JavaLibraryUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.util.CachedValueProvider.Result;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.util.ArrayUtil;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.text.VersionComparatorUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.jar.Attributes;

import static com.intellij.spring.SpringLibraryUtil.SpringVersion.ANY;

public final class SpringLibraryUtil {

  private static final String SPRING_MAVEN = "org.springframework:spring-core";
  private static final Attributes.Name SPRING_VERSION = new Attributes.Name("Spring-Version");

  public enum SpringVersion {
    ANY("1.0"), // detectionClassFqn: SpringConstants.BEAN_FACTORY_CLASS
    V_2_5("2.5"), // detectionClassFqn: "org.springframework.core.PriorityOrdered"
    V_4_2("4.2"), // detectionClassFqn: "org.springframework.beans.AbstractNestablePropertyAccessor"
    V_4_3("4.3"), // detectionClassFqn: "org.springframework.core.MethodClassKey"
    V_5_0("5.0"), // detectionClassFqn: "org.springframework.core.ReactiveAdapter"
    V_5_1("5.1"), // detectionClassFqn: "org.springframework.core.codec.Hints"
    V_5_2("5.2"), // detectionClassFqn: "org.springframework.core.SortedProperties"
    V_6_0("6.0"); // detectionClassFqn: "org.springframework.aot.AotDetector"

    private final String myVersion;

    SpringVersion(String version) {
      myVersion = version;
    }

    boolean isAtLeast(SpringVersion reference) {
      if (reference == ANY) {
        return true;
      }

      return StringUtil.compareVersionNumbers(getVersion(), reference.getVersion()) >= 0;
    }

    String getVersion() {
      return myVersion;
    }
  }

  public static boolean hasSpringLibrary(@NotNull Project project) {
    return JavaLibraryUtil.hasLibraryJar(project, SPRING_MAVEN);
  }

  public static boolean hasSpringLibrary(@Nullable Module module) {
    return isAtLeastVersion(module, ANY);
  }

  public static boolean isAtLeastVersion(@Nullable Module module, SpringVersion version) {
    if (module == null) return false;

    if (!hasSpringLibrary(module.getProject())) return false;

    final SpringVersion cached = getCachedSpringVersion(module);
    return cached != null && cached.isAtLeast(version);
  }

  @Nullable
  private static SpringVersion getCachedSpringVersion(@NotNull final Module module) {
    if (module.isDisposed() || module.getProject().isDefault()) return null;

    return CachedValuesManager.getManager(module.getProject()).getCachedValue(module, () -> {
      String libraryVersion = JavaLibraryUtil.getLibraryVersion(module, SPRING_MAVEN, SPRING_VERSION);
      SpringVersion detected = libraryVersion == null ? null :
                               ContainerUtil.find(ArrayUtil.reverseArray(SpringVersion.values()),
                                                  version -> VersionComparatorUtil.compare(version.myVersion, libraryVersion) <= 0);
      return Result.create(detected, ProjectRootManager.getInstance(module.getProject()));
    });
  }
}
