package com.intellij.spring.references;

import com.intellij.microservices.url.UrlPath;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.util.TextRange;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiReference;
import com.intellij.psi.PsiReferenceBase;
import com.intellij.psi.util.PartiallyKnownStringKt;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class UrlPathReferenceSet {
  private final UrlPath myPath;
  private final PsiElement myElement;
  private final int myOffset;

  public UrlPathReferenceSet(@NotNull UrlPath path, @NotNull PsiElement psiElement, int offset) {
    myPath = path;
    myElement = psiElement;
    myOffset = offset;
  }

  public UrlPath getPath() {
    return myPath;
  }

  public PsiElement getElement() {
    return myElement;
  }

  @NotNull
  public List<UrlPath> getAllPaths(@NotNull Module module) {
    return Collections.emptyList();
  }

  public boolean isResolved() {
    final Module module = ModuleUtilCore.findModuleForPsiElement(getElement());
    return module != null && ContainerUtil.find(getAllPaths(module), path -> myPath.equals(path)) != null;
  }

  @NotNull
  public List<PsiReference> getReferences() {
    List<PsiReference> refs = new ArrayList<>();

    PartiallyKnownStringKt.splitToTextRanges(myPath.getPresentation(), "/", (sequence, s) -> (lastSplit, currentPosition) -> true)
      .iterator()
      .forEachRemaining(range -> {
        if (!range.isEmpty()) refs.add(createReference(this, myElement, range));
      });

    return refs;
  }

  @NotNull
  protected PsiReference createReference(@NotNull UrlPathReferenceSet set, @NotNull PsiElement element, @NotNull TextRange range) {
    return new UrlPathBasedReference(set, element, range.shiftRight(myOffset));
  }

  public static class UrlPathBasedReference extends PsiReferenceBase<PsiElement> {
    private final UrlPathReferenceSet mySet;

    protected UrlPathBasedReference(UrlPathReferenceSet set, PsiElement element, TextRange from) {
      super(element, from, true);
      mySet = set;
    }

    @Nullable
    @Override
    public PsiElement resolve() {
      return mySet.isResolved() ? getElement() : null;
    }

    public UrlPathReferenceSet getReferenceSet() {
      return mySet;
    }
  }
}
