package com.intellij.jam.model.util;

import com.intellij.codeInsight.MetaAnnotationUtil;
import com.intellij.openapi.module.Module;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

import static java.util.Collections.singleton;

public final class JamAnnotationUtil {
  private JamAnnotationUtil() {
  }

  public static Collection<String> getChildAnnotations(@Nullable Module module, @NotNull String annotation) {
    if (module == null || module.isDisposed()) {
      return singleton(annotation);
    }

    return MetaAnnotationUtil.getAnnotationNamesWithChildren(module, annotation, true);
  }
}
