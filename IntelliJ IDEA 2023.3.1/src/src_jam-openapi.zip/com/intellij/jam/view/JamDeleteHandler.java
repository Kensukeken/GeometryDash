/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam.view;

import com.intellij.jam.model.common.CommonModelElement;
import com.intellij.psi.PsiElement;
import com.intellij.util.xml.DomElement;

import java.util.Collection;

public abstract class JamDeleteHandler {

  public void addModelElements(final CommonModelElement element, final Collection<CommonModelElement> result) {
  }

  public void addPsiElements(final CommonModelElement element, final Collection<? super PsiElement> result) {
  }


  public boolean onChildrenDelete(final DomElement domElement) {
    return false;
  }

  public boolean onChildrenDelete(final PsiElement psiElement) {
    return false;
  }

}
