package com.intellij.jam;

import com.intellij.openapi.diagnostic.Logger;
import com.intellij.psi.PsiAnnotation;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiElementRef;
import com.intellij.psi.PsiModifierListOwner;
import com.intellij.util.ReflectionUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Constructor;
import java.util.function.Function;

import static com.intellij.util.ExceptionUtil.rethrowUnchecked;

final class DirectJamClassGenerator {
  private static final Logger LOG = Logger.getInstance(DirectJamClassGenerator.class);

  private static final MethodHandles.Lookup LOOKUP = MethodHandles.lookup();

  public static <T> @NotNull Function<PsiElementRef<?>, T> generateJamElementFactory(@NotNull Class<T> aClass) {
    try {
      return generateFromReflection(aClass);
    } catch (Exception e) {
      throw new IllegalStateException("Unable to build JAM factory for " + aClass);
    }
  }

  private static <T> @NotNull Function<PsiElementRef<?>, T> generateFromReflection(@NotNull Class<T> aClass) throws IllegalAccessException {
    Constructor<?> annoConstructor = null;
    Constructor<?> memberConstructor = null;
    Constructor<?> refConstructor = null;

    for (Constructor<?> constructor : aClass.getDeclaredConstructors()) {
      if (constructor.getParameterCount() == 0) {
        return new ZeroArgJamFactory<>(constructor);
      }
      else if (constructor.getParameterCount() == 1) {
        Class<?> argType = constructor.getParameterTypes()[0];
        if (ReflectionUtil.isAssignable(PsiAnnotation.class, argType)) {
          annoConstructor = constructor;
        }
        else if (ReflectionUtil.isAssignable(PsiModifierListOwner.class, argType)) {
          memberConstructor = constructor;
        }
        else if (PsiElementRef.class.equals(argType)) {
          refConstructor = constructor;
        }
      }
    }

    if (refConstructor != null) {
      return new RefJamFactory<>(refConstructor);
    }

    return new DispatchJamFactory<>(aClass, annoConstructor, memberConstructor);
  }

  private static final class ZeroArgJamFactory<T> implements Function<PsiElementRef<?>, T> {
    private final MethodHandle myConstructor;

    private ZeroArgJamFactory(Constructor<?> constructor) throws IllegalAccessException {
      myConstructor = LOOKUP.unreflectConstructor(constructor);
    }

    @SuppressWarnings("unchecked")
    @Override
    public T apply(PsiElementRef ref) {
      try {
        return (T)myConstructor.invoke();
      }
      catch (Throwable e) {
        rethrowUnchecked(e);

        throw new RuntimeException(e);
      }
    }
  }

  private static final class RefJamFactory<T> implements Function<PsiElementRef<?>, T> {
    private final MethodHandle myConstructor;

    private RefJamFactory(Constructor<?> constructor) throws IllegalAccessException {
      myConstructor = LOOKUP.unreflectConstructor(constructor);
    }

    @SuppressWarnings("unchecked")
    @Override
    public T apply(PsiElementRef ref) {
      try {
        return (T)myConstructor.invoke(ref);
      }
      catch (Throwable e) {
        rethrowUnchecked(e);

        throw new RuntimeException(e);
      }
    }
  }

  private static final class DispatchJamFactory<T> implements Function<PsiElementRef<?>, T> {
    private final Class<?> myClass;
    private final MethodHandle myAnnoConstructor;
    private final MethodHandle myMemberConstructor;

    private DispatchJamFactory(@NotNull Class<?> aClass,
                               @Nullable Constructor<?> annoConstructor,
                               @Nullable Constructor<?> memberConstructor) throws IllegalAccessException {
      myAnnoConstructor = annoConstructor != null ? LOOKUP.unreflectConstructor(annoConstructor) : null;
      myMemberConstructor = memberConstructor != null ? LOOKUP.unreflectConstructor(memberConstructor) : null;
      myClass = aClass;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T apply(PsiElementRef ref) {
      PsiElement element = ref.getPsiElement();
      LOG.assertTrue(element != null);

      if (element instanceof PsiAnnotation) {
        assert myAnnoConstructor != null : "No <init>(PsiAnnotation) in " + myClass;
        try {
          return (T)myAnnoConstructor.invoke(((PsiAnnotation)element));
        }
        catch (Throwable e) {
          throw new RuntimeException(e);
        }
      }

      assert myMemberConstructor != null : "No <init>(PsiModifierListOwner) in " + myClass;
      try {
        return (T)myMemberConstructor.invoke(element);
      }
      catch (Throwable e) {
        rethrowUnchecked(e);

        throw new RuntimeException(e);
      }
    }
  }
}