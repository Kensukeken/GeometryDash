package com.intellij.jam;

import com.intellij.java.library.JavaLibraryUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public final class JavaLibraryUtils {
  /**
   * @deprecated Use {@link com.intellij.java.library.JavaLibraryUtil} instead
   */
  @Deprecated
  public static boolean hasLibraryClass(@Nullable Project project, @NotNull String classFqn) {
    return JavaLibraryUtil.hasLibraryClass(project, classFqn);
  }

  /**
   * @deprecated Use {@link com.intellij.java.library.JavaLibraryUtil} instead
   */
  @Deprecated
  public static boolean hasLibraryClass(@Nullable Module module, @NotNull String classFqn) {
    return JavaLibraryUtil.hasLibraryClass(module, classFqn);
  }

  /**
   * @deprecated Use {@link com.intellij.java.library.JavaLibraryUtil} instead
   */
  @Deprecated
  public static boolean hasLibraryJar(@Nullable Project project, @NotNull String mavenCoords) {
    return JavaLibraryUtil.hasLibraryJar(project, mavenCoords);
  }

  /**
   * @deprecated Use {@link com.intellij.java.library.JavaLibraryUtil} instead
   */
  @Deprecated
  public static boolean hasLibraryJar(@Nullable Module module, @NotNull String mavenCoords) {
    return JavaLibraryUtil.hasLibraryJar(module, mavenCoords);
  }
}
