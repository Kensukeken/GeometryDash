/*
 * Copyright 2000-2013 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam.reflect;

import com.intellij.jam.JamElement;
import com.intellij.pom.PomTarget;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElementRef;
import com.intellij.semantic.SemKey;
import com.intellij.util.Consumer;
import com.intellij.util.PairConsumer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;

public final class JamClassMeta<Jam extends JamElement> extends JamMemberMeta<PsiClass, Jam> {
  /**
   * @deprecated Use {@link JamClassMeta#JamClassMeta(JamMemberArchetype, Class, Function)} instead.
   */
  @Deprecated(forRemoval = true)
  public JamClassMeta(@Nullable JamMemberArchetype<? super PsiClass, ? super Jam> parent,
                      @NotNull Class<Jam> jamClass) {
    super(parent, jamClass);
  }

  public JamClassMeta(@Nullable JamMemberArchetype<? super PsiClass, ? super Jam> parent,
                      @NotNull Class<Jam> jamClass,
                      @NotNull Function<PsiElementRef<?>, Jam> jamFactory) {
    super(parent, jamClass, jamFactory);
  }

  /**
   * @deprecated Use {@link JamClassMeta#JamClassMeta(Class, Function)} instead.
   */
  @Deprecated
  public JamClassMeta(@NotNull Class<Jam> jamClass) {
    super(jamClass);
  }

  public JamClassMeta(@NotNull Class<? extends Jam> jamClass, Function<PsiElementRef<?>, Jam> jamFactory) {
    super(jamClass, jamFactory);
  }

  /**
   * @deprecated Use {@link JamClassMeta#JamClassMeta(JamMemberArchetype, Function, SemKey)} instead.
   */
  @Deprecated
  public JamClassMeta(@Nullable JamMemberArchetype<? super PsiClass, ? super Jam> parent,
                      @NotNull Class<? extends Jam> jamClass,
                      @NotNull SemKey<Jam> jamKey) {
    super(parent, jamClass, jamKey);
  }

  public JamClassMeta(@Nullable JamMemberArchetype<? super PsiClass, ? super Jam> parent,
                      @NotNull Function<PsiElementRef<?>, Jam> jamFactory,
                      @NotNull SemKey<Jam> jamKey) {
    super(parent, jamFactory, jamKey);
  }

  @Override
  @NotNull
  public JamClassMeta<Jam> addChildrenQuery(JamChildrenQuery<?> childrenQuery) {
    super.addChildrenQuery(childrenQuery);
    return this;
  }

  @Override
  @NotNull
  public JamClassMeta<Jam> addPomTargetProducer(@NotNull PairConsumer<Jam, Consumer<PomTarget>> producer) {
    super.addPomTargetProducer(producer);
    return this;
  }

  public <T extends JamElement> JamChildrenQuery<T> addAnnotatedMethodsQuery(JamAnnotationMeta anno, JamMethodMeta<T> methodMeta) {
    JamChildrenQuery<T> query = JamChildrenQuery.annotatedMethods(anno, methodMeta.addAnnotation(anno));
    addChildrenQuery(query);
    return query;
  }

  public <T extends JamElement> JamChildrenQuery<T> addAnnotatedFieldsQuery(JamAnnotationMeta anno, final JamFieldMeta<T> fieldMeta) {
    JamChildrenQuery<T> query = JamChildrenQuery.annotatedFields(anno, fieldMeta.addAnnotation(anno));
    addChildrenQuery(query);
    return query;
  }

  @Override
  @NotNull
  public JamClassMeta<Jam> addAnnotation(JamAnnotationMeta meta) {
    super.addAnnotation(meta);
    return this;
  }

  @Override
  public JamClassMeta<Jam> addRootAnnotation(JamAnnotationMeta meta) {
    super.addRootAnnotation(meta);
    return this;
  }
}
