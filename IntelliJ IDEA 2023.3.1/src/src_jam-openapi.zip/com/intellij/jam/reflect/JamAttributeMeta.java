/*
 * Copyright 2000-2017 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.jam.reflect;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.jam.JamClassGenerator;
import com.intellij.jam.JamConverter;
import com.intellij.jam.JamElement;
import com.intellij.psi.*;
import com.intellij.psi.ref.AnnotationAttributeChildLink;
import com.intellij.util.NullableFunction;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.function.Function;

import static java.util.Objects.requireNonNull;

public abstract class JamAttributeMeta<JamType> {
  private final AnnotationAttributeChildLink myAttributeLink;

  protected JamAttributeMeta(@NonNls String attrName) {
    myAttributeLink = new AnnotationAttributeChildLink(attrName);
  }

  public AnnotationAttributeChildLink getAttributeLink() {
    return myAttributeLink;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;

    JamAttributeMeta<?> that = (JamAttributeMeta<?>)o;

    if (!myAttributeLink.equals(that.myAttributeLink)) return false;

    return true;
  }

  @Override
  public int hashCode() {
    return myAttributeLink.hashCode();
  }

  @NotNull
  public  <T> List<T> getCollectionJam(PsiElementRef<? extends PsiAnnotation> annoRef, NullableFunction<? super PsiAnnotationMemberValue, T> producer) {
    final PsiAnnotationMemberValue attr = getAttributeLink().findLinkedChild(annoRef.getPsiElement());
    return ContainerUtil.mapNotNull(AnnotationUtil.arrayAttributeValues(attr), producer);
  }

  @NotNull
  public abstract JamType getJam(PsiElementRef<? extends PsiAnnotation> anno);

  @NotNull
  public static JamStringAttributeMeta.Single<String> singleString(@NotNull @NonNls String attrName) {
    return singleString(attrName, JamConverter.DUMMY_CONVERTER);
  }

  @NotNull
  public static <T> JamStringAttributeMeta.Single<T> singleString(@NotNull @NonNls String attrName, JamConverter<T> converter) {
    return new JamStringAttributeMeta.Single<>(attrName, converter);
  }

  @NotNull
  public static <T extends Enum<T>> JamEnumAttributeMeta.Single<T> singleEnum(@NotNull @NonNls String attrName, Class<T> modelEnum) {
    return new JamEnumAttributeMeta.Single<>(attrName, modelEnum);
  }

  @NotNull
  public static JamStringAttributeMeta.Collection<String> collectionString(@NotNull @NonNls String attrName) {
    return collectionString(attrName, JamConverter.DUMMY_CONVERTER);
  }

  @NotNull
  public static <T> JamStringAttributeMeta.Collection<T> collectionString(String attrName, JamConverter<T> converter) {
    return new JamStringAttributeMeta.Collection<>(attrName, converter);
  }

  @Deprecated
  @NotNull
  public static <T extends JamElement> JamAnnotationAttributeMeta.Single<T> singleAnno(@NotNull @NonNls String attrName,
                                                                                       @NotNull JamAnnotationMeta annoMeta,
                                                                                       @NotNull Class<T> jamClass) {
    Function<PsiElementRef<?>, T> instantiator = JamClassGenerator.generateJamElementFactory(jamClass);
    return new JamAnnotationAttributeMeta.Single<>(attrName, annoMeta, instantiator);
  }

  @NotNull
  public static <T extends JamElement> JamAnnotationAttributeMeta.Single<T> singleAnno(@NotNull @NonNls String attrName,
                                                                                       @NotNull JamAnnotationMeta annoMeta,
                                                                                       @NotNull Function<PsiAnnotation, T> instantiator) {
    return new JamAnnotationAttributeMeta.Single<>(attrName, annoMeta,
                                                   ref -> instantiator.apply((PsiAnnotation)requireNonNull(ref.getPsiElement())));
  }

  @Deprecated
  @NotNull
  public static <T extends JamElement> JamAnnotationAttributeMeta.Collection<T> annoCollection(@NotNull @NonNls String attrName,
                                                                                               @NotNull JamAnnotationMeta annoMeta,
                                                                                               @NotNull Class<T> jamClass) {
    Function<PsiElementRef<?>, T> instantiator = JamClassGenerator.generateJamElementFactory(jamClass);
    return new JamAnnotationAttributeMeta.Collection<>(attrName, annoMeta, instantiator);
  }

  @NotNull
  public static <T extends JamElement> JamAnnotationAttributeMeta.Collection<T> annoCollection(@NotNull @NonNls String attrName,
                                                                                               @NotNull JamAnnotationMeta annoMeta,
                                                                                               @NotNull Function<PsiAnnotation, T> instantiator) {
    return new JamAnnotationAttributeMeta.Collection<>(attrName, annoMeta,
                                                       ref -> instantiator.apply((PsiAnnotation)requireNonNull(ref.getPsiElement())));
  }

  @NotNull
  public static JamClassAttributeMeta.Single singleClass(String attrName) {
    return new JamClassAttributeMeta.Single(attrName);
  }

  @NotNull
  public static JamClassAttributeMeta.Collection classCollection(String attrName) {
    return new JamClassAttributeMeta.Collection(attrName);
  }

  @NotNull
  public static JamTypeAttributeMeta.Single singleType(String attrName) {
    return new JamTypeAttributeMeta.Single(attrName);
  }

  @NotNull
  public static JamTypeAttributeMeta.Collection typeCollection(String attrName) {
    return new JamTypeAttributeMeta.Collection(attrName);
  }

  @NotNull
  public static JamBooleanAttributeMeta singleBoolean(@NotNull @NonNls String attrName, boolean defaultValue) {
    return new JamBooleanAttributeMeta(attrName, defaultValue);
  }

  @NotNull
  public static JamNumberAttributeMeta.Single<Integer> singleInteger(@NotNull @NonNls String attrName) {
    return new JamNumberAttributeMeta.Single<>(attrName, Integer.class);
  }

  protected static PsiAnnotationMemberValue addAttribute(PsiElementRef<? extends PsiAnnotation> annoRef, String valueText, final AnnotationAttributeChildLink link) {
    final PsiAnnotation annotation = annoRef.ensurePsiElementExists();
    final PsiElementFactory factory = JavaPsiFacade.getElementFactory(annotation.getProject());
    PsiAnnotationMemberValue literal = factory.createExpressionFromText(valueText, null);

    PsiAnnotationMemberValue attr = link.findLinkedChild(annotation);
    if (attr == null) {
      literal = (PsiAnnotationMemberValue)link.createChild(annotation).replace(literal);
    } else if (attr instanceof PsiArrayInitializerMemberValue) {
      literal = (PsiAnnotationMemberValue) attr.add(literal);
    } else {
      PsiAnnotationMemberValue arrayInit = factory.createAnnotationFromText("@Foo({})", null).findDeclaredAttributeValue(null);
      arrayInit.add(attr);
      arrayInit = annotation.setDeclaredAttributeValue(link.getAttributeName(), arrayInit);
      literal = (PsiAnnotationMemberValue)arrayInit.add(literal);
    }
    return literal;
  }
}
