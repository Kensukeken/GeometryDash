// Copyright 2000-2017 JetBrains s.r.o.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
package com.intellij.jam.reflect;

import com.intellij.codeInsight.AnnotationUtil;
import com.intellij.jam.JamElement;
import com.intellij.openapi.util.Key;
import com.intellij.patterns.ElementPattern;
import com.intellij.patterns.PsiJavaPatterns;
import com.intellij.psi.*;
import com.intellij.psi.util.CachedValue;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.psi.util.PsiModificationTracker;
import com.intellij.semantic.SemRegistrar;
import com.intellij.util.containers.ContainerUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.function.Function;

public abstract class JamChildrenQuery<Jam extends JamElement> {
  private final Key<CachedValue<List<Jam>>> myCacheKey;

  protected JamChildrenQuery() {
    myCacheKey = Key.create(getClass().getName());
  }

  protected JamChildrenQuery(@NonNls String debugName) {
    myCacheKey = Key.create(debugName);
  }

  @Nullable
  public abstract JamMemberMeta<?, ? extends Jam> getMeta(@NotNull PsiModifierListOwner member);

  protected abstract List<Jam> findChildren(@NotNull PsiMember parent);



  public final List<Jam> findChildren(@NotNull PsiElementRef<? extends PsiMember> parentRef) {
    final PsiMember parent = parentRef.getPsiElement();
    if (parent == null) {
      return Collections.emptyList();
    }

    CachedValue<List<Jam>> data = parent.getUserData(myCacheKey);
    if (data == null) {
      parent.putUserData(myCacheKey, data = CachedValuesManager.getManager(parent.getProject()).createCachedValue(
        () -> CachedValueProvider.Result.create(findChildren(parent), PsiModificationTracker.MODIFICATION_COUNT), false));
    }

    return data.getValue();
  }

  public static boolean isAnnotated(PsiModifierListOwner member, String fqn) {
    return AnnotationUtil.isAnnotated(member, fqn, 0);
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> composite(JamChildrenQuery<? extends Jam>... components) {
    return new CompositeQuery<>(components);
  }

  @Deprecated
  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedMethods(JamAnnotationMeta annotationMeta, final Class<? extends Jam> jamClass) {
    return annotatedMethods(annotationMeta, new JamMethodMeta<>(jamClass).addAnnotation(annotationMeta));
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedMethods(JamAnnotationMeta annotationMeta,
                                                                                Class<? extends Jam> jamClass,
                                                                                Function<PsiElementRef<?>, Jam> jamFactory) {
    return annotatedMethods(annotationMeta, new JamMethodMeta<>(jamClass, jamFactory).addAnnotation(annotationMeta));
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedMethods(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiMethod, ? extends Jam> methodMeta) {
    return new AnnotatedMethodsQuery<>(annotationMeta, methodMeta);
  }

  @Deprecated
  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedFields(JamAnnotationMeta annotationMeta, Class<? extends Jam> jamClass) {
    return annotatedFields(annotationMeta, new JamFieldMeta<>(jamClass).addAnnotation(annotationMeta));
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedFields(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiField, ? extends Jam> fieldMeta) {
    return new AnnotatedFieldsQuery<>(annotationMeta, fieldMeta);
  }

  @Deprecated
  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedParameters(JamAnnotationMeta annotationMeta, Class<? extends Jam> jamClass) {
    return annotatedParameters(annotationMeta, new JamParameterMeta<>(jamClass).addAnnotation(annotationMeta));
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedParameters(JamAnnotationMeta annotationMeta,
                                                                                   Class<? extends Jam> jamClass,
                                                                                   Function<PsiElementRef<?>, Jam> jamFactory) {
    return annotatedParameters(annotationMeta, new JamParameterMeta<>(jamClass, jamFactory).addAnnotation(annotationMeta));
  }

  public static <Jam extends JamElement> JamChildrenQuery<Jam> annotatedParameters(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiParameter, ? extends Jam> paramMeta) {
    return new AnnotatedParametersQuery<>(annotationMeta, paramMeta);
  }

  private static class AnnotatedMethodsQuery<Jam extends JamElement> extends JamAnnotatedChildrenQuery<Jam> implements JamRegisteringChildrenQuery {
    private final JamMemberMeta<? super PsiMethod, ? extends Jam> myMethodMeta;

    AnnotatedMethodsQuery(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiMethod, ? extends Jam> methodMeta) {
      super(annotationMeta);
      myMethodMeta = methodMeta;
    }

    @Override
    public JamMemberMeta<?, ? extends Jam> getMemberMeta(@NotNull PsiModifierListOwner member) {
      return member instanceof PsiMethod ? myMethodMeta : null;
    }

    @Override
    public PsiModifierListOwner[] getAllChildren(@NotNull PsiMember parent) {
      return ((PsiClass) parent).getMethods();
    }

    @Override
    public void registerSem(SemRegistrar registrar, ElementPattern<? extends PsiElement> parentPattern) {
      myMethodMeta.register(registrar, PsiJavaPatterns.psiMethod().withAnnotation(getAnnoName()).inClass(parentPattern));
    }
  }

  private static class AnnotatedFieldsQuery<Jam extends JamElement> extends JamAnnotatedChildrenQuery<Jam> implements JamRegisteringChildrenQuery{
    private final JamMemberMeta<? super PsiField, ? extends Jam> myFieldMeta;

    AnnotatedFieldsQuery(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiField, ? extends Jam> fieldMeta) {
      super(annotationMeta);
      myFieldMeta = fieldMeta;
    }

    @Override
    public JamMemberMeta<?, ? extends Jam> getMemberMeta(@NotNull PsiModifierListOwner member) {
      return member instanceof PsiField ? myFieldMeta : null;
    }

    @Override
    public PsiModifierListOwner[] getAllChildren(@NotNull PsiMember parent) {
      return ((PsiClass) parent).getFields();
    }

    @Override
    public void registerSem(SemRegistrar registrar, ElementPattern<? extends PsiElement> parentPattern) {
      myFieldMeta.register(registrar, PsiJavaPatterns.psiField().withAnnotation(getAnnoName()).inClass(parentPattern));
    }
  }

  private static class CompositeQuery<Jam extends JamElement> extends JamChildrenQuery<Jam> implements JamRegisteringChildrenQuery {
    private final JamChildrenQuery<? extends Jam>[] myComponents;

    CompositeQuery(JamChildrenQuery<? extends Jam>... components) {
      myComponents = components;
    }

    @Override
    public JamMemberMeta<?, ? extends Jam> getMeta(@NotNull PsiModifierListOwner member) {
      for (final JamChildrenQuery<? extends Jam> component : myComponents) {
        final JamMemberMeta<?, ? extends Jam> meta = component.getMeta(member);
        if (meta != null) {
          return meta;
        }
      }
      return null;
    }

    @Override
    public List<Jam> findChildren(@NotNull final PsiMember parent) {
      return ContainerUtil.concat(myComponents, jamChildrenQuery -> jamChildrenQuery.findChildren(parent));
    }

    @Override
    public void registerSem(SemRegistrar registrar, ElementPattern<? extends PsiElement> parentPattern) {
      for (final JamChildrenQuery<? extends Jam> component : myComponents) {
        if (component instanceof JamRegisteringChildrenQuery) {
          ((JamRegisteringChildrenQuery)component).registerSem(registrar, parentPattern);
        }
      }
    }
  }

  private static class AnnotatedParametersQuery<Jam extends JamElement> extends JamAnnotatedChildrenQuery<Jam> implements JamRegisteringChildrenQuery {
    private final JamMemberMeta<? super PsiParameter, ? extends Jam> myParamMeta;

    AnnotatedParametersQuery(JamAnnotationMeta annotationMeta, JamMemberMeta<? super PsiParameter, ? extends Jam> paramMeta) {
      super(annotationMeta);
      myParamMeta = paramMeta;
    }

    @Override
    @Nullable
    public JamMemberMeta<?, ? extends Jam> getMemberMeta(@NotNull PsiModifierListOwner member) {
      return member instanceof PsiParameter ? myParamMeta : null;
    }

    @Override
    public PsiModifierListOwner[] getAllChildren(@NotNull PsiMember parent) {
      return ((PsiMethod) parent).getParameterList().getParameters();
    }

    @Override
    public void registerSem(SemRegistrar registrar, ElementPattern<? extends PsiElement> parentPattern) {
      myParamMeta.register(registrar, PsiJavaPatterns.psiParameter().withAnnotation(getAnnoName()).withSuperParent(2, parentPattern));
    }

  }
}
