/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package icons;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class DatabaseIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, DatabaseIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon Access_method = load("icons/access_method.svg", 1470895168, 0);
  /** 16x16 */ public static final @NotNull Icon Adapter_script = load("icons/adapter_script.svg", -596946450, 0);
  /** 10x10 */ public static final @NotNull Icon AddHover = load("icons/add-hover.svg", 22167568, 2);
  /** 10x10 */ public static final @NotNull Icon Add = load("icons/add.svg", -125509341, 2);
  /** 16x16 */ public static final @NotNull Icon Aggregate = load("icons/aggregate.svg", 2071603851, 0);
  /** 16x16 */ public static final @NotNull Icon Argument = load("icons/argument.svg", -1038926529, 0);
  /** 16x16 */ public static final @NotNull Icon BinaryData = load("icons/binaryData.svg", -369145683, 2);
  /** 16x16 */ public static final @NotNull Icon BlueKey = load("icons/blueKey.svg", -1148505948, 0);
  /** 16x16 */ public static final @NotNull Icon BlueKeyTrigger = load("icons/blueKeyTrigger.svg", -264642028, 0);
  /** 16x16 */ public static final @NotNull Icon Body = load("icons/body.svg", -1101624460, 0);
  /** 16x16 */ public static final @NotNull Icon CheckConstraint = load("icons/checkConstraint.svg", 1624613843, 0);
  /** 16x16 */ public static final @NotNull Icon Col = load("icons/col.svg", -923015441, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKey = load("icons/colBlueKey.svg", -814475484, 0);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDot = load("icons/colBlueKeyDot.svg", 1459042540, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyDotIndex = load("icons/colBlueKeyDotIndex.svg", -1095856648, 2);
  /** 16x16 */ public static final @NotNull Icon ColBlueKeyIndex = load("icons/colBlueKeyIndex.svg", -1881720516, 0);
  /** 16x16 */ public static final @NotNull Icon ColDot = load("icons/colDot.svg", -1076260515, 2);
  /** 16x16 */ public static final @NotNull Icon ColDotIndex = load("icons/colDotIndex.svg", 615823406, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKey = load("icons/colGoldBlueKey.svg", 1960629324, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDot = load("icons/colGoldBlueKeyDot.svg", -1044450218, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyDotIndex = load("icons/colGoldBlueKeyDotIndex.svg", 2031119038, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldBlueKeyIndex = load("icons/colGoldBlueKeyIndex.svg", 1854233114, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKey = load("icons/colGoldKey.svg", -1609168235, 0);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDot = load("icons/colGoldKeyDot.svg", -875663285, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyDotIndex = load("icons/colGoldKeyDotIndex.svg", -1889664240, 2);
  /** 16x16 */ public static final @NotNull Icon ColGoldKeyIndex = load("icons/colGoldKeyIndex.svg", -448656503, 0);
  /** 16x16 */ public static final @NotNull Icon ColGreyKey = load("icons/colGreyKey.svg", -1211919682, 0);
  /** 16x16 */ public static final @NotNull Icon ColIndex = load("icons/colIndex.svg", -1719903453, 0);
  /** 16x16 */ public static final @NotNull Icon Collation = load("icons/collation.svg", -788307436, 0);
  /** 16x16 */ public static final @NotNull Icon Collection = load("icons/collection.svg", 2090571539, 0);
  /** 16x16 */ public static final @NotNull Icon CollectionKey = load("icons/collectionKey.svg", 1798429128, 0);
  /** 16x16 */ public static final @NotNull Icon CollectionType = load("icons/collectionType.svg", 535057273, 0);
  /** 16x16 */ public static final @NotNull Icon Commit = load("icons/commit.svg", 1634981977, 2);
  /** 16x16 */ public static final @NotNull Icon Connector = load("icons/connector.svg", 1856119873, 0);
  /** 16x16 */ public static final @NotNull Icon ConsoleRun = load("icons/consoleRun.svg", -1202204547, 2);
  /** 16x16 */ public static final @NotNull Icon ConsoleShowPlan = load("icons/consoleShowPlan.svg", -1855169745, 2);
  /** 16x16 */ public static final @NotNull Icon Constant = load("icons/constant.svg", -1355485592, 0);
  /** 16x16 */ public static final @NotNull Icon Database = load("icons/database.svg", 127168678, 0);
  /** 16x16 */ public static final @NotNull Icon DatabaseExternal = load("icons/databaseExternal.svg", 370825518, 2);
  /** 16x16 */ public static final @NotNull Icon DatabaseLink = load("icons/databaseLink.svg", -1308709366, 2);
  /** 16x16 */ public static final @NotNull Icon DatabaseObjGroup = load("icons/databaseObjGroup.svg", 1278741185, 0);
  /** 16x16 */ public static final @NotNull Icon DataFile = load("icons/dataFile.svg", -1768937524, 0);
  /** 16x16 */ public static final @NotNull Icon DataShare = load("icons/dataShare.svg", -428180101, 2);
  /** 16x16 */ public static final @NotNull Icon Dbms = load("icons/dbms.svg", 485941891, 0);
  /** 16x16 */ public static final @NotNull Icon DdlDataSourceOverlay = load("icons/ddlDataSourceOverlay.svg", 1287876227, 2);
  /** 16x16 */ public static final @NotNull Icon DdlDbms = load("icons/ddlDbms.svg", -522433367, 1);
  /** 16x16 */ public static final @NotNull Icon DefaultConstraint = load("icons/defaultConstraint.svg", -175488724, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue1 = load("icons/driverBlue1.svg", 541977924, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue2 = load("icons/driverBlue2.svg", 1144941500, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue3 = load("icons/driverBlue3.svg", 1050664539, 0);
  /** 16x16 */ public static final @NotNull Icon DriverBlue4 = load("icons/driverBlue4.svg", -1978606872, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen1 = load("icons/driverGreen1.svg", -329279889, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen2 = load("icons/driverGreen2.svg", 1576791710, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen3 = load("icons/driverGreen3.svg", 1047914015, 0);
  /** 16x16 */ public static final @NotNull Icon DriverGreen4 = load("icons/driverGreen4.svg", 1237024163, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink1 = load("icons/driverPink1.svg", 1661933206, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink2 = load("icons/driverPink2.svg", 29638582, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink3 = load("icons/driverPink3.svg", -35845690, 0);
  /** 16x16 */ public static final @NotNull Icon DriverPink4 = load("icons/driverPink4.svg", -177795961, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed1 = load("icons/driverRed1.svg", 1301400375, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed2 = load("icons/driverRed2.svg", -127329629, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed3 = load("icons/driverRed3.svg", 973279857, 0);
  /** 16x16 */ public static final @NotNull Icon DriverRed4 = load("icons/driverRed4.svg", -239561210, 0);
  /** 16x16 */ public static final @NotNull Icon EditData = load("icons/editData.svg", 1724969267, 0);
  /** 16x16 */ public static final @NotNull Icon EditorOutput = load("icons/editorOutput.svg", -1345700495, 2);
  /** 16x16 */ public static final @NotNull Icon Extension = load("icons/extension.svg", -834517105, 0);
  /** 14x14 */ public static final @NotNull Icon External_link_arrow = load("icons/external_link_arrow.svg", -1698491733, 0);
  /** 16x16 */ public static final @NotNull Icon External_schema_object = load("icons/external_schema_object.svg", -102467701, 2);
  /** 16x16 */ public static final @NotNull Icon FileFormat = load("icons/fileFormat.svg", 901564052, 0);

  public static final class FileTypes {
    /** 16x16 */ public static final @NotNull Icon CassandraFileType = load("icons/fileTypes/cassandraFileType.svg", -1770674348, 0);
    /** 16x16 */ public static final @NotNull Icon HiveFileType = load("icons/fileTypes/hiveFileType.svg", -1906841200, 0);
    /** 16x16 */ public static final @NotNull Icon RedisFileType = load("icons/fileTypes/redisFileType.svg", 1523507741, 0);
  }

  /** 16x16 */ public static final @NotNull Icon Foreign_datawrapper = load("icons/foreign_datawrapper.svg", -612772698, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_server = load("icons/foreign_server.svg", -2038913743, 2);
  /** 16x16 */ public static final @NotNull Icon Foreign_table = load("icons/foreign_table.svg", 1279733625, 2);
  /** 16x16 */ public static final @NotNull Icon Function = load("icons/function.svg", -1161587986, 1);
  /** 16x16 */ public static final @NotNull Icon FunctionExternal = load("icons/functionExternal.svg", -248618303, 2);
  /** 16x16 */ public static final @NotNull Icon FunctionRun = load("icons/functionRun.svg", -126535921, 1);
  /** 16x16 */ public static final @NotNull Icon FunnelGray = load("icons/funnel-gray.svg", -1425423157, 0);
  /** 16x16 */ public static final @NotNull Icon FunnelHover = load("icons/funnel-hover.svg", 417756890, 0);
  /** 16x16 */ public static final @NotNull Icon FunnelSelected = load("icons/funnel-selected.svg", 1439076776, 0);
  /** 16x16 */ public static final @NotNull Icon GoldKey = load("icons/goldKey.svg", -1152779188, 0);
  /** 16x16 */ public static final @NotNull Icon GoldKeyAlt = load("icons/goldKeyAlt.svg", 340396166, 0);
  /** 16x16 */ public static final @NotNull Icon GreenBugOverlap = load("icons/greenBugOverlap.svg", -1346527128, 2);
  /** 16x16 */ public static final @NotNull Icon HashCluster = load("icons/hashCluster.svg", 2038036403, 2);
  /** 16x16 */ public static final @NotNull Icon HashTable = load("icons/hashTable.svg", 1305527411, 0);
  /** 16x16 */ public static final @NotNull Icon HashTableKey = load("icons/hashTableKey.svg", 1052626199, 0);
  /** 16x16 */ public static final @NotNull Icon Index = load("icons/index.svg", 1203186003, 0);
  /** 16x16 */ public static final @NotNull Icon IndexCluster = load("icons/indexCluster.svg", 1016580734, 0);
  /** 16x16 */ public static final @NotNull Icon IndexFun = load("icons/indexFun.svg", 1175398537, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUnique = load("icons/indexUnique.svg", 818235936, 2);
  /** 16x16 */ public static final @NotNull Icon IndexUniqueFun = load("icons/indexUniqueFun.svg", -1467572469, 2);
  /** 16x16 */ public static final @NotNull Icon KillDataSourceProcess = load("icons/killDataSourceProcess.svg", 790626860, 2);
  /** 12x16 */ public static final @NotNull Icon Level1 = load("icons/level1.svg", 602318431, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_declared = load("icons/level1_declared.svg", -433016557, 2);
  /** 16x16 */ public static final @NotNull Icon Level1_details = load("icons/level1_details.svg", -1218499420, 0);
  /** 16x16 */ public static final @NotNull Icon Level1_inherited = load("icons/level1_inherited.svg", 447152801, 2);
  /** 12x16 */ public static final @NotNull Icon Level2 = load("icons/level2.svg", -1646763902, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_declared = load("icons/level2_declared.svg", 538449820, 2);
  /** 16x16 */ public static final @NotNull Icon Level2_details = load("icons/level2_details.svg", -1429070005, 0);
  /** 16x16 */ public static final @NotNull Icon Level2_inherited = load("icons/level2_inherited.svg", -1455885041, 2);
  /** 12x16 */ public static final @NotNull Icon Level3 = load("icons/level3.svg", -419270490, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_declared = load("icons/level3_declared.svg", 441339069, 2);
  /** 16x16 */ public static final @NotNull Icon Level3_details = load("icons/level3_details.svg", 198420475, 0);
  /** 16x16 */ public static final @NotNull Icon Level3_inherited = load("icons/level3_inherited.svg", -614290745, 2);
  /** 16x16 */ public static final @NotNull Icon LevelAuto = load("icons/levelAuto.svg", -1318798078, 2);
  /** 16x16 */ public static final @NotNull Icon List = load("icons/list.svg", -315558007, 0);
  /** 16x16 */ public static final @NotNull Icon ListKey = load("icons/listKey.svg", 1059234739, 0);
  /** 16x16 */ public static final @NotNull Icon Locked = load("icons/locked.svg", -1048665948, 0);
  /** 16x16 */ public static final @NotNull Icon Macro = load("icons/macro.svg", -1964381475, 1);
  /** 16x16 */ public static final @NotNull Icon ManageDataSources = load("icons/manageDataSources.svg", 1724014583, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedLog = load("icons/materializedLog.svg", 1210637103, 2);
  /** 16x16 */ public static final @NotNull Icon MaterializedView = load("icons/materializedView.svg", 1634158955, 2);
  /** 16x16 */ public static final @NotNull Icon MongoField = load("icons/mongoField.svg", -815626622, 0);
  /** 16x16 */ public static final @NotNull Icon MongoFieldGoldKey = load("icons/mongoFieldGoldKey.svg", 1211201910, 0);
  /** 16x16 */ public static final @NotNull Icon ObjectGroup = load("icons/objectGroup.svg", 1221437422, 0);
  /** 16x16 */ public static final @NotNull Icon Operator = load("icons/operator.svg", -1530464287, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorClass = load("icons/operatorClass.svg", 1988648989, 0);
  /** 16x16 */ public static final @NotNull Icon OperatorFamily = load("icons/operatorFamily.svg", 2054172939, 0);
  /** 16x16 */ public static final @NotNull Icon Package = load("icons/package.svg", 387074974, 0);
  /** 16x16 */ public static final @NotNull Icon Partition = load("icons/partition.svg", -217636952, 0);
  /** 16x16 */ public static final @NotNull Icon PreviewChanges = load("icons/previewChanges.svg", 1007592620, 2);
  /** 16x16 */ public static final @NotNull Icon Procedure = load("icons/procedure.svg", -1213779848, 0);
  /** 16x16 */ public static final @NotNull Icon ProcedureRun = load("icons/procedureRun.svg", 1985808286, 0);
  /** 16x16 */ public static final @NotNull Icon ProcGroup = load("icons/procGroup.svg", 314771273, 1);
  /** 16x16 */ public static final @NotNull Icon Projection = load("icons/projection.svg", 1147686884, 2);
  /** 16x16 */ public static final @NotNull Icon RefreshMaterializedView = load("icons/refreshMaterializedView.svg", 1628522469, 2);
  /** 16x16 */ public static final @NotNull Icon Role = load("icons/role.svg", -919637761, 0);
  /** 16x16 */ public static final @NotNull Icon RollbackDB = load("icons/rollbackDB.svg", -1327648289, 2);
  /** 16x16 */ public static final @NotNull Icon Routine = load("icons/routine.svg", -432950496, 0);
  /** 16x16 */ public static final @NotNull Icon Rule = load("icons/rule.svg", 342803038, 0);
  /** 16x16 */ public static final @NotNull Icon RunDatabaseScript = load("icons/runDatabaseScript.svg", -1433352406, 2);
  /** 16x16 */ public static final @NotNull Icon ScheduledEvent = load("icons/scheduledEvent.svg", -1397312179, 0);
  /** 16x16 */ public static final @NotNull Icon Schema = load("icons/schema.svg", 221387551, 0);
  /** 16x16 */ public static final @NotNull Icon Scripting_script = load("icons/scripting_script.svg", -266508188, 2);
  /** 16x16 */ public static final @NotNull Icon Sequence = load("icons/sequence.svg", -241631989, 0);
  /** 16x16 */ public static final @NotNull Icon ServerObjGroup = load("icons/serverObjGroup.svg", 586105632, 0);
  /** 16x16 */ public static final @NotNull Icon Set = load("icons/set.svg", 440036658, 0);
  /** 16x16 */ public static final @NotNull Icon SetKey = load("icons/setKey.svg", -677457010, 0);
  /** 16x16 */ public static final @NotNull Icon SortedSet = load("icons/sortedSet.svg", 1974310198, 0);
  /** 16x16 */ public static final @NotNull Icon SortedSetKey = load("icons/sortedSetKey.svg", 139228708, 0);
  /** 16x16 */ public static final @NotNull Icon Sql = load("icons/sql.svg", 829656185, 0);
  /** 16x16 */ public static final @NotNull Icon SqlDmlStatement = load("icons/sqlDmlStatement.svg", 1915666326, 0);
  /** 16x16 */ public static final @NotNull Icon SqlGroupByType = load("icons/sqlGroupByType.svg", -2095175239, 2);
  /** 16x16 */ public static final @NotNull Icon SqlOtherStatement = load("icons/sqlOtherStatement.svg", 23750452, 0);
  /** 16x16 */ public static final @NotNull Icon SqlSelectStatement = load("icons/sqlSelectStatement.svg", 521670063, 0);
  /** 16x16 */ public static final @NotNull Icon Stream = load("icons/stream.svg", -665460087, 0);
  /** 16x16 */ public static final @NotNull Icon StreamKey = load("icons/streamKey.svg", 1172887804, 0);
  /** 16x16 */ public static final @NotNull Icon String = load("icons/string.svg", -1149660421, 0);
  /** 16x16 */ public static final @NotNull Icon StringKey = load("icons/stringKey.svg", 1821673608, 0);
  /** 16x16 */ public static final @NotNull Icon SubmitDB = load("icons/submitDB.svg", 952665878, 2);
  /** 16x16 */ public static final @NotNull Icon SuspendScaled = load("icons/suspendScaled.svg", 1792973619, 2);
  /** 16x16 */ public static final @NotNull Icon Synonym = load("icons/synonym.svg", 2110535270, 2);
  /** 16x16 */ public static final @NotNull Icon Table = load("icons/table.svg", -860699544, 0);
  /** 16x16 */ public static final @NotNull Icon TableMapping = load("icons/tableMapping.svg", 177413207, 0);
  /** 16x16 */ public static final @NotNull Icon Tablespace = load("icons/tablespace.svg", -918331319, 0);
  /** 16x16 */ public static final @NotNull Icon TextAutoGenerate = load("icons/textAutoGenerate.svg", -1438079841, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowConsole = load("icons/toolWindowConsole.svg", 301750124, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowDatabase = load("icons/toolWindowDatabase.svg", -1613984147, 2);
  /** 13x13 */ public static final @NotNull Icon ToolwindowDatabaseChanges = load("icons/toolwindowDatabaseChanges.svg", 539472956, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowFiles = load("icons/toolWindowFiles.svg", 706509660, 2);
  /** 13x13 */ public static final @NotNull Icon ToolWindowSQLGenerator = load("icons/toolWindowSQLGenerator.svg", 1964656625, 2);
  /** 16x16 */ public static final @NotNull Icon Trigger = load("icons/trigger.svg", -1741398588, 0);
  /** 16x16 */ public static final @NotNull Icon TSQLt = load("icons/tSQLt.svg", 287822116, 2);
  /** 16x16 */ public static final @NotNull Icon Udf_script = load("icons/udf_script.svg", 859687222, 2);
  /** 16x16 */ public static final @NotNull Icon UnspecifiedCluster = load("icons/unspecifiedCluster.svg", -1727812768, 0);
  /** 16x16 */ public static final @NotNull Icon User_mapping = load("icons/user_mapping.svg", 1879253547, 0);
  /** 16x16 */ public static final @NotNull Icon UserDriver = load("icons/userDriver.svg", 1159078563, 0);
  /** 16x16 */ public static final @NotNull Icon UtPLSQL = load("icons/utPLSQL.svg", -1906123845, 0);
  /** 16x16 */ public static final @NotNull Icon ViewParameters = load("icons/viewParameters.svg", 427958033, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualColumn = load("icons/virtualColumn.svg", -1710313631, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualFolder = load("icons/virtualFolder.svg", 714075348, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualForeignKey = load("icons/virtualForeignKey.svg", 1770229227, 0);
  /** 16x16 */ public static final @NotNull Icon VirtualView = load("icons/virtualView.svg", 1341538990, 0);
  /** 16x16 */ public static final @NotNull Icon Warehouse = load("icons/warehouse.svg", -1032102704, 0);
}
