package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasBuiltinType<C extends DasBuiltinTypeClass<C>> extends DasType {
  @NotNull
  @Override
  C getTypeClass();

  @NotNull
  DasBuiltinType<C> withTypeClass(@NotNull C newTypeClass);
}