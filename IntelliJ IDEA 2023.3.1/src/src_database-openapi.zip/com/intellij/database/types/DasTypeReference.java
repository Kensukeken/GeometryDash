package com.intellij.database.types;

import com.intellij.database.model.DasObject;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface DasTypeReference extends DasType {
  @NotNull
  DasType resolve();

  @NotNull
  default DasType resolve(@Nullable DasObject context) {
    return resolve();
  }
}