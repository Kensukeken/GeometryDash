package com.intellij.database.types;

import org.jetbrains.annotations.NotNull;

public interface DasArrayType extends DasType {
  @NotNull
  DasType getComponentType();
}