package com.intellij.database.types;

public interface DasTableType extends DasType {
  int getColumnCount();

  String getColumnName(int i);

  DasType getColumnDasType(int i);

  default boolean isGeneratedColumn(int i) {
    return false;
  }
}