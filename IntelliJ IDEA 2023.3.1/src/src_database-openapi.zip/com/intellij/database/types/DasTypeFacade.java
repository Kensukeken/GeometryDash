package com.intellij.database.types;

import com.intellij.database.model.DasObject;
import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class DasTypeFacade {
  @NotNull
  public abstract DasBuiltinType<?> getUnknown();

  @NotNull
  public static DasTypeFacade getInstance() {
    return ApplicationManager.getApplication().getService(DasTypeFacade.class);
  }

  @NotNull
  public static DasType resolve(@NotNull DasType dasType, @Nullable DasObject context) {
    return dasType instanceof DasTypeReference ? ((DasTypeReference)dasType).resolve(context) : dasType;
  }
}