package com.intellij.database.types;

import com.intellij.database.model.DataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface DasTypeSystem {
  @NotNull
  DasType getIntType();

  @NotNull
  DasType getRealType();

  @NotNull
  DasType getBooleanType();

  @NotNull
  DasType getTimeType();

  @NotNull
  DasType getDateType();

  @NotNull
  DasType getDateTimeType();

  @NotNull
  DasType getTimestampType();

  @NotNull
  DasType getIntervalType();

  @NotNull
  DasType getStringType();

  @NotNull
  DasType getBytesType();

  @NotNull
  DasType getDefaultType(@NotNull DasTypeCategory category);

  @NotNull
  String getNormalizedTypeName(@NotNull String name);

  @NotNull
  DataType normalizeType(@NotNull DataType type);

  @Nullable
  String getDefaultTypeName(@NotNull DasTypeCategory cat);

  @NotNull
  String getTableTypeSpecification(@NotNull String args);

  @NotNull
  DasArrayType getArrayType(@NotNull DasType componentType);

  @NotNull
  DasArrayType getAnyArrayType();

  @NotNull
  DasArrayType createUnionArrayType(@NotNull List<DasType> variants);
}
