package com.intellij.database.model;

import com.intellij.openapi.util.NlsSafe;
import com.intellij.openapi.util.text.NaturalComparator;
import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Comparator;

/**
 * @author gregsh
 */
public interface DasObject extends DasNamed {
  Comparator<DasObject> NATURAL_COMPARATOR = Comparator.comparing(DasObject::getName, NaturalComparator.INSTANCE);

  @NlsSafe
  @Nullable
  default String getComment() {
    return null;
  }

  @Nullable
  default DasObject getDasParent() {
    return null;
  }

  @NotNull
  default JBIterable<? extends DasObject> getDasChildren(@Nullable ObjectKind kind) {
    return JBIterable.empty();
  }


  /**
   * @deprecated use {@link #getDasChildren(ObjectKind)} instead.
   */
  @Deprecated(forRemoval = true)
  @NotNull
  default <C extends DasObject> JBIterable<C> getDbChildren(@NotNull Class<C> clazz, @NotNull ObjectKind kind) {
    return getDasChildren(kind).filter(clazz);
  }
}
