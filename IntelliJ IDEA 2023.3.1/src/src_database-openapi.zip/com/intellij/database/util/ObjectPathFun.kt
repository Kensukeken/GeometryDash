@file:JvmName("ObjectPathFun")
package com.intellij.database.util

import com.intellij.database.model.ObjectKind
import com.intellij.database.model.ObjectKind.*


/**
 * Returns the nearest parent of this object one of the specified [kinds].
 * This object itself is never returned even when its kind is in the specified set.
 *
 * @param kinds kind of parent is needed.
 * @return found parent, or null if not found.
 * @see thisOrParentOfKind
 */
fun ObjectPath.parentOfKind(kinds: Set<ObjectKind>): ObjectPath? {
  var p: ObjectPath? = this.parent
  while (p != null) {
    if (p.kind in kinds) return p
    p = p.parent
  }
  return null
}

/**
 * Returns this or the nearest parent of this object one of the specified [kinds].
 *
 * @param kinds kind of parent is needed.
 * @return found parent, or null if not found.
 * @see parentOfKind
 */
fun ObjectPath.thisOrParentOfKind(kinds: Set<ObjectKind>): ObjectPath? =
  if (this.kind in kinds) this else this.parentOfKind(kinds)


/**
 * Determines the namespace which this path belongs to.
 * If this object is inside a schema -> the namespace is that schema,
 * if this object is inside a database -> the namespace is that schema,
 * otherwise it is in the server.
 * However, for schema and database, the namespace is itself.
 */
val ObjectPath.namespace: ObjectPathNamespace
  get() {
    return when(this.kind) {
      SCHEMA -> ObjectPathNamespace.InSchema(this)
      DATABASE -> ObjectPathNamespace.InDatabase(this)
      else -> {
        val p: ObjectPath? = this.parentOfKind(objectPathNamespaceKinds)
        when (p?.kind) {
          SCHEMA -> ObjectPathNamespace.InSchema(p!!)
          DATABASE -> ObjectPathNamespace.InDatabase(p!!)
          else -> ObjectPathNamespace.InServer
        }
      }
    }
  }

private val objectPathNamespaceKinds = setOf(ROOT, DATABASE, SCHEMA)


val ObjectPath.database: ObjectPath?
  get() = this.findParent(DATABASE, false)

val ObjectPath.databaseName: String?
  get() = this.database?.name

val ObjectPath.schema: ObjectPath?
  get() = this.findParent(SCHEMA, false)

val ObjectPath.schemaName: String?
  get() = this.schema?.name








