/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.database.util;

import com.intellij.database.model.DataType;
import com.intellij.openapi.util.text.StringUtil;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.math.BigDecimal;
import java.sql.Types;

public final class JdbcUtil {


  private JdbcUtil() {
  }

  public static boolean hasScaleAndPrecision(int jdbcType) {
    return switch (jdbcType) {
      case Types.DECIMAL, Types.NUMERIC, Types.FLOAT, Types.REAL, Types.DOUBLE -> true;
      default -> false;
    };
  }

  public static boolean hasLength(int jdbcType) {
    return switch (jdbcType) {
      case Types.CHAR, Types.VARCHAR, Types.LONGVARCHAR -> true;
      default -> false;
    };
  }

  @NotNull
  public static String getJdbcTypeName(@NotNull DataType dataType) {
    return getJdbcTypeName(dataType, true);
  }

  @NotNull
  public static String getJdbcTypeName(@NotNull final DataType dataType, boolean addLength) {
    final String sqlType = dataType.typeName;
    if (StringUtil.isNotEmpty(sqlType) && sqlType.indexOf('(') > -1) return sqlType;
    final int jdbcType = dataType.jdbcType;
    final String typeName = StringUtil.isNotEmpty(sqlType) ? sqlType : getJdbcTypeName(jdbcType);
    if (addLength) {
      boolean hasLength = hasLength(jdbcType);
      boolean hasScaleAndPrecision = !hasLength && hasScaleAndPrecision(jdbcType);
      int length = hasLength || hasScaleAndPrecision ? dataType.getLength() : -1;
      int scale = hasScaleAndPrecision ? dataType.getScale() : -1;
      if (hasLength && length > 0) {
        return typeName + "(" + length + ")";
      }
      else if (hasScaleAndPrecision && length > 0 && scale >= 0) {
        return typeName + "(" + length + ", " + scale + ")";
      }
    }
    return typeName;
  }

  /**
   * Returns JDBC type name string, i.e. "LONGVARCHAR" for Types.LONGVARCHAR.
   * @param jdbcType one of java.sql.Types.* constants
   * @return type name
   */
  @NotNull
  public static String getJdbcTypeName(final int jdbcType) {
    @NonNls final String result = switch (jdbcType) {
      case Types.BIT -> "BIT";
      case Types.TINYINT -> "TINYINT";
      case Types.SMALLINT -> "SMALLINT";
      case Types.INTEGER -> "INTEGER";
      case Types.BIGINT -> "BIGINT";
      case Types.FLOAT -> "FLOAT";
      case Types.REAL -> "REAL";
      case Types.DOUBLE -> "DOUBLE";
      case Types.NUMERIC -> "NUMERIC";
      case Types.DECIMAL -> "DECIMAL";
      case Types.CHAR -> "CHAR";
      case Types.VARCHAR -> "VARCHAR";
      case Types.LONGVARCHAR -> "LONGVARCHAR";
      case Types.DATE -> "DATE";
      case Types.TIME -> "TIME";
      case Types.TIMESTAMP -> "TIMESTAMP";
      case Types.BINARY -> "BINARY";
      case Types.VARBINARY -> "VARBINARY";
      case Types.LONGVARBINARY -> "LONGVARBINARY";
      case Types.NULL -> "NULL";
      case Types.OTHER -> "OTHER";
      case Types.JAVA_OBJECT -> "JAVA_OBJECT";
      case Types.DISTINCT -> "DISTINCT";
      case Types.STRUCT -> "STRUCT";
      case Types.ARRAY -> "ARRAY";
      case Types.BLOB -> "BLOB";
      case Types.CLOB -> "CLOB";
      case Types.REF -> "REF";
      case Types.DATALINK -> "DATALINK";
      case Types.BOOLEAN -> "BOOLEAN";
      default -> "UNKNOWN";
    };
    return result;
  }

  public static int guessJdbcTypeByName(final String name) {
    if (StringUtil.isEmpty(name)) return Types.OTHER;
    @NonNls final String fixed = StringUtil.toUpperCase(name);
    if (fixed.contains("BINARY_FLOAT")) return Types.FLOAT;
    else if (fixed.contains("BINARY")) return Types.VARBINARY;
    else if (fixed.contains("BIT")) return Types.BIT;
    else if (fixed.contains("BOOL")) return Types.BOOLEAN;
    else if (fixed.endsWith("RANGE")) return Types.OTHER;
    else if (fixed.contains("DATE")) return Types.DATE;
    else if (fixed.contains("TIMESTAMP")) return Types.TIMESTAMP;
    else if (fixed.contains("TIME")) return Types.TIME;
    else if (fixed.contains("REAL") || fixed.contains("NUMBER")) return Types.REAL;
    else if (fixed.contains("FLOAT")) return Types.FLOAT;
    else if (fixed.contains("DOUBLE")) return Types.DOUBLE;
    else if (fixed.equals("CHAR")) return Types.CHAR;
    else if (fixed.contains("INT") && !fixed.contains("INTERVAL") && !fixed.contains("POINT")) return Types.INTEGER;
    else if (fixed.contains("DECIMAL")) return Types.DECIMAL;
    else if (fixed.contains("NUMERIC")) return Types.NUMERIC;
    else if (fixed.contains("CHAR") || fixed.contains("TEXT")) return Types.VARCHAR;
    else if (fixed.contains("BLOB")) return Types.BLOB;
    else if (fixed.contains("CLOB")) return Types.CLOB;
    else if (fixed.contains("REFERENCE")) return Types.REF;
    return Types.OTHER;
  }

  public static boolean isDouble(@Nullable String clazz) {
    return Double.class.getName().equals(clazz) ||
           "oracle.sql.BINARY_DOUBLE".equals(clazz);
  }

  public static boolean isFloat(@Nullable String clazz) {
    return Float.class.getName().equals(clazz) ||
           "oracle.sql.BINARY_FLOAT".equals(clazz);
  }

  public static boolean isBigDecimal(@Nullable String clazz) {
    return BigDecimal.class.getName().equals(clazz);
  }
}
