package com.intellij.database.util

import com.intellij.database.model.ObjectKind


/**
 * Represents which namespace this object path belongs to.
 */
sealed class ObjectPathNamespace {

  class InSchema(val schemaPath: ObjectPath) : ObjectPathNamespace() {
    init {
      assert(schemaPath.kind == ObjectKind.SCHEMA)
    }

    override fun toString() = "In schema $schemaPath"
  }

  class InDatabase(val databasePath: ObjectPath) : ObjectPathNamespace() {
    init {
      assert(databasePath.kind == ObjectKind.DATABASE)
    }

    override fun toString() = "In database ${databasePath.name}"
  }

  object InServer : ObjectPathNamespace() {
    override fun toString() = "In server"
  }

}

