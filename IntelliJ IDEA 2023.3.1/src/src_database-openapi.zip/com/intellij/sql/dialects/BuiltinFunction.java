/*
 * Copyright 2000-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.sql.dialects;

import com.intellij.database.Dbms;
import com.intellij.database.model.DasObject;
import com.intellij.database.model.ObjectKind;
import com.intellij.database.symbols.DasPredefinedSymbol;
import com.intellij.database.types.DasType;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.tree.IElementType;
import com.intellij.util.PairConsumer;
import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Represents built-in dialect function.
 * @author gregsh
 */
public class BuiltinFunction extends DasPredefinedSymbol implements DasObject {
  public static final Parameter COMMA = new SyntaxParameter(-1, ",");

  public static final String PARAM_TYPE_PREFIX = "P";

  protected final Map<String, String> myDialectAttrs;

  protected final String myName;

  protected final Prototype[] myPrototypes;

  protected final String myAliasedFunction;

  protected final Location myLocation;

  protected final Dbms myDbms;

  public BuiltinFunction(
    String name, String aliasedFunction, Map<String, String> dialectAttrs,
    List<Prototype> prototypes,
    @NotNull Dbms dbms
  ) {
    myDialectAttrs = dialectAttrs;
    myName = name;
    myAliasedFunction = aliasedFunction;
    myDbms = dbms;
    myLocation = parseLocation(getDialectAttribute("location"));
    myPrototypes = new Prototype[prototypes.size()];
    for (int i = 0; i < prototypes.size(); i++) {
      Prototype p = prototypes.get(i);
      myPrototypes[i] = new Prototype(this, p.getReturnType(), p.getPrototypeId(), p.getHeadBlock(), p.getParams(), p.getAttributes());
    }
  }

  @NotNull
  protected static Location parseLocation(@Nullable String location) {
    if (location == null) return Location.NORMAL;
    try {
      return Location.valueOf(StringUtil.toUpperCase(location));
    }
    catch (IllegalArgumentException e) {
      return Location.NORMAL;
    }
  }

  @Override
  @NotNull
  public DasObject getDasObject() {
    return super.getDasObject();
  }

  @NotNull
  @Override
  public ObjectKind getKind() {
    return ObjectKind.ROUTINE;
  }

  @Override
  public boolean isQuoted() {
    return true;
  }

  public String getPostfixType() {
    return getDialectAttribute("postfix");
  }

  @Override
  @NotNull
  public JBIterable<? extends DasObject> getDasChildren(@Nullable ObjectKind kind) {
    return super.getDasChildren(kind);
  }

  @Nullable
  @Override
  public DasObject getDasParent() {
    return super.getDasParent();
  }

  @Override
  @Nullable
  public String getComment() {
    return null;
  }

  @Override
  @NotNull
  public String getName() {
    return myName;
  }

  public Prototype[] getPrototypes() {
    return myPrototypes;
  }

  public String getAliasedFunction() {
    return myAliasedFunction;
  }

  public Map<String, String> getDialectAttrs() {
    return myDialectAttrs;
  }

  @Nullable
  public String getDialectAttribute(String name) {
    return myDialectAttrs.get(name);
  }

  @Nullable
  public String getSelf() {
    return getDialectAttribute("self");
  }

  public boolean isOptionalSelf() {
    return "true".equals(getDialectAttribute("opt_self"));
  }

  public boolean isInstanceMethod() {
    return Boolean.parseBoolean(getDialectAttribute("instance"));
  }

  @NotNull
  private Location getLocation() {
    return myLocation;
  }

  @Override
  @NotNull
  public Dbms getDbms() {
    return myDbms;
  }

  public boolean isOverloadable() {
    return !"no".equals(getDialectAttribute("overloadable"));
  }

  public String toString() {
    return myName + Prototype.toString(myDialectAttrs) + Arrays.asList(myPrototypes);
  }

  public enum Location {
    NORMAL(true),
    TABLE_FUNCTION(true),
    TABLE_ENGINE_SPEC(false),
    DATABASE_ENGINE_SPEC(false),
    CODEC_SPEC(false),
    INDEX_TYPE_SPEC(false),
    DICTIONARY_SOURCE_SPEC(false),
    DICTIONARY_LAYOUT_SPEC(false);

    private final boolean myHasReturnType;

    Location(boolean special) {
      myHasReturnType = special;
    }

    public boolean hasReturnType() {
      return myHasReturnType;
    }
  }

  public abstract static class Parameter {
    public static final Parameter[] EMPTY_ARRAY = new Parameter[0];

    private final int myPrototypeId;

    public Parameter(int prototypeId) {
      myPrototypeId = prototypeId;
    }

    public int getPrototypeId() {
      return myPrototypeId;
    }

    public boolean isMany() {
      return false;
    }

    public abstract Parameter copyWithPrototype(int prototypeId);
  }

  public static class SyntaxParameter extends Parameter {
    private final String myText;

    public SyntaxParameter(int prototypeId, @NotNull String text) {
      super(prototypeId);
      myText = text;
    }

    @NotNull
    public String getText() {
      return myText;
    }

    @Override
    public String toString() {
      return !"()[]{}.\\:|".contains(myText) ? myText : "'" + myText + "'";
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      return new SyntaxParameter(prototypeId, myText);
    }
  }

  public static class ExternalParameter extends Parameter {
    private final IElementType myNodeType;
    private final String myDisplayName;

    public ExternalParameter(int prototypeId, IElementType nodeType, String displayName) {
      super(prototypeId);
      myNodeType = nodeType;
      myDisplayName = displayName;
    }

    @NotNull
    public IElementType getNodeType() {
      return myNodeType;
    }

    @Override
    public String toString() {
      return myDisplayName;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      return new ExternalParameter(prototypeId, myNodeType, myDisplayName);
    }
  }

  public static class Keyword extends Parameter {
    private final String myName;

    public Keyword(int prototypeId, String name) {
      super(prototypeId);
      myName = name;
    }

    public String getName() {
      return myName;
    }

    @Override
    public String toString() {
      return myName;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      return new Keyword(prototypeId, myName);
    }
  }

  public enum ParameterBlockType { SEQUENCE, OPTIONAL_SEQUENCE, CHOICE}

  public enum ParameterBlockQuantifier {
    ELLIPSIS(true, true, true),
    NON_GREEDY_ELLIPSIS(false, true, true),
    STAR(true, false, false);

    final boolean greedy;
    final boolean atLeastOne;
    final boolean commaSeparated;

    ParameterBlockQuantifier(boolean greedy, boolean atLeastOne, boolean commaSeparated) {
      this.greedy = greedy;
      this.atLeastOne = atLeastOne;
      this.commaSeparated = commaSeparated;
    }
  }

  public static class ParameterBlock extends Parameter {
    private final Parameter[] myParams;
    private final ParameterBlockQuantifier myQuantifier;
    private final ParameterBlockType myBlockType;

    public ParameterBlock(int prototypeId, ParameterBlockType blockType, Parameter[] params, ParameterBlockQuantifier quantifier) {
      super(prototypeId);
      myBlockType = blockType;
      myParams = params;
      myQuantifier = quantifier;
    }

    public ParameterBlock(int prototypeId, ParameterBlockType blockType, Parameter[] params, boolean many) {
      this(prototypeId, blockType, params, many ? ParameterBlockQuantifier.ELLIPSIS : null);
    }

    public ParameterBlockType getBlockType() {
      return myBlockType;
    }

    public Parameter[] getParams() {
      return myParams;
    }

    @Override
    public boolean isMany() {
      return myQuantifier != null;
    }

    public boolean isAtLeastOne() {
      return myQuantifier == null || myQuantifier.atLeastOne;
    }

    public boolean isGreedy() {
      return myQuantifier == null || myQuantifier.greedy;
    }

    public boolean isFollowedByComma() {
      return myQuantifier == null || myQuantifier.commaSeparated;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      Parameter[] params = myParams.length == 0 ? EMPTY_ARRAY : new Parameter[myParams.length];
      for (int i = 0; i < myParams.length; i++) {
        params[i] = myParams[i].copyWithPrototype(prototypeId);
      }
      return new ParameterBlock(prototypeId, myBlockType, params, myQuantifier);
    }

    @Override
    public String toString() {
      StringBuilder sb = new StringBuilder();
      toString(sb, null);
      return sb.toString();
    }

    public void toString(StringBuilder sb, @Nullable PairConsumer<Parameter, Boolean> markerProcessor) {
      boolean first = true;
      if (markerProcessor != null) markerProcessor.consume(this, true);
      switch (myBlockType) {
        case CHOICE -> sb.append("{");
        case OPTIONAL_SEQUENCE -> sb.append("[");
        case SEQUENCE -> sb.append("(");
      }
      for (Parameter param : myParams) {
        if (first) first = false;
        else if (myBlockType == ParameterBlockType.CHOICE) sb.append(" | ");
        else if (param != COMMA) {
          sb.append(' ');
        }
        if (param instanceof ParameterBlock) {
          ((ParameterBlock)param).toString(sb, markerProcessor);
        }
        else {
          if (markerProcessor != null) markerProcessor.consume(param, true);
          sb.append(param);
          if (markerProcessor != null) markerProcessor.consume(param, false);
        }
      }
      switch (myBlockType) {
        case CHOICE -> sb.append("}");
        case OPTIONAL_SEQUENCE -> sb.append("]");
        case SEQUENCE -> sb.append(")");
      }
      if (isMany()) {
        sb.append("...");
      }
      if (markerProcessor != null) markerProcessor.consume(this, false);
    }

    //  public boolean processParameters(Processor<Parameter> processor) {
    //    for (Parameter param : getParams()) {
    //      if (!processor.process(param)) return false;
    //      if (param instanceof ParameterBlock) {
    //        if (!((ParameterBlock)param).processParameters(processor)) return false;
    //      }
    //    }
    //    return true;
    //  }
  }

  public static class Type {
    private final String myName;
    private final DasType myDasType;

    public Type(@NonNls String name) {
      this(name, null);
    }

    public Type(@NonNls String name, DasType dasType) {
      myName = name;
      myDasType = dasType;
    }

    public String getName() {
      return myName;
    }

    public String getDisplayName() {
      return myDasType == null ? myName : myDasType.getSpecification();
    }

    @Nullable
    public DasType getDasType() {
      return myDasType;
    }

    @Override
    public String toString() {
      return getDisplayName();
    }
  }

  public static class SimpleParameter extends Parameter {
    private final String myName;
    private final Type myType;
    private final boolean myMany;

    public SimpleParameter(int prototypeId, String name, @NotNull Type type, boolean many) {
      super(prototypeId);
      myName = name == null ? StringUtil.toLowerCase(type.getName()) : name;
      myType = type;
      myMany = many;
    }

    @Override
    public boolean isMany() {
      return myMany;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      return new SimpleParameter(prototypeId, myName, myType, myMany);
    }

    public String getName() {
      return myName;
    }

    public Type getType() {
      return myType;
    }

    @Override
    public String toString() {
      return myName + ":" + myType.getDisplayName() + (myMany ? "*" : "");
    }
  }

  public static class ReferenceParameter extends SimpleParameter {
    private final String myRefTypeName;

    public ReferenceParameter(int prototypeId, String name, Type type, @NotNull String refTypeName, boolean many) {
      super(prototypeId, name, type, many);
      myRefTypeName = refTypeName;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      return new ReferenceParameter(prototypeId, getName(), getType(), myRefTypeName, isMany());
    }

    public String getRefTypeName() {
      return myRefTypeName;
    }

    @Override
    public String toString() {
      return super.toString()+"/"+myRefTypeName;
    }
  }

  public static class ParamType extends Type {
    private final int myIndex;

    public ParamType(int index) {
      super(PARAM_TYPE_PREFIX + index);
      myIndex = index;
    }

    @Override
    public String getDisplayName() {
      return "TypeOf("+myIndex+")";
    }

    public int getIndex() {
      return myIndex;
    }
  }

  public static class Prototype extends ParameterBlock {
    public static final Prototype[] EMPTY_ARRAY = new Prototype[0];

    private final Type myReturnType;
    private final BuiltinFunction myFunction;
    private final Parameter myHeadBlock;
    private final Map<String, String> myAttributes;

    public Prototype(@Nullable BuiltinFunction function,
                     @NotNull Type returnType,
                     int id,
                     @Nullable Parameter headBlock,
                     Parameter[] parameters,
                     @NotNull Map<String, String> attributes) {
      super(id, ParameterBlockType.SEQUENCE, parameters, null);
      myFunction = function;
      myReturnType = returnType;
      myHeadBlock = headBlock;
      myAttributes = attributes.isEmpty() ? Collections.emptyMap() : attributes;
    }

    @Override
    public Parameter copyWithPrototype(int prototypeId) {
      throw new UnsupportedOperationException();
    }

    public Type getReturnType() {
      return myReturnType;
    }

    @Override
    public String toString() {
      return toString(myAttributes)
             + (myHeadBlock == null ? "" : myHeadBlock + " ")
             + super.toString()
             + (myFunction == null || getLocation().hasReturnType() ? ":" + myReturnType : "");
    }

    @NotNull
    public BuiltinFunction getFunction() {
      assert myFunction != null;
      return myFunction;
    }

    public Location getLocation() {
      String locationName = myAttributes.get("location");
      return locationName != null ? parseLocation(locationName) : myFunction.getLocation();
    }

    @Nullable
    public Parameter getHeadBlock() {
      return myHeadBlock;
    }

    @NotNull
    public Map<String, String> getAttributes() {
      return myAttributes;
    }

    private static String toString(Map<String, String> attrs) {
      if (attrs.isEmpty()) return "";
      return "{" + StringUtil.join(attrs.entrySet(), entry -> entry.getKey() + ":" + entry.getValue(), ",") + "}";
    }
  }
}
