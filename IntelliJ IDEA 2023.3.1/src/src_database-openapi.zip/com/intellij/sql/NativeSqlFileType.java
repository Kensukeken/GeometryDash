package com.intellij.sql;

import com.intellij.openapi.fileTypes.LanguageFileType;
import com.intellij.sql.dialects.SqlLanguageDialect;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.util.function.Supplier;

public abstract class NativeSqlFileType extends LanguageFileType {
  private final String myDefaultExtension;
  private final Supplier<? extends Icon> iconProvider;

  protected NativeSqlFileType(@NotNull SqlLanguageDialect dialect,
                              @NotNull String defaultExtension,
                              @NotNull Supplier<? extends Icon> iconProvider) {
    super(dialect);
    myDefaultExtension = defaultExtension;
    this.iconProvider = iconProvider;
  }

  @NotNull
  private SqlLanguageDialect getSqlDialect() {
    return (SqlLanguageDialect) getLanguage();
  }

  @Override
  @NotNull
  @NonNls
  public final String getName() {
    return getSqlDialect().getID();
  }

  @Override
  @NotNull
  public final String getDescription() {
    return getName(); //NON-NLS
  }

  @NotNull
  @Override
  public String getDefaultExtension() {
    return myDefaultExtension;
  }

  @Override
  public final Icon getIcon() {
    return iconProvider.get();
  }
}
