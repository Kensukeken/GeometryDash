package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;

/**
 * @author Gregory.Shrago
 */
public interface SqlExpression extends SqlDasTypeAwareElement {
  /**
   * @deprecated SqlType is superseded by DasType
   * Use getDasType() instead
   */
  @Deprecated(forRemoval = true)
  @NotNull
  default SqlType getSqlType() {
    return SqlType.UNKNOWN;
  }
}
