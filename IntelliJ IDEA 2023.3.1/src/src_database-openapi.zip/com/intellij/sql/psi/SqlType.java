package com.intellij.sql.psi;

import com.intellij.database.types.DasTypeFacade;
import org.jetbrains.annotations.NotNull;

/**
 * @author Gregory.Shrago
 * @deprecated SqlType is superseded by DasType
 */
@Deprecated(forRemoval = true)
public class SqlType {
  /**
   * @deprecated Use DasType.getDescription() instead
   */
  @Deprecated(forRemoval = true)
  @NotNull
  public final String getDisplayName() {
    return DasTypeFacade.getInstance().getUnknown().getDescription();
  }

  /**
   * @deprecated SqlType is superseded by DasType, so avoid using it in the IntelliJ code
   * This constant exists only for backward compatibility with third-party plugins
   */
  @Deprecated(forRemoval = true)
  public static final SqlPrimitiveType UNKNOWN = new SqlPrimitiveType();

  @Override
  public String toString() {
    return getDisplayName();
  }
}
