package com.intellij.sql.psi;

/**
 * @author Gregory.Shrago
 */
public interface SqlTypeElement extends SqlDasTypeAwareElement {
}
