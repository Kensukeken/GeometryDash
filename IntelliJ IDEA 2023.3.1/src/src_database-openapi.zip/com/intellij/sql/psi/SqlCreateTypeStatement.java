package com.intellij.sql.psi;

/**
 * @author ignatov
 */
public interface SqlCreateTypeStatement extends SqlCreateStatement, SqlUserTypeDefinition {

}
