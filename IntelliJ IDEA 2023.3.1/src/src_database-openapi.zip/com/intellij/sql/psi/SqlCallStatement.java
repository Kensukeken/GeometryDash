package com.intellij.sql.psi;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface SqlCallStatement extends SqlStatement {
  @Nullable
  SqlReferenceExpression getCallableReference();
  @NotNull
  List<SqlExpression> getArguments();
}
