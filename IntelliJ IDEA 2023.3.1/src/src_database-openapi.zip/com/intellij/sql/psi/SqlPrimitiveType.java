package com.intellij.sql.psi;

/**
 * @deprecated SqlType is superseded by DasType
 * This class exists only for backward compatibility with third-party plugins
 */
public class SqlPrimitiveType extends SqlType {

}