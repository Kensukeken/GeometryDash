package com.intellij.sql.psi;

import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * @author Gregory.Shrago
 */
public interface SqlJoinExpression extends SqlBinaryExpression, SqlLateralAwareExpression {
  @NotNull
  @Override
  SqlTableType getDasType();

  @NotNull
  @Override
  SqlTableType getDasType(@Nullable PsiElement end);

  boolean isLeft();

  boolean isRight();
}
