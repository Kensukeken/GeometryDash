/*
 * Copyright 2000-2016 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.sql.util;

import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.tree.IElementType;
import com.intellij.sql.psi.SqlCompositeElementType;
import com.intellij.sql.psi.SqlKeywordTokenType;
import com.intellij.sql.psi.SqlTokenType;
import com.intellij.util.*;
import com.intellij.util.containers.CollectionFactory;
import com.intellij.util.containers.JBIterable;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.TestOnly;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * @author Gregory.Shrago
 */
public final class SqlTokenRegistry {
  private static final Map<String, SqlTokenType> ourTokensMap = newTokenMap();
  private static final Map<Class, Map<String, SqlKeywordTokenType>> ourClassTokensMap = new HashMap<>();
  private static final Map<Class, Set<SqlKeywordTokenType>> ourSynteticTokensMap = new HashMap<>();
  private static final Map<String, IElementType> ourCompositeMap = new HashMap<>();

  private SqlTokenRegistry() {
  }

  @NotNull
  public static SqlTokenType getType(@NotNull String text) {
    return getImpl(ourTokensMap, text, o -> (Character.isLetter(o.charAt(0)) ? new SqlKeywordTokenType(o) : new SqlTokenType(o)));
  }

  @NotNull
  public static SqlTokenType getType(@NotNull String text, @NotNull Function<String, ? extends SqlTokenType> factory) {
    return getImpl(ourTokensMap, text, factory);
  }

  /**
   * For *ElementTypes only
   */
  @NotNull
  public static SqlCompositeElementType getCompositeType(@NotNull String debugName) {
    return getImpl(ourCompositeMap, debugName, o -> new SqlCompositeElementType(o));
  }

  /**
   * For *ElementTypes only
   */
  @NotNull
  public static <T extends IElementType> T getCompositeType(@NotNull String debugName,
                                                            @NotNull Function<String, T> factory) {
    return getImpl(ourCompositeMap, debugName, factory);
  }


  private static Consumer<String> ourTestInterceptor;

  @TestOnly
  public static void setTestInterceptor(@NotNull Consumer<String> testInterceptor) {
    ourTestInterceptor = testInterceptor;
  }

  @NotNull
  private synchronized static <T extends IElementType> T getImpl(@NotNull Map<String, ? super T> map,
                                                                 @NotNull String debugName,
                                                                 @NotNull Function<String, T> factory) {
    //noinspection unchecked
    T type = (T)map.get(debugName);
    if (type == null) {
      map.put(debugName, type = Objects.requireNonNull(factory.fun(debugName)));
      if (ourTestInterceptor != null) {
        ourTestInterceptor.consume(debugName);
      }
    }
    return type;
  }

  @Nullable
  public static synchronized SqlTokenType findTokenType(@NotNull String text) {
    return ourTokensMap.get(text);
  }

  @Nullable
  public static synchronized IElementType findCompositeType(@NotNull String text) {
    return ourCompositeMap.get(text);
  }

  @Nullable
  public static synchronized IElementType findType(@NotNull String text) {
    SqlTokenType token = ourTokensMap.get(text);
    if (token != null) return token;
    return ourCompositeMap.get(text);
  }

  @NotNull
  public static synchronized Iterable<IElementType> getAllCompositeTypes() {
    return ourCompositeMap.values();
  }

  public static void initTypeMap(@NotNull Class clazz, @Nullable Set<String> exclude) {
    Map<String, SqlKeywordTokenType> map = buildTokenMap(clazz, newTokenMap());
    if (exclude != null) {
      map.keySet().removeAll(exclude);
    }
    setTypeMap(clazz, map, false);
  }

  public static synchronized void addTokensToClassMap(@NotNull Class clazz, @NotNull Set<String> keywordSet, boolean storeNewAsSynthetic) {
    Map<String, SqlKeywordTokenType> map = ourClassTokensMap.get(clazz);
    if (map == null) map = newTokenMap();
    Set<SqlKeywordTokenType> synthetic = storeNewAsSynthetic ? ourSynteticTokensMap.get(clazz) : null;
    if (storeNewAsSynthetic && synthetic == null) synthetic = new HashSet<>();
    for (String s : keywordSet) {
      if (!map.containsKey(s)) {
        String upperCase = StringUtil.toUpperCase(s);
        SqlKeywordTokenType type = (SqlKeywordTokenType)getType(upperCase);
        map.put(upperCase, type);
        if (synthetic != null) synthetic.add(type);
      }
    }
    setTypeMap(clazz, map, true);
    if (storeNewAsSynthetic) ourSynteticTokensMap.put(clazz, synthetic);
  }

  private static synchronized void setTypeMap(@NotNull Class clazz, @NotNull Map<String, SqlKeywordTokenType> map, boolean force) {
    if (!force && ourClassTokensMap.containsKey(clazz)) return;
    ourClassTokensMap.put(clazz, map);
  }

  @NotNull
  public static NullableFunction<String, IElementType> getTokenProvider(@NotNull Class clazz) {
    return getSafeMap(clazz)::get;
  }

  public static Set<SqlKeywordTokenType> getSyntheticTokens(final Class clazz) {
    Set<SqlKeywordTokenType> synthetic = ourSynteticTokensMap.get(clazz);
    if (synthetic == null) {
      throw new AssertionError(clazz + " synthetic token map not initialized");
    }
    return Collections.unmodifiableSet(synthetic);
  }

  public static Set<String> getTokens(final Class clazz) {
    return Collections.unmodifiableSet(getSafeMap(clazz).keySet());
  }

  @NotNull
  private synchronized static Map<String, SqlKeywordTokenType> getSafeMap(@NotNull Class clazz) {
    Map<String, SqlKeywordTokenType> result = ourClassTokensMap.get(clazz);
    if (result == null) {
      throw new AssertionError(clazz + " token map not initialized");
    }
    return result;
  }

  private static <T extends IElementType> Map<String, T> newTokenMap() {
    return CollectionFactory.createCaseInsensitiveStringMap();
  }

  private static Map<String, SqlKeywordTokenType> buildTokenMap(@NotNull Class clazz, @NotNull Map<String, SqlKeywordTokenType> map) {
    consumeStaticFieldsInOrder(clazz, (field, value) -> {
      if (value instanceof SqlKeywordTokenType tokenType) {
        map.put(tokenType.toString(), tokenType);
      }
    });
    return map;
  }

  public static void consumeStaticFieldsInOrder(@NotNull Class clazz, @NotNull PairConsumer<Field, Object> processor) {
    JBIterable<Field> fields = JBIterableClassTraverser.classTraverser(clazz)
      .postOrderDfsTraversal()
      .flatMap(o -> JBIterable.of(o.getDeclaredFields()))
      .filter(o -> Modifier.isStatic(o.getModifiers()));
    for (Field field : fields) {
      try {
        processor.consume(field, field.get(null));
      }
      catch (IllegalAccessException ignored) {
      }
    }
  }

  public static void ensureInterfacesAreInitializedInOrder(@NotNull Class<?> factoryClass) {
    // as far as interfaces are not initialized automatically (JLS 12.4.1)
    // make sure all superinterfaces are initialized from top to bottom
    JBIterable<Class<?>> interfaces = JBIterableClassTraverser.classTraverser(factoryClass)
      .postOrderDfsTraversal()
      .filter(o -> o.isInterface());
    for (Class<?> aClass : interfaces) {
      Field[] fields = aClass.getDeclaredFields();
      if (fields.length == 0) continue;
      try {
        fields[0].setAccessible(true);
        fields[0].get(null);
      }
      catch (IllegalAccessException ignored) {
      }
    }
  }
}
