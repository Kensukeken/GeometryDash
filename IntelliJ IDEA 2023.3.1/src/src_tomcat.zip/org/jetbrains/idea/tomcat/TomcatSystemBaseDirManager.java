package org.jetbrains.idea.tomcat;

import com.intellij.javaee.directoryManager.JavaeeSystemBaseDirectoryManagerProvider;
import com.intellij.javaee.directoryManager.SystemBaseDirectoryManager;
import org.jetbrains.annotations.NotNull;

public final class TomcatSystemBaseDirManager {
  @NotNull
  public static SystemBaseDirectoryManager getInstance() {
    return JavaeeSystemBaseDirectoryManagerProvider.getManagerInstance("tomcat");
  }
}
