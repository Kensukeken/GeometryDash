package org.jetbrains.idea.tomcat;

import com.intellij.execution.configurations.ConfigurationFactory;
import com.intellij.execution.configurations.ConfigurationType;
import com.intellij.execution.configurations.RunConfiguration;
import com.intellij.javaee.appServers.run.configuration.J2EEConfigurationProducer;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.TomcatConfiguration;

import javax.swing.*;

final class TomcatConfigurationProducer extends J2EEConfigurationProducer {
  TomcatConfigurationProducer() {
    super(new ConfigurationFactory() {
      // init TomcatConfiguration lazily
      @Override
      public @NotNull ConfigurationType getType() {
        return TomcatConfiguration.getInstance();
      }

      @Override
      public Icon getIcon() {
        return getType().getIcon();
      }

      @Nls
      @Override
      public @NotNull String getName() {
        return getType().getDisplayName();
      }

      @Override
      public @NotNull RunConfiguration createTemplateConfiguration(@NotNull Project project) {
        return getType().getConfigurationFactories()[0].createTemplateConfiguration(project);
      }
    });
  }
}
