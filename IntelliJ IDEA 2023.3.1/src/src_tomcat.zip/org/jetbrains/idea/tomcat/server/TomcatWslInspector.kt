package org.jetbrains.idea.tomcat.server

import com.intellij.openapi.application.ApplicationInfo
import com.intellij.openapi.diagnostic.Logger
import com.intellij.openapi.diagnostic.logger
import org.jetbrains.idea.tomcat.server.TomcatWslSupportUtil.executeOnWsl
import org.jetbrains.idea.tomcat.server.TomcatWslSupportUtil.fromLinuxToWslPath
import org.jetbrains.idea.tomcat.server.TomcatWslSupportUtil.fromWslToLinuxPath
import org.jetbrains.idea.tomcat.server.TomcatWslSupportUtil.getWslConfiguration
import java.io.File
import java.io.FileOutputStream

private const val TOMCAT_INSPECTOR_VERSION: String = "2023.2.0"

private const val GET_SERVER_INFO_CMD: String = "getServerInfo"
private const val SEARCH_FOR_CLASSES_CMD: String = "searchForClasses"

object TomcatWslInspector {

  private val LOG: Logger = logger<TomcatWslInspector>()

  @JvmStatic
  fun getServerInfo(tomcatHome: String): String? {
    val wslConfiguration = getWslConfiguration(tomcatHome) ?: return null
    if (!deployTomcatInspectorIfNeeded(wslConfiguration)) return null

    val command = buildString {
      append(getTomcatInspectorLocation())
      append(" ")
      append(GET_SERVER_INFO_CMD)
      append(" ")
      append(fromWslToLinuxPath(tomcatHome))
    }

    return executeOnWsl(wslConfiguration, command)?.firstOrNull()
  }

  @JvmStatic
  fun searchForLibraries(tomcatHome: String): Array<out File> {
    val wslConfiguration = getWslConfiguration(tomcatHome) ?: return emptyArray()
    if (!deployTomcatInspectorIfNeeded(wslConfiguration)) return emptyArray()

    val command = buildString {
      append(getTomcatInspectorLocation())
      append(" ")
      append(SEARCH_FOR_CLASSES_CMD)
      append(" ")
      append(fromWslToLinuxPath(tomcatHome))
    }

    return executeOnWsl(wslConfiguration, command)?.map { classInJar ->
      File(fromLinuxToWslPath(classInJar.substringAfter(':'), wslConfiguration))
    }?.toTypedArray() ?: emptyArray()
  }

  private fun deployTomcatInspectorIfNeeded(wslConfiguration: WslConfiguration): Boolean {
    val tomcatInspectorDir = File(fromLinuxToWslPath(getTomcatInspectorDir(), wslConfiguration))
    if (!tomcatInspectorDir.exists()) {
      if (!tomcatInspectorDir.mkdirs()) {
        LOG.warn("Unable to create a directory for Tomcat WSL inspector: ${tomcatInspectorDir.path}")
        return false
      }
    }

    val tomcatInspectorBinaryName = getTomcatInspectorBinaryName()
    val tomcatInspector = File(tomcatInspectorDir, tomcatInspectorBinaryName)
    if (tomcatInspector.exists()) return true

    try {
      FileOutputStream(tomcatInspector).use { outputStream ->
        TomcatWslInspector::class.java.classLoader
          .getResourceAsStream("org/jetbrains/idea/tomcat/$tomcatInspectorBinaryName")
          ?.transferTo(outputStream)
      }
    }
    catch (e: Exception) {
      LOG.warn("Failed to deploy Tomcat WSL inspector", e)
      return false
    }

    executeOnWsl(wslConfiguration, "chmod a+x ${getTomcatInspectorLocation()}")

    return true
  }

  private fun getTomcatInspectorDir(): String {
    val applicationName = ApplicationInfo.getInstance().versionName.replace(' ', '-')
    return "/var/tmp/JetBrains/$applicationName/$TOMCAT_INSPECTOR_VERSION/app-servers/tomcat/tomcat-inspector"
  }

  private fun getTomcatInspectorLocation(): String {
    return "${getTomcatInspectorDir()}/${getTomcatInspectorBinaryName()}"
  }

  private fun getTomcatInspectorBinaryName(): String {
    return "tomcat-inspector-$TOMCAT_INSPECTOR_VERSION.bin"
  }
}