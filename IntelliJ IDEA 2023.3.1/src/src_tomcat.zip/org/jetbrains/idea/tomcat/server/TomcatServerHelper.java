package org.jetbrains.idea.tomcat.server;

import com.intellij.javaee.appServers.appServerIntegrations.ApplicationServerInfo;
import com.intellij.javaee.appServers.appServerIntegrations.ApplicationServerPersistentData;
import com.intellij.javaee.appServers.appServerIntegrations.ApplicationServerPersistentDataEditor;
import com.intellij.javaee.appServers.appServerIntegrations.CantFindApplicationServerJarsException;
import com.intellij.javaee.oss.server.JavaeeIntegration;
import com.intellij.javaee.oss.server.JavaeePersistentData;
import com.intellij.javaee.oss.server.JavaeeServerHelper;
import com.intellij.openapi.util.text.StringUtil;

import java.io.File;
import java.util.Arrays;

public class TomcatServerHelper extends JavaeeServerHelper {

  private final TomcatIntegration myIntegration;
  private final boolean myTomEEOnly;

  public TomcatServerHelper(TomcatIntegration integration, boolean tomEEOnly) {
    super(integration);
    myIntegration = integration;
    myTomEEOnly = tomEEOnly;
  }

  @Override
  public ApplicationServerPersistentData createPersistentDataEmptyInstance() {
    return new TomcatPersistentData();
  }

  @Override
  public ApplicationServerPersistentDataEditor createConfigurable() {
    return new TomcatPersistentDataEditor(myIntegration, myTomEEOnly);
  }

  @Override
  public ApplicationServerInfo getApplicationServerInfo(ApplicationServerPersistentData data)
    throws CantFindApplicationServerJarsException {

    if (data instanceof JavaeePersistentData jeePersistentData &&
        TomcatWslSupportUtil.isWslPath(jeePersistentData.HOME)) {

      String tomcatHome = ((JavaeePersistentData)data).HOME;
      File[] libraries = TomcatWslInspector.searchForLibraries(tomcatHome);

      JavaeeIntegration integration = getIntegration();
      String serverVersion = integration.getServerVersionSilently((JavaeePersistentData)data);
      String name = StringUtil.join(Arrays.asList(integration.getName(), serverVersion), " ");
      return new ApplicationServerInfo(libraries, name);
    } else {
      return super.getApplicationServerInfo(data);
    }
  }
}
