package org.jetbrains.idea.tomcat.server;

import com.intellij.javaee.oss.server.JavaeeIntegration;
import com.intellij.javaee.oss.server.JavaeePersistentDataWithBaseEditor;
import com.intellij.openapi.options.ConfigurationException;
import com.intellij.ui.components.JBLabel;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.idea.tomcat.TomcatBundle;
import org.jetbrains.idea.tomcat.TomcatConstants;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;

public class TomcatPersistentDataEditor extends JavaeePersistentDataWithBaseEditor<TomcatPersistentData> {

  private JBLabel myTomEELabel;
  private JPanel myMainPanel;

  private final boolean myTomEEOnly;

  public TomcatPersistentDataEditor(TomcatIntegration integration, boolean tomEEOnly) {
    super(integration);
    myTomEEOnly = tomEEOnly;
    getCustomPanelPlaceHolder().add(myMainPanel);
  }

  @Override
  protected boolean isValidHomeSet(@Nullable String home) {
    if (TomcatWslSupportUtil.isWslPath(home) &&
        !TomcatWslSupportUtil.isUnderHomeDir(home)) {
      return false;
    }
    return super.isValidHomeSet(home);
  }

  @Override
  protected void onHomeChanged() {
    String tomcatHome = getHome();
    if (TomcatWslSupportUtil.isWslPath(tomcatHome) &&
        !TomcatWslSupportUtil.isUnderHomeDir(tomcatHome)) {
      showQuickFix(new ConfigurationException(
        TomcatBundle.message("tomcat.wsl.unsupported.location.message"),
        TomcatBundle.message("tomcat.wsl.unsupported.location.title")
      ));
      return;
    }
    boolean tomEE = isServerVersionSet() && TomcatIntegration.isTomEE(tomcatHome);
    myTomEELabel.setVisible(!myTomEEOnly && tomEE);
    super.onHomeChanged();
  }

  @Override
  protected void doValidateBaseDir(String baseDir) throws FileNotFoundException {
    File base = new File(baseDir);
    JavaeeIntegration.checkDir(base);
    JavaeeIntegration.checkDir(new File(base, TomcatConstants.CATALINA_CONFIG_DIRECTORY_NAME));
  }
}
