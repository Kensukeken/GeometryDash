package org.jetbrains.idea.tomcat.server

import com.intellij.execution.ExecutionException
import com.intellij.execution.wsl.WSLDistribution
import com.intellij.openapi.diagnostic.logger
import com.intellij.openapi.util.io.FileUtil
import com.intellij.openapi.util.io.OSAgnosticPathUtil
import org.jetbrains.idea.tomcat.TomcatBundle
import java.io.InputStream
import java.net.InetAddress

private const val EXEC: String = "--exec /bin/sh -c"

private val WSL_PREFIXES: List<String> = listOf("\\\\wsl$", "\\\\wsl.localhost")
private val WSL_REGEX: Regex = Regex("(\\\\\\\\wsl(?:\\\$|\\.localhost)\\\\([^\\\\]+))\\\\.*")

object TomcatWslSupportUtil {

  private val LOG = logger<TomcatWslSupportUtil>()

  @JvmStatic
  fun isWslPath(path: String?): Boolean {
    return WSL_PREFIXES.any { prefix ->
      path.orEmpty().startsWith(prefix)
    }
  }

  @JvmStatic
  fun isUnderHomeDir(path: String?): Boolean {
    return fromWslToLinuxPath(path).orEmpty().startsWith("/home/")
  }

  @JvmStatic
  fun toWslEnvVariables(envVariables: Map<String, String>): Map<String, String> {
    val wslEnvVariables = mutableMapOf<String, String>()

    val wslPath = envVariables["CATALINA_HOME"] ?: envVariables["CATALINA_TMPDIR"]
    if (wslPath.isNullOrEmpty() || !isWslPath(wslPath)) {
      LOG.warn("Unable to convert environment variables - no WSL path provided")
      throw ExecutionException(TomcatBundle.message("tomcat.wsl.env.vars.conversion.error", envVariables["CATALINA_HOME"]))
    }

    val wslJavaHome = getWslJavaHome(wslPath)
    if (wslJavaHome.isNullOrEmpty() || !isWslPath(wslJavaHome)) {
      LOG.warn("Unable to find JAVA_HOME declaration in WSL distribution")
      throw ExecutionException(TomcatBundle.message("tomcat.wsl.java.home.detection.error"))
    }

    if (envVariables.containsKey("JRE_HOME")) {
      wslEnvVariables["JRE_HOME"] = wslJavaHome
    }
    if (envVariables.containsKey("JAVA_HOME")) {
      wslEnvVariables["JAVA_HOME"] = wslJavaHome
    }

    if (envVariables.containsKey("CATALINA_BASE")) {
      wslEnvVariables["CATALINA_BASE"] = fromWinToLinuxMntPath(wslPath, envVariables["CATALINA_BASE"]!!)
    }
    if (envVariables.containsKey("CATALINA_TMPDIR")) {
      val catalinaTmpDir = envVariables["CATALINA_TMPDIR"]!!
      wslEnvVariables["CATALINA_TMPDIR"] = fromWslToLinuxPath(catalinaTmpDir) ?: catalinaTmpDir
    }
    if (envVariables.containsKey("CATALINA_HOME")) {
      wslEnvVariables["CATALINA_HOME"] = fromWslToLinuxPath(wslPath) ?: wslPath
    }
    if (envVariables.containsKey("JAVA_OPTS")) {
      wslEnvVariables["JAVA_OPTS"] = envVariables["JAVA_OPTS"]!!
    }

    return wslEnvVariables
  }

  @JvmStatic
  fun toWslJavaOpts(wslPath: String, opts: List<String>): List<String> {
    return opts.mapNotNull {
      toWslJavaOpt(wslPath, it)
    }
  }

  @JvmStatic
  fun patchJavaOpts(wslPath: String, optString: String?): String? {
    val opts = optString?.split(' ')?.filter { it.isNotEmpty() } ?: return null

    val sb = StringBuilder()

    for ((index, opt) in opts.withIndex()) {
      if (opt.startsWith("-agentlib")) {
        sb.append(opt.replace("127.0.0.1", InetAddress.getLocalHost().hostAddress))
      }
      else if (opt.startsWith("-javaagent")) {
        val agentPath = opt.substringAfter(':')
        sb.append("-javaagent:${fromWinToLinuxMntPath(wslPath, agentPath)}")
      }
      else
        sb.append(opt)

      if (index + 1 < opts.size)
        sb.append(' ')
    }

    return sb.toString()
  }

  @JvmStatic
  fun fromWslToLinuxPath(path: String?): String? {
    val wslPrefix = path?.let(WSL_REGEX::matchEntire)?.groupValues?.get(1) ?: return null
    return path.replace(wslPrefix, "")
      .let(FileUtil::toSystemIndependentName)
  }

  @JvmStatic
  fun fromWinToLinuxMntPath(wslPath: String, winPath: String): String {
    val winDrive = winPath.substringBefore('\\')
    val winDrivePoint = getWinDriveMountPoint(wslPath, winDrive)
    if (winDrivePoint.isNullOrEmpty()) {
      LOG.warn("Failed to find Windows drive mount point by path: $winPath")
      throw ExecutionException(TomcatBundle.message("tomcat.wsl.cant.find.win.drive.mount.point", winPath))
    }
    return FileUtil.toSystemIndependentName(winPath).replace(winDrive, winDrivePoint)
  }

  @JvmStatic
  fun getWslDistributionName(wslPath: String): String? {
    return WSL_REGEX.matchEntire(wslPath)?.groupValues?.get(2)
  }

  private fun toWslJavaOpt(wslPath: String, opt: String?): String? {
    val (key, value) = opt?.split("=") ?: return null
    return if (isWinPath(value)) {
      "$key=${fromWinToLinuxMntPath(wslPath, value)}"
    }
    else opt
  }

  internal fun getWslConfiguration(wslPath: String): WslConfiguration? {
    val wslExePath = WSLDistribution.findWslExe()?.toString()
    if (wslExePath.isNullOrEmpty()) {
      LOG.warn("Unable to find WSL executable")
      return null
    }

    val wslDistribution = getWslDistributionName(wslPath)
    if (wslDistribution.isNullOrEmpty()) {
      LOG.warn("Failed to determine WSL distribution for the given path: $wslPath")
      return null
    }

    val wslPrefix = WSL_PREFIXES.find(wslPath::startsWith) ?: return null

    return WslConfiguration(wslExePath, wslDistribution, wslPrefix)
  }

  internal fun executeOnWsl(wslConfiguration: WslConfiguration, cmd: String): List<String>? {
    val (wslExePath, wslDistribution) = wslConfiguration
    val process = Runtime.getRuntime().exec("$wslExePath -d $wslDistribution $EXEC \"$cmd\"")

    val output = readOutput(process.inputStream)

    val errorOutput = readOutput(process.errorStream)
    if (errorOutput.isNotEmpty()) {
      LOG.warn("Failed to execute a command on WSL: $cmd. An error occurred: ${errorOutput.firstOrNull()}")
      return null
    }

    return output
  }

  private fun getWslJavaHome(tomcatHome: String): String? {
    val wslConfiguration = getWslConfiguration(tomcatHome) ?: return null

    return getJavaHomeLocations(tomcatHome, wslConfiguration).mapNotNull { location ->
      executeOnWsl(wslConfiguration, "cat $location")
        ?.firstOrNull(::isJavaHomeVariable)
        ?.substringAfter("=")
        ?.trim('"', '\'')
    }.firstOrNull()
  }

  internal fun fromLinuxToWslPath(linuxPath: String, wslConfiguration: WslConfiguration): String {
    val path = linuxPath.trimStart('/', '\\').replace('/', '\\')
    return buildString {
      append(wslConfiguration.wslPrefix)
      append("\\")
      append(wslConfiguration.distribution)
      append(path)
    }
  }

  private fun getJavaHomeLocations(tomcatHome: String, wslConfiguration: WslConfiguration): Sequence<String> {
    return sequence {
      yield(fromWslToLinuxPath(tomcatHome)?.trimEnd('/') + "/bin/setenv.sh")

      val wslUser = getWslUser(wslConfiguration)
      if (!wslUser.isNullOrEmpty()) {
        yield("/home/$wslUser/.bashrc")
        yield("/home/$wslUser/.zshrc")
      }

      yield("/etc/environment")
    }
  }

  private fun isJavaHomeVariable(line: String): Boolean {
    return !line.startsWith("#") &&
           (line.contains("JAVA_HOME") || line.contains("JRE_HOME"))
  }

  private fun getWinDriveMountPoint(wslPath: String, winDrive: String): String? {
    val wslConfiguration = getWslConfiguration(wslPath) ?: return null

    return executeOnWsl(wslConfiguration, "cat /proc/mounts | grep $winDrive")
      ?.firstOrNull()
      ?.split(' ')
      ?.getOrNull(1)
  }

  private fun getWslUser(wslConfiguration: WslConfiguration): String? {
    return executeOnWsl(wslConfiguration, "whoami")?.firstOrNull()
  }

  private fun readOutput(inputStream: InputStream): List<String> {
    return inputStream.use {
      it.bufferedReader().lineSequence().toList()
    }
  }

  private fun isWinPath(path: String): Boolean {
    return path.contains("\\") || OSAgnosticPathUtil.startsWithWindowsDrive(path)
  }
}

internal data class WslConfiguration(val wslExePath: String,
                                     val distribution: String,
                                     val wslPrefix: String)