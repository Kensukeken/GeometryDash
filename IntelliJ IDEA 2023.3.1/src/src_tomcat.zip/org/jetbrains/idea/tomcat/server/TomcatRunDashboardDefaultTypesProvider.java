package org.jetbrains.idea.tomcat.server;

import com.intellij.execution.dashboard.RunDashboardDefaultTypesProvider;
import com.intellij.openapi.project.Project;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.idea.tomcat.server.tomee.TomeeConfiguration;

import java.util.Collection;
import java.util.List;

final class TomcatRunDashboardDefaultTypesProvider implements RunDashboardDefaultTypesProvider {
  @Override
  public @NotNull Collection<String> getDefaultTypeIds(@NotNull Project project) {
    return List.of(TomcatConfiguration.ID, TomeeConfiguration.ID);
  }
}
