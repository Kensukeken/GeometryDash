// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.run.lifecycle;

public class SpringBootApplicationConfigurationException extends Exception {
  public SpringBootApplicationConfigurationException(String message) {
    super(message);
  }
}
