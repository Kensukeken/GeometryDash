// Copyright 2000-2017 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.run.lifecycle;

import org.jetbrains.annotations.Nullable;

/**
 * @author konstantin.aleev
 */
public interface SpringBootApplicationServerConfiguration {
  boolean isSslEnabled();

  @Nullable
  String getContextPath();

  @Nullable
  String getServletPath();

  @Nullable
  String getAddress();
}
