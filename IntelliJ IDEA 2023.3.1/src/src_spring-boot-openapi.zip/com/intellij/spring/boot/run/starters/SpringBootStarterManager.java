package com.intellij.spring.boot.run.starters;

import com.intellij.buildsystem.model.unified.UnifiedDependency;
import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.psi.PsiFile;
import com.intellij.util.SmartList;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.concurrency.Promise;

import java.util.Collection;
import java.util.Objects;

@ApiStatus.Experimental
public interface SpringBootStarterManager {
  ExtensionPointName<SpringBootStarterManager> EP_NAME = ExtensionPointName.create("com.intellij.spring.boot.run.starterManager");

  static @Nullable SpringBootStarterManager getStarterManager(@NotNull Module module) {
    for (SpringBootStarterManager manager : EP_NAME.getExtensionList()) {
      if (manager.supports(module)) {
        return manager;
      }
    }
    return null;
  }

  boolean supports(@NotNull Module module);

  default void addDependency(@NotNull Module module, @NotNull UnifiedDependency dependency) {
    addDependencies(module, new SmartList<>(dependency));
  }

  void addDependencies(@NotNull Module module, @NotNull Collection<UnifiedDependency> dependencies);

  void addManagedDependencies(@NotNull Module module, @NotNull Collection<ManagedDependency> dependencies);

  void removeManagedDependencies(@NotNull Module module, @NotNull Collection<ManagedDependency> dependencies);

  boolean isBuildFile(@NotNull Module module, @NotNull PsiFile psiFile);

  @NotNull Module adjustModule(@NotNull Module module);

  @NotNull Promise<?> refresh(@NotNull Module module);

  record ManagedDependency(@NotNull UnifiedDependency dependency, @Nullable String versionProperty) {
    public @NotNull String getPropertyName() {
      if (versionProperty != null) return versionProperty;

      String artifactId = Objects.requireNonNull(dependency.getCoordinates().getArtifactId());
      return StringUtil.substringBeforeLast(artifactId, "-") + ".version";
    }
  }
}
