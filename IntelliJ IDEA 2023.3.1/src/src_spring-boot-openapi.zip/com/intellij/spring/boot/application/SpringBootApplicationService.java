// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.application;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.module.Module;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface SpringBootApplicationService {
  static SpringBootApplicationService getInstance() {
    return ApplicationManager.getApplication().getService(SpringBootApplicationService.class);
  }

  /**
   * @return {@code true} if class annotated with {@code @EnableAutoConfiguration} and can have main method, otherwise {@code false}.
   */
  boolean isSpringApplication(PsiClass psiClass);

  /**
   * @param module module to search classes
   * @return the list of all classes in production scope of the given module
   * for which {@link #isSpringApplication(PsiClass)} returns {@code true}.
   */
  List<PsiClass> getSpringApplications(Module module);

  /**
   * @param springBootClass Spring Boot application class
   * @return {@code true} if candidate class is found by {@link #findMainClassCandidate(PsiClass)} for the given Spring Boot application,
   * and it contains {@code public static void main} method, otherwise {@code false}.
   */
  boolean hasMainMethod(PsiClass springBootClass);

  /**
   * @param springBootClass Spring Boot application class
   * @return class itself or candidate class which may contain main method to start the given Spring Boot application
   */
  @Nullable
  PsiClass findMainClassCandidate(@Nullable PsiClass springBootClass);

  /**
   * @param psiClass a class to check.
   * @return {@code true} if the class has main method and it is a Spring Application or invokes {@code SpringApplication#run},
   * otherwise {@code false}.
   */
  boolean isSpringBootApplicationRun(@NotNull PsiClass psiClass);

  /**
   * @param psiMethod a method to check.
   * @return {@code true} if the method invokes {@code SpringApplication#run} or {@code SpringApplication.Augmented#run},
   * otherwise {@code false}.
   */
  boolean hasSpringBootApplicationRun(@NotNull PsiMethod psiMethod);
}
