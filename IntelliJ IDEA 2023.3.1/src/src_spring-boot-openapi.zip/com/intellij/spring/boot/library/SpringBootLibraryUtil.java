// Copyright 2000-2020 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.library;

import com.intellij.compiler.CompilerConfiguration;
import com.intellij.java.library.JavaLibraryUtil;
import com.intellij.openapi.module.Module;
import com.intellij.openapi.module.ModuleUtilCore;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.ProjectRootManager;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.patterns.PatternCondition;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiElement;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.spring.boot.SpringBootClassesConstants;
import com.intellij.spring.model.utils.SpringCommonUtils;
import com.intellij.util.ArrayUtil;
import com.intellij.util.ProcessingContext;
import com.intellij.util.containers.ContainerUtil;
import com.intellij.util.text.VersionComparatorUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.jps.model.java.compiler.AnnotationProcessingConfiguration;

import java.io.File;
import java.util.Set;

import static com.intellij.psi.util.CachedValueProvider.Result;

public final class SpringBootLibraryUtil {

  public static final PatternCondition<PsiElement> SB_1_3_OR_HIGHER =
    createVersionPatternCondition(SpringBootVersion.VERSION_1_3_0);

  public static final PatternCondition<PsiElement> SB_1_5_OR_HIGHER =
    createVersionPatternCondition(SpringBootVersion.VERSION_1_5_0);

  private static final String CONFIGURATION_PROCESSOR_ARTIFACT_NAME = "spring-boot-configuration-processor";

  private static final String SPRING_BOOT_MAVEN = "org.springframework.boot:spring-boot";
  private static final String SPRING_BOOT_DEV_TOOLS_MAVEN = "org.springframework.boot:spring-boot-devtools";
  private static final String SPRING_BOOT_ACTUATOR_MAVEN = "org.springframework.boot:spring-boot-actuator";
  private static final String SPRING_WEB_MVC_MAVEN = "org.springframework:spring-webmvc";
  private static final String SPRING_WEB_FLUX_MAVEN = "org.springframework:spring-webflux";

  /**
   * Creates condition with minimum required SB version.
   *
   * @param minimumVersion Minimum required SB version.
   * @return PatternCondition.
   */
  public static PatternCondition<PsiElement> createVersionPatternCondition(@NotNull SpringBootVersion minimumVersion) {
    return new PatternCondition<>("SB" + minimumVersion.name() + "OrHigher") {
      @Override
      public boolean accepts(@NotNull PsiElement element, ProcessingContext context) {
        final Module module = ModuleUtilCore.findModuleForPsiElement(element);
        return isAtLeastVersion(module, minimumVersion);
      }
    };
  }

  // must be listed in ascending order
  public enum SpringBootVersion {
    ANY("1.0.0"), // detectionClassFqn: SpringBootClassesConstants.SPRING_APPLICATION
    VERSION_1_2_0("1.2.0"), // detectionClassFqn: "org.springframework.boot.jta.XADataSourceWrapper"
    VERSION_1_3_0("1.3.0"), // detectionClassFqn: "org.springframework.boot.context.event.ApplicationReadyEvent"
    VERSION_1_4_0("1.4.0"), // detectionClassFqn: "org.springframework.boot.diagnostics.FailureAnalysis"
    VERSION_1_5_0("1.5.0"), // detectionClassFqn: "org.springframework.boot.autoconfigure.AbstractDatabaseInitializer"

    VERSION_2_0_0("2.0.0"), // detectionClassFqn: "org.springframework.boot.WebApplicationType"
    VERSION_2_1_0("2.1.0"), // detectionClassFqn: "org.springframework.boot.context.event.ApplicationContextInitializedEvent"
    VERSION_2_2_0("2.2.0"), // detectionClassFqn: "org.springframework.boot.context.properties.ConfigurationPropertiesScan"
    VERSION_2_4_0("2.4.0"), // detectionClassFqn: "org.springframework.boot.context.config.ConfigData"
    VERSION_2_5_0("2.5.0"), // detectionClassFqn: "org.springframework.boot.context.properties.source.ConfigurationPropertySourcesPropertyResolver"
    VERSION_2_7_0("2.7.0"), // detectionClassFqn: "org.springframework.boot.autoconfigure.AutoConfiguration"

    VERSION_3_0_0("3.0.0"); // detectionClassFqn: "org.springframework.boot.context.properties.ConstructorBound"

    private final String myVersion;
    SpringBootVersion(String version) {
      myVersion = version;
    }

    public boolean isAtLeast(SpringBootVersion reference) {
      if (reference == ANY) {
        return true;
      }
      return compareTo(reference) >= 0;
    }
  }

  public static boolean hasConfigurationMetadataAnnotationProcessor(@NotNull Module module) {
    AnnotationProcessingConfiguration configuration =
      CompilerConfiguration.getInstance(module.getProject()).getAnnotationProcessingConfiguration(module);
    if (!configuration.isEnabled()) {
      return false;
    }

    Set<String> processors = configuration.getProcessors();
    if (!processors.isEmpty() && !processors.contains(SpringBootClassesConstants.CONFIGURATION_METADATA_ANNOTATION_PROCESSOR)) {
      return false;
    }

    if (configuration.isObtainProcessorsFromClasspath()) {
      PsiClass processor = SpringCommonUtils.findLibraryClass(module,
                                                              SpringBootClassesConstants.CONFIGURATION_METADATA_ANNOTATION_PROCESSOR);
      return processor != null;
    }

    Iterable<String> segments = StringUtil.tokenize(configuration.getProcessorPath(), File.pathSeparator);
    for (String segment : segments) {
      if (segment.endsWith(".jar")) {
        int fileNameIndex = Integer.max(segment.lastIndexOf('/'), segment.lastIndexOf('\\'));
        if (fileNameIndex >= 0 && fileNameIndex < segment.length() - 1) {
          segment = segment.substring(fileNameIndex + 1);
        }
        if (segment.contains(CONFIGURATION_PROCESSOR_ARTIFACT_NAME)) {
          return true;
        }
      }
    }

    return false;
  }

  public static boolean hasSpringBootLibrary(@Nullable Project project) {
    return JavaLibraryUtil.hasLibraryJar(project, SPRING_BOOT_MAVEN);
  }

  public static boolean hasSpringBootLibrary(@Nullable Module module) {
    return JavaLibraryUtil.hasLibraryJar(module, SPRING_BOOT_MAVEN);
  }

  public static boolean isBelowVersion(@Nullable Module module, SpringBootVersion version) {
    return !isAtLeastVersion(module, version);
  }

  public static boolean isAtLeastVersion(@Nullable final Module module,
                                         final SpringBootVersion version) {
    if (module == null || module.isDisposed()) return false;

    if (!hasSpringBootLibrary(module.getProject())) return false;

    final SpringBootVersion cached = getSpringBootVersion(module);
    return cached != null && cached.isAtLeast(version);
  }

  @Nullable
  public static String getVersionFromJar(@NotNull Module module) {
    if (module.isDisposed() || module.getProject().isDefault()) return null;

    return CachedValuesManager.getManager(module.getProject()).getCachedValue(module, () -> {
      String libraryVersion = JavaLibraryUtil.getLibraryVersion(module, SPRING_BOOT_MAVEN);
      return Result.create(libraryVersion, ProjectRootManager.getInstance(module.getProject()));
    });
  }

  public static boolean hasDevtools(@Nullable final Module module) {
    return JavaLibraryUtil.hasLibraryJar(module, SPRING_BOOT_DEV_TOOLS_MAVEN);
  }

  public static boolean hasActuators(@Nullable final Module module) {
    return JavaLibraryUtil.hasLibraryJar(module, SPRING_BOOT_ACTUATOR_MAVEN);
  }

  public static boolean hasRequestMappings(@Nullable final Module module) {
    return JavaLibraryUtil.hasLibraryJar(module, SPRING_WEB_MVC_MAVEN)
           || JavaLibraryUtil.hasLibraryJar(module, SPRING_WEB_FLUX_MAVEN);
  }

  @Nullable
  public static SpringBootVersion getSpringBootVersion(@NotNull final Module module) {
    if (module.isDisposed() || module.getProject().isDefault()) return null;

    return CachedValuesManager.getManager(module.getProject()).getCachedValue(module, () -> {
      String libraryVersion = JavaLibraryUtil.getLibraryVersion(module, SPRING_BOOT_MAVEN);
      SpringBootVersion detected = libraryVersion == null ? null :
                                   ContainerUtil.find(ArrayUtil.reverseArray(SpringBootVersion.values()),
                                                      version -> VersionComparatorUtil.compare(version.myVersion, libraryVersion) <= 0);
      return Result.create(detected, ProjectRootManager.getInstance(module.getProject()));
    });
  }
}
