// Copyright 2000-2018 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.
package com.intellij.spring.boot.model

import com.intellij.microservices.jvm.config.MetaConfigKey.Deprecation
import com.intellij.openapi.module.Module
import com.intellij.openapi.util.Ref
import com.intellij.psi.PsiManager
import com.intellij.spring.boot.application.metadata.SpringBootApplicationMetaConfigKeyManager
import com.intellij.spring.model.SpringProfile
import com.intellij.util.Processor
import com.intellij.util.containers.ContainerUtil

/**
 * Search/process configuration files values.
 */
class SpringBootConfigValueSearcher(private val module: Module,
                                    private val includeTests: Boolean = false,
                                    private val configKey: String,
                                    private val requireMetadata: Boolean = true,
                                    private val checkRelaxedNames: Boolean = true,
                                    private val activeProfiles: Set<String>? = null,
                                    private val keyIndex: String? = null,
                                    private val keyProperty: String? = null) {

  fun findValueText(): String? {
    val valueText = Ref.create<String>()
    val findValueTextProcessor = Processor<ConfigurationValueResult> { result ->
      val text = result.valueText ?: return@Processor true

      valueText.set(text)
      false
    }
    process(findValueTextProcessor)
    return valueText.get()
  }

  fun process(processor: Processor<ConfigurationValueResult>): Boolean {
    val configKeyManager = SpringBootApplicationMetaConfigKeyManager.getInstance()
    val metaConfigKey = configKeyManager.findApplicationMetaConfigKey(module, configKey) ?: if (requireMetadata) {
      return true
    }
    else {
      configKeyManager.createFakeConfigKey(module, configKey)
    }
    // keys with ERROR level are not used by SB, skip them
    if (metaConfigKey.deprecation.level == Deprecation.DeprecationLevel.ERROR) {
      return true
    }

    val psiManager = PsiManager.getInstance(module.project)
    val activeProfiles = clearDefaultTestProfile(activeProfiles)
    val params = ConfigurationValueSearchParams(module, checkRelaxedNames, activeProfiles, metaConfigKey,
                                                keyIndex, keyProperty)
    for (configFile in SpringBootConfigurationFileService.getInstance().findConfigFilesWithPropertySources(module, includeTests)) {
      val contributor = SpringBootModelConfigFileContributor.getContributor(configFile) ?: continue
      val configPsiFile = psiManager.findFile(configFile) ?: continue
      val result = contributor.findConfigurationValues(configPsiFile, params)
      if (!ContainerUtil.process(result, processor)) return false
    }

    return true
  }

  companion object {
    @JvmStatic
    @JvmOverloads
    fun productionForAllProfiles(module: Module, configKey: String, requireMetadata: Boolean = true): SpringBootConfigValueSearcher {
      return SpringBootConfigValueSearcher(module = module, configKey = configKey, requireMetadata = requireMetadata,
                                           activeProfiles = ConfigurationValueSearchParams.PROCESS_ALL_VALUES)
    }

    @JvmStatic
    @JvmOverloads
    fun productionForProfiles(module: Module,
                              configKey: String,
                              activeProfiles: Set<String>?,
                              requireMetadata: Boolean = true): SpringBootConfigValueSearcher {
      return SpringBootConfigValueSearcher(module = module, configKey = configKey, requireMetadata = requireMetadata,
                                           activeProfiles = activeProfiles)
    }

    @JvmStatic
    fun productionForProfiles(module: Module,
                              configKey: String,
                              activeProfiles: Set<String>?,
                              keyIndex: String?,
                              keyProperty: String?): SpringBootConfigValueSearcher {
      return SpringBootConfigValueSearcher(module = module, configKey = configKey, activeProfiles = activeProfiles,
                                           keyIndex = keyIndex, keyProperty = keyProperty)
    }

    @JvmStatic
    fun clearDefaultTestProfile(activeProfiles: Set<String>?): Set<String>? {
      if (activeProfiles == null) return null

      if (activeProfiles.contains(SpringProfile.DEFAULT_TEST_PROFILE_NAME)) {
        val result = LinkedHashSet<String>(activeProfiles)
        result.remove(SpringProfile.DEFAULT_TEST_PROFILE_NAME)
        return result
      }
      return activeProfiles
    }
  }
}
