package com.intellij.spring.boot.model

import com.intellij.lang.properties.IProperty
import com.intellij.openapi.module.Module
import com.intellij.openapi.project.Project
import com.intellij.psi.PsiFile

interface SpringBootPropertiesFileUtil {
  fun getDocuments(psiFile: PsiFile, module: Module): List<SpringBootPropertiesDocument>

  companion object {
    @JvmStatic
    fun getInstance(project: Project): SpringBootPropertiesFileUtil {
      return project.getService(SpringBootPropertiesFileUtil::class.java)
    }
  }
}

data class SpringBootPropertiesDocument(
  val properties: List<IProperty>,
  val documentId: Int,
)