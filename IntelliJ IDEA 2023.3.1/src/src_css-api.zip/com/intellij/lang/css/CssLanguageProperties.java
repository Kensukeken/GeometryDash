package com.intellij.lang.css;

import com.intellij.css.util.CssConstants;
import org.jetbrains.annotations.NotNull;

public interface CssLanguageProperties {
  default @NotNull String getDeclarationsTerminator() {
    return CssConstants.SEMICOLON;
  }

  default @NotNull String getPropertyNameValueSeparator() {
    return CssConstants.COLON;
  }

  default boolean isIndentBased() {
    return false;
  }
}
