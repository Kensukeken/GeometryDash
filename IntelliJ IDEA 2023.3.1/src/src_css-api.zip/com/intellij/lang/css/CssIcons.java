package com.intellij.lang.css;

import com.intellij.ui.IconManager;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;

/**
 * NOTE THIS FILE IS AUTO-GENERATED
 * DO NOT EDIT IT BY HAND, run "Generate icon classes" configuration instead
 */
public final class CssIcons {
  private static @NotNull Icon load(@NotNull String path, int cacheKey, int flags) {
    return IconManager.getInstance().loadRasterizedIcon(path, CssIcons.class.getClassLoader(), cacheKey, flags);
  }
  /** 16x16 */ public static final @NotNull Icon Custom_property = load("icons/css/custom_property.svg", 1914126789, 0);
  /** 16x16 */ public static final @NotNull Icon Property = load("icons/css/property.svg", 1710846171, 0);
  /** 16x16 */ public static final @NotNull Icon PseudoClass = load("icons/css/pseudo-class.svg", 1419383589, 0);
  /** 16x16 */ public static final @NotNull Icon PseudoElement = load("icons/css/pseudo-element.svg", -31443768, 0);
  /** 13x13 */ public static final @NotNull Icon Toolwindow = load("icons/css/toolwindow.svg", 1378474529, 2);
}
