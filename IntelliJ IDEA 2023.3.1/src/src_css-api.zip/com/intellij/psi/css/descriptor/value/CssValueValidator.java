package com.intellij.psi.css.descriptor.value;

import com.intellij.psi.PsiElement;

public interface CssValueValidator {
  boolean isValid(PsiElement value, CssValueDescriptor valueDescriptor);
}
