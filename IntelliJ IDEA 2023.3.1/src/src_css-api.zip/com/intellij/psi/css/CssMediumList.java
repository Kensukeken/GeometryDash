package com.intellij.psi.css;

import com.intellij.psi.css.descriptor.CssMediaType;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public interface CssMediumList extends CssElement {

  CssMediaQuery @NotNull [] getMediaQueries();
  
  @NotNull
  Set<CssMediaType> getTypes();
}
