/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.psi.css.resolve;

import com.intellij.openapi.application.ApplicationManager;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiFile;
import com.intellij.psi.css.CssDeclaration;
import com.intellij.psi.css.CssStylesheet;
import com.intellij.psi.xml.XmlFile;
import com.intellij.psi.xml.XmlTag;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public abstract class CssResolveManager {
  public static CssResolveManager getInstance() {
    return ApplicationManager.getApplication().getService(CssResolveManager.class);
  }

  public abstract CssResolver getNewResolver();

  public CssDeclaration[] resolve(XmlTag tag) {
    final PsiFile psiFile = tag.getContainingFile();
    return psiFile instanceof XmlFile ? resolve(tag, new XmlFile[]{(XmlFile) psiFile}, null) : CssDeclaration.EMPTY_ARRAY;
  }

  public CssDeclaration[] resolve(XmlTag tag, XmlFile[] xhtmlFiles) {
    return resolve(tag, xhtmlFiles, null);
  }

  public abstract PsiFile @NotNull [] resolveFiles(@Nullable PsiElement uriElement);

  public abstract CssDeclaration[] resolve(XmlTag tag, XmlFile[] xhtmlFiles, CssStylesheet defaultStylesheet);
}
