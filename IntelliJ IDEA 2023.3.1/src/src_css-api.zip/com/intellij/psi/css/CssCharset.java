package com.intellij.psi.css;

import org.jetbrains.annotations.Nullable;

public interface CssCharset extends CssAtRule, CssOneLineStatement {
  @Nullable
  String getValue();

  @Nullable
  CssString getValueElement();
}
