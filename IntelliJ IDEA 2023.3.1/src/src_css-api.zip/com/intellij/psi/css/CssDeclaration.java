package com.intellij.psi.css;

import com.intellij.model.psi.PsiExternalReferenceHost;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.psi.NavigatablePsiElement;
import com.intellij.psi.PsiElement;
import com.intellij.util.ArrayFactory;
import com.intellij.util.IncorrectOperationException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface CssDeclaration extends CssOneLineStatement, CssDescriptorOwner, CssValueOwner, CssNamedElement, NavigatablePsiElement,
                                        PsiExternalReferenceHost {
  CssDeclaration[] EMPTY_ARRAY = new CssDeclaration[0];

  ArrayFactory<CssDeclaration> ARRAY_FACTORY = count -> count == 0 ? EMPTY_ARRAY : new CssDeclaration[count];

  /**
   * Returns property name of declaration element.
   * Use {@link com.intellij.psi.css.impl.util.table.CssDescriptorsUtil#getCanonicalPropertyName} in order
   * to get real property name.
   *
   * @return property name
   */
  @NotNull @NlsSafe String getPropertyName();

  @Override
  @Nullable
  CssTermList getValue();

  boolean isImportant();

  boolean isShorthandProperty();

  boolean isCustomProperty();

  /**
   * Returns property names which values are defined inside this shorthand property
   * Note: this method will not return property-names which values are not defined!
   *
   * @return empty array if no values defined or non-shorthand property
   */
  String[] expandShorthandProperty();

  String @Nullable [] getShorthandValue(@NotNull final String propertyName);

  PsiElement @Nullable [] getShorthandPsiValue(@NotNull final String propertyName);

  boolean isEqualTo(Object object);

  int equalityHashCode();

  void setValue(final String propertyValue) throws IncorrectOperationException;

  /**
   * @deprecated use {@link this#getDescriptors()}
   */
  @Deprecated
  @Nullable
  CssPropertyDescriptor getDescriptor();

  boolean isHack();

  @Nullable
  PsiElement getPropertyNameElement();

  @NotNull
  @Override
  Collection<? extends CssPropertyDescriptor> getDescriptors();

  @NotNull
  @Override
  Collection<? extends CssPropertyDescriptor> getDescriptors(@NotNull PsiElement context);
}
