package com.intellij.psi.css;

import com.intellij.psi.css.descriptor.CssElementDescriptor;
import com.intellij.psi.css.descriptor.CssMediaGroup;
import org.jetbrains.annotations.NotNull;

public interface CssMediaGroupAwareDescriptor extends CssElementDescriptor {
  CssMediaGroup @NotNull [] getMediaGroups();
}
