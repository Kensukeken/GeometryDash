/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.psi.css;

import com.intellij.model.psi.PsiExternalReferenceHost;
import com.intellij.psi.PsiElement;
import com.intellij.psi.css.resolve.CssResolver;
import com.intellij.psi.xml.XmlTag;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface CssSimpleSelector extends CssElement, PsiExternalReferenceHost {
  CssSimpleSelector[] EMPTY_ARRAY = new CssSimpleSelector[0];

  @NotNull
  String getElementName();

  @Nullable
  PsiElement getNameIdentifier();

  @Nullable
  String getNamespaceName();

  CssSelectorSuffix @NotNull [] getSelectorSuffixes();

  boolean isUniversalSelector();

  boolean isMatch(@NotNull XmlTag tag, @NotNull CssResolver resolver);

  boolean isTagNameMatch(String tagName);

  String getPresentableText();
}
