package com.intellij.psi.css;

import com.intellij.psi.PsiNameIdentifierOwner;

public interface CssCustomPropertyAtRule extends CssAtRule, PsiNameIdentifierOwner, CssNamedElement {
}
