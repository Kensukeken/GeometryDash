package com.intellij.javaee.utils.persistence.data;

import com.intellij.psi.PsiElement;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.uast.UPolyadicExpression;
import org.jetbrains.uast.UastFacade;
import org.jetbrains.uast.expressions.UInjectionHost;
import org.jetbrains.uast.util.ClassSet;

import java.util.List;

public final class QLInjectorContext {
  private static final ClassSet<PsiElement> ourPsiSourceTypes =
    UastFacade.INSTANCE.getPossiblePsiSourceTypes(UInjectionHost.class, UPolyadicExpression.class);

  private static final List<? extends Class<? extends PsiElement>> ourElementsToInjectIn = ourPsiSourceTypes.toList();

  public static boolean isInjectionTarget(@NotNull PsiElement context) {
    return ourPsiSourceTypes.contains(context.getClass());
  }

  public static List<? extends Class<? extends PsiElement>> elementsToInjectIn() {
    return ourElementsToInjectIn;
  }

  private QLInjectorContext() {
  }
}
