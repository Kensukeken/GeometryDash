package com.intellij.javaee.utils.persistence.data.parser;

import com.intellij.javaee.utils.persistence.data.parser.domain.OrderBySource;
import org.jetbrains.annotations.NotNull;

import java.util.regex.Pattern;

public interface PartTreeParserContext {

  PartTypes types();

  String keywordTemplate();

  String queryPattern();

  String countPattern();

  String existsPattern();

  String deleteUpdatePattern();

  Pattern[] prefixTemplates();

  default String ignoreCase() {return "";}

  default String[] splitOrderBy(@NotNull String orderClause) {return OrderBySource.splitOrderClause(orderClause); }
}
