/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.constants;

import org.jetbrains.annotations.NonNls;

public interface JavaeeFileTemplateNames {
  @NonNls String EJB_JAR_XML_1_1 = "ejb-jar.1_1.xml";
  @NonNls String EJB_JAR_XML_2_0 = "ejb-jar.2_0.xml";
  @NonNls String EJB_JAR_XML_2_1 = "ejb-jar.2_1.xml";
  @NonNls String EJB_JAR_XML_3_0 = "ejb-jar.3_0.xml";
  @NonNls String EJB_JAR_XML_3_1 = "ejb-jar.3_1.xml";
  @NonNls String EJB_JAR_XML_3_2 = "ejb-jar.3_2.xml";
  @NonNls String EJB_JAR_XML_4_0 = "ejb-jar.4_0.xml";

  @NonNls String APPLICATION_XML_1_2 = "application.1_2.xml";
  @NonNls String APPLICATION_XML_1_3 = "application.1_3.xml";
  @NonNls String APPLICATION_XML_1_4 = "application.1_4.xml";
  @NonNls String APPLICATION_XML_5_0 = "application.5.xml";
  @NonNls String APPLICATION_XML_6_0 = "application.6.xml";
  @NonNls String APPLICATION_XML_7_0 = "application.7.xml";
  @NonNls String APPLICATION_XML_8_0 = "application.8.xml";
  @NonNls String APPLICATION_XML_9_0 = "application.9.xml";
  @NonNls String APPLICATION_XML_10_0 = "application.10.xml";

  @NonNls String WEB_XML_22 = "web.2_2.xml";
  @NonNls String WEB_XML_23 = "web.2_3.xml";
  @NonNls String WEB_XML_24 = "web.2_4.xml";
  @NonNls String WEB_XML_25 = "web.2_5.xml";
  @NonNls String WEB_XML_30 = "web.3_0.xml";
  @NonNls String WEB_XML_31 = "web.3_1.xml";
  @NonNls String WEB_XML_40 = "web.4_0.xml";
  @NonNls String WEB_XML_50 = "web.5_0.xml";
  @NonNls String WEB_XML_60 = "web.6_0.xml";

  @NonNls String ENTITY_HOME_INTERFACE_TEMPLATE = "Entity Home Interface.java";
  @NonNls String ENTITY_LOCAL_HOME_INTERFACE_TEMPLATE = "Entity Local Home Interface.java";
  @NonNls String SESSION_HOME_INTERFACE_TEMPLATE = "Session Home Interface.java";
  @NonNls String SESSION_LOCAL_HOME_INTERFACE_TEMPLATE = "Session Local Home Interface.java";
  @NonNls String SESSION_SERVICE_ENDPOINT_INTERFACE = "Session Service Endpoint Interface.java";
  @NonNls String REMOTE_INTERFACE_TEMPLATE = "EJB Remote Interface.java";
  @NonNls String LOCAL_INTERFACE_TEMPLATE = "EJB Local Interface.java";

  @NonNls String ENTITY_CLASS_CMP_1x_TEMPLATE = "Entity Bean Class CMP 1x.java";
  @NonNls String ENTITY_CLASS_CMP_2x_TEMPLATE = "Entity Bean Class CMP 2x.java";
  @NonNls String ENTITY_CLASS_BMP_TEMPLATE = "Entity Bean Class BMP.java";
  @NonNls String PERSISTENT_ENTITY_CLASS_TEMPLATE_3 = "Persistent Entity Class 3.java";
  @NonNls String PERSISTENT_EMBEDDABLE_CLASS_TEMPLATE_3 = "Persistent Embeddable Class 3.java";
  @NonNls String SESSION_CLASS_STATEFUL_TEMPLATE = "Session Bean Class Stateful.java";
  @NonNls String SESSION_CLASS_STATEFUL_TEMPLATE_3 = "Session Bean Class Stateful 3.java";
  @NonNls String SESSION_CLASS_STATELESS_TEMPLATE = "Session Bean Class Stateless.java";
  @NonNls String SESSION_CLASS_STATELESS_TEMPLATE_3 = "Session Bean Class Stateless 3.java";
  @NonNls String SESSION_CLASS_SINGLETON_TEMPLATE = "Session Bean Class Singleton.java";
  @NonNls String MESSAGE_CLASS_TEMPLATE = "Message Driven Bean Class.java";
  @NonNls String MESSAGE_CLASS_TEMPLATE_3 = "Message Driven Bean Class 3.java";
  @NonNls String INTERCEPTOR_TEMPLATE_3 = "EnterpriseBean Interceptor 3.java";

  @NonNls String SERVLET_CLASS_TEMPLATE = "Servlet Class.java";
  @NonNls String SERVLET_ANNOTATED_CLASS_TEMPLATE = "Servlet Annotated Class.java";
  @NonNls String FILTER_CLASS_TEMPLATE = "Filter Class.java";
  String FILTER_ANNOTATED_CLASS_TEMPLATE = "Filter Annotated Class.java";
  @NonNls String LISTENER_CLASS_TEMPLATE = "Listener Class.java";
  String LISTENER_ANNOTATED_CLASS_TEMPLATE = "Listener Annotated Class.java";

  @NonNls String JSP_FILE = "Jsp File.jsp";
  @NonNls String JSPX_FILE = "Jspx File.jspx";
  @NonNls String TLD_FILE = "Tag Library Descriptor.tld";

  @NonNls String PERSISTENCE_XML_1_0 = "persistence.xml";
  @NonNls String PERSISTENCE_XML_2_0 = "persistence_2_0.xml";

  @NonNls String PERSISTENCE_XML_3_0 = "persistence_3_0.xml";

  @NonNls String ORM_XML_1_0 = "orm_1_0.xml";
  @NonNls String ORM_XML_2_0 = "orm_2_0.xml";

  @NonNls String ORM_XML_3_0 = "orm_3_0.xml";

  @NonNls String KOTLIN_ENTITY_CLASS = "Kotlin Entity.kt";
  @NonNls String KOTLIN_EQUALS_METHOD = "Kotlin Equals Method.kt";
  @NonNls String KOTLIN_HASHCODE_METHOD = "Kotlin HashCode Method.kt";
  @NonNls String KOTLIN_TO_STRING_METHOD = "Kotlin ToString Method.kt";
  @NonNls String KOTLIN_PROPERTY = "Kotlin Property.kt";
  @NonNls String KOTLIN_RELATION_OWNER_PROPERTY = "Kotlin Relation Owner Property.kt";
  @NonNls String KOTLIN_RELATION_DEPENDENT_PROPERTY = "Kotlin Relation Dependent Property.kt";
  @NonNls String JPA_JOIN_COLUMN_ANNOTATION = "Jpa JoinColumn Annotation.kt";
}
