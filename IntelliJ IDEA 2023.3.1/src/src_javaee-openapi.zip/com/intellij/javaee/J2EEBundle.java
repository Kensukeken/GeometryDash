/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee;

import com.intellij.DynamicBundle;
import com.intellij.openapi.util.NlsSafe;
import org.jetbrains.annotations.Nls;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.PropertyKey;

import java.util.function.Supplier;

public final class J2EEBundle extends DynamicBundle {
  public static final @NlsSafe String JAKARTA_EE = "Jakarta EE";
  public static final @NlsSafe String JAVA_ENTERPRISE = "Java Enterprise";
  public static final @NlsSafe String JAKARTA_EE_9 = "Jakarta EE 9";
  public static final @NlsSafe String JAKARTA_EE_10 = "Jakarta EE 10";
  public static final @NlsSafe String JAVA_EE_8 = "Java EE 8";

  @NonNls private static final String BUNDLE = "messages.J2EEBundle";
  private static final J2EEBundle INSTANCE = new J2EEBundle();

  private J2EEBundle() { super(BUNDLE); }

  @NotNull
  public static @Nls String message(@NotNull @PropertyKey(resourceBundle = BUNDLE) String key, Object @NotNull ... params) {
    return INSTANCE.getMessage(key, params);
  }

  @NotNull
  public static Supplier<@Nls String> messagePointer(@NotNull @PropertyKey(resourceBundle = BUNDLE) String key, Object @NotNull ... params) {
    return INSTANCE.getLazyMessage(key, params);
  }
}
