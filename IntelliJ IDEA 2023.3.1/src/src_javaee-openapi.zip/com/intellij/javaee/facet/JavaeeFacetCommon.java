/*
 * Copyright (c) 2000-2007 JetBrains s.r.o. All Rights Reserved.
 */

package com.intellij.javaee.facet;

public interface JavaeeFacetCommon {

  JavaeeFacetCommonPart getCommonPart();

  void onFacetChanged();
}
