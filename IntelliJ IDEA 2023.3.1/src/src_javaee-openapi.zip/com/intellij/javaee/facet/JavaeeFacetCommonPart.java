package com.intellij.javaee.facet;

import com.intellij.openapi.util.ModificationTracker;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.packaging.elements.PackagingElement;
import com.intellij.util.descriptors.ConfigFileContainer;

import java.util.Collection;
import java.util.List;

public interface JavaeeFacetCommonPart {
  ConfigFileContainer getDescriptorsContainer();

  void fireFacetChanged();

  Collection<VirtualFile> getDescriptors();

  ModificationTracker getModificationTracker();

  boolean isAllDescriptorsValid();

  List<? extends PackagingElement<?>> getFacetResourcesPackagingElements();
}
