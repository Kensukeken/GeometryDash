package com.intellij.javaee.facet;

import org.jetbrains.annotations.NonNls;

public final class JavaeeFacetExternalizationConstants {
  @NonNls public static final String WEB_FACET_TYPE_ID = "web";
  @NonNls public static final String EJB_FACET_TYPE_ID = "ejb";
  @NonNls public static final String JAVAEE_APPLICATION_FACET_TYPE_ID = "javaeeApplication";
  @NonNls public static final String PACKAGING_SETTINGS_ELEMENT = "packaging";
  @NonNls public static final String VALIDATORS_ELEMENT = "validators";
  @NonNls public static final String BUILDING_SETTINGS_ELEMENT = "building";

  @NonNls public static final String EXPLODED_URL_ATTRIBUTE = "EXPLODED_URL";
  @NonNls public static final String EXPLODED_ENABLED_ATTRIBUTE = "EXPLODED_ENABLED";
  @NonNls public static final String EXCLUDE_EXPLODED_ATTRIBUTE = "EXCLUDE_EXPLODED_DIRECTORY";
  @NonNls public static final String JAR_URL_ATTRIBUTE = "JAR_URL";
  @NonNls public static final String JAR_ENABLED_ATTRIBUTE = "JAR_ENABLED";
  @NonNls public static final String EJB_SOURCE_ROOTS_ELEMENT = "ejbRoots";
  @NonNls public static final String WEB_SOURCE_ROOTS_ELEMENT = "sourceRoots";
  @NonNls public static final String SOURCE_ROOT_ELEMENT = "root";
  @NonNls public static final String ROOT_URL_ATTRIBUTE = "url";

  @NonNls public static final String WAR_ARTIFACT_TYPE = "war";
  @NonNls public static final String EXPLODED_WAR_ARTIFACT_TYPE = "exploded-war";
  @NonNls public static final String EJB_JAR_ARTIFACT_TYPE = "ejb-jar";
  @NonNls public static final String EXPLODED_EJB_ARTIFACT_TYPE = "exploded-ejb";
  @NonNls public static final String EAR_ARTIFACT_TYPE = "ear";
  @NonNls public static final String EXPLODED_EAR_ARTIFACT_TYPE = "exploded-ear";

  @NonNls public static final String WEB_ROOTS_ELEMENT = "webroots";
  @NonNls public static final String WEB_ROOT_ELEMENT = "root";
  @NonNls public static final String WEB_ROOT_URL_ATTRIBUTE = "url";
  @NonNls public static final String WEB_ROOT_RELATIVE_PATH_ATTRIBUTE = "relative";
  @NonNls public static final String DESCRIPTORS_ELEMENT = "descriptors";
}
