package com.intellij.javaee.facet;

import com.intellij.util.descriptors.ConfigFileMetaData;
import org.jetbrains.annotations.NonNls;

/**
 * Java EE facet importers can run in two modes: as legacy importers and as workspace importers.
 * To do so, they extend [org.jetbrains.idea.maven.importing.FacetImporter] (legacy import)
 * and implement [org.jetbrains.idea.maven.importing.MavenWorkspaceConfigurator] (workspace import).
 * Legacy import context provides [com.intellij.facet.Facet] instances, but workspace import does not.
 * Workspace importers have to manipulate with storage entities directly.
 * To be able to use the same importing logic in both modes, it is handy to have facet-like abstractions.
 * This interface and its ancestors provide an abstraction layer to be used in both legacy and workspace import.
 */
public interface JavaeeFacetEx {
  void replaceConfigFile(ConfigFileMetaData metaData, @NonNls String newUrl);
  void setSourceRoots(String[] urls);
}
