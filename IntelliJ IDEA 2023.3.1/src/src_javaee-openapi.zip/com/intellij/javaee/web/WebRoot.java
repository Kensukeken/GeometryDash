/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.web;

import com.intellij.openapi.Disposable;
import com.intellij.openapi.application.ReadAction;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.openapi.util.io.FileUtil;
import com.intellij.openapi.util.text.StringUtil;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.vfs.pointers.VirtualFilePointer;
import com.intellij.openapi.vfs.pointers.VirtualFilePointerManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public class WebRoot implements Disposable {
  private final String myRelativePath;
  private final VirtualFilePointer myVirtualFilePointer;

  public WebRoot(@NotNull String url, String relativePath) {
    myRelativePath = normalize(relativePath);
    myVirtualFilePointer = VirtualFilePointerManager.getInstance().create(url, this, null);
  }

  public String getRelativePath() {
    return myRelativePath;
  }

  public String getDirectoryUrl() {
    return myVirtualFilePointer.getUrl();
  }

  public @NlsSafe String getPresentableUrl() {
    return myVirtualFilePointer.getPresentableUrl();
  }

  @Override
  public void dispose() { }

  @Nullable
  public VirtualFile getFile() {
    return ReadAction.compute(myVirtualFilePointer::getFile);
  }

  public String getURI() {
    return myRelativePath;
  }

  @NotNull
  private static String normalize(String relativePath) {
    relativePath = FileUtil.toCanonicalPath(relativePath);
    if (relativePath == null) relativePath = "";
    while (StringUtil.endsWithChar(relativePath, '/')) {
      relativePath = relativePath.substring(0, relativePath.length() - 1);
    }

    if (!StringUtil.startsWithChar(relativePath, '/')) {
      relativePath = "/" + relativePath;
    }
    return relativePath;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (!(o instanceof WebRoot webRoot)) return false;

    if (!Comparing.equal(getFile(), webRoot.getFile())) return false;
    if (!Objects.equals(myRelativePath, webRoot.myRelativePath)) return false;
    return true;
  }

  @Override
  public int hashCode() {
    Object myFile = getFile();
    int result = myFile != null ? myFile.hashCode() : 0;
    result = 29 * result + (myRelativePath != null ? myRelativePath.hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "WebRoot: ('" + (myVirtualFilePointer == null ? "" : myVirtualFilePointer.getPresentableUrl()) + "' -> '" + myRelativePath + "')";
  }
}
