package com.intellij.javaee.web.facet;

import com.intellij.javaee.facet.JavaeeFacetEx;
import com.intellij.javaee.web.WebRoot;

import java.util.List;

public interface WebFacetEx extends JavaeeFacetEx {
  WebRoot addWebRootNoFire(String url, String path);
  List<WebRoot> getWebRoots();
  void removeAllWebRoots();
}
