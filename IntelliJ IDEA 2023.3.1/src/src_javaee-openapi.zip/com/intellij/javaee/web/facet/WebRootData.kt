package com.intellij.javaee.web.facet

import com.intellij.javaee.facet.JavaeeFacetExternalizationConstants
import com.intellij.openapi.util.InvalidDataException
import com.intellij.openapi.vfs.VirtualFile
import com.intellij.openapi.vfs.VirtualFileManager
import org.jdom.Element

data class WebRootData(val url: String, val relativePath: String) {
  fun findFile(): VirtualFile? {
    return VirtualFileManager.getInstance().findFileByUrl(url)
  }

  companion object {
    @JvmStatic
    fun create(element: Element): WebRootData {
      var url = element.getAttributeValue(JavaeeFacetExternalizationConstants.WEB_ROOT_URL_ATTRIBUTE)
      url = url ?: ""
      val relativePath = element.getAttributeValue(JavaeeFacetExternalizationConstants.WEB_ROOT_RELATIVE_PATH_ATTRIBUTE)
                         ?: throw InvalidDataException("No relative attribute in Web Root element $element")
      return WebRootData(url, relativePath)
    }
  }
}