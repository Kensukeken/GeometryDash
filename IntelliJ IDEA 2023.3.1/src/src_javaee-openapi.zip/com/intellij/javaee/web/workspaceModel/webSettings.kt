package com.intellij.javaee.web.workspaceModel

import com.intellij.javaee.web.facet.WebRootData
import com.intellij.openapi.util.NlsSafe
import com.intellij.platform.workspace.storage.EntitySource
import com.intellij.platform.workspace.storage.GeneratedCodeApiVersion
import com.intellij.platform.workspace.storage.MutableEntityStorage
import com.intellij.platform.workspace.storage.WorkspaceEntity
import com.intellij.util.descriptors.ConfigFileItem
import com.intellij.platform.workspace.storage.*
import com.intellij.platform.workspace.jps.entities.ModuleEntity
import com.intellij.platform.workspace.jps.entities.ModuleId
import com.intellij.platform.workspace.jps.entities.ModuleSettingsBase
import com.intellij.platform.workspace.storage.impl.containers.toMutableWorkspaceList
import com.intellij.platform.workspace.storage.EntityType
import com.intellij.platform.workspace.storage.annotations.Child

interface WebSettingsEntity: ModuleSettingsBase {
  val sourceRoots: List<String>
  val webRoots: List<WebRootData>

  val configFileItems: List<ConfigFileItem>
  val module: ModuleEntity
  override val symbolicId: WebSettingsId
    get() = WebSettingsId(name, moduleId)

  //region generated code
  @GeneratedCodeApiVersion(2)
  interface Builder : WebSettingsEntity, ModuleSettingsBase.Builder<WebSettingsEntity>, WorkspaceEntity.Builder<WebSettingsEntity> {
    override var entitySource: EntitySource
    override var name: String
    override var moduleId: ModuleId
    override var sourceRoots: MutableList<String>
    override var webRoots: MutableList<WebRootData>
    override var configFileItems: MutableList<ConfigFileItem>
    override var module: ModuleEntity
  }

  companion object : EntityType<WebSettingsEntity, Builder>(ModuleSettingsBase) {
    @JvmOverloads
    @JvmStatic
    @JvmName("create")
    operator fun invoke(name: String,
                        moduleId: ModuleId,
                        sourceRoots: List<String>,
                        webRoots: List<WebRootData>,
                        configFileItems: List<ConfigFileItem>,
                        entitySource: EntitySource,
                        init: (Builder.() -> Unit)? = null): WebSettingsEntity {
      val builder = builder()
      builder.name = name
      builder.moduleId = moduleId
      builder.sourceRoots = sourceRoots.toMutableWorkspaceList()
      builder.webRoots = webRoots.toMutableWorkspaceList()
      builder.configFileItems = configFileItems.toMutableWorkspaceList()
      builder.entitySource = entitySource
      init?.invoke(builder)
      return builder
    }
  }
  //endregion
}

//region generated code
fun MutableEntityStorage.modifyEntity(entity: WebSettingsEntity,
                                      modification: WebSettingsEntity.Builder.() -> Unit): WebSettingsEntity = modifyEntity(
  WebSettingsEntity.Builder::class.java, entity, modification)

var ModuleEntity.Builder.webSettings: @Child List<WebSettingsEntity>
  by WorkspaceEntity.extension()
//endregion

val ModuleEntity.webSettings: List<@Child WebSettingsEntity>
  by WorkspaceEntity.extension()

data class WebSettingsId(val name: @NlsSafe String, val parentId: ModuleId) : SymbolicEntityId<WebSettingsEntity> {
  override val presentableName: String
    get() = name
}