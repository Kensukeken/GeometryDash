/*
 * Copyright 2000-2014 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.javaee.web.artifact;

import com.intellij.javaee.web.facet.WebFacet;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.roots.libraries.Library;
import com.intellij.packaging.artifacts.Artifact;
import com.intellij.packaging.artifacts.ArtifactType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public abstract class WebArtifactUtil {
  public static WebArtifactUtil getInstance() {
    return ApplicationManager.getApplication().getService(WebArtifactUtil.class);
  }

  public abstract boolean isWebApplication(@NotNull ArtifactType artifactType);

  @Nullable
  public abstract String getModuleWebUri(@NotNull Artifact earArtifact, @NotNull WebFacet webFacet);

  public abstract ArtifactType getExplodedWarArtifactType();

  public abstract ArtifactType getWarArtifactType();

  public abstract Collection<? extends Artifact> getWebArtifacts(@NotNull Project project);

  public abstract void addLibrary(@NotNull Library library, @NotNull Artifact artifact, @NotNull Project project);

  public abstract Collection<? extends ArtifactType> getWebArtifactTypes();
}
