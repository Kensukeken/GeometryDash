/*
 * Copyright 2000-2007 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.intellij.javaee.web.debugger.engine;

import com.intellij.debugger.engine.DebugProcess;
import com.intellij.javaee.facet.JavaeeFacet;
import com.intellij.openapi.application.ApplicationManager;
import org.jetbrains.annotations.NonNls;

public abstract class PositionManagersFactory {

  public static PositionManagersFactory getInstance() {
    return ApplicationManager.getApplication().getService(PositionManagersFactory.class);
  }

  public abstract DefaultJSPPositionManager createJSR45PositionManager(DebugProcess process, JavaeeFacet[] facets, @NonNls String jspPackage);

  public abstract DefaultJSPPositionManager createWebSphereSpecificPositionManager(DebugProcess process, JavaeeFacet[] facets, @NonNls String jspPackage);

}
