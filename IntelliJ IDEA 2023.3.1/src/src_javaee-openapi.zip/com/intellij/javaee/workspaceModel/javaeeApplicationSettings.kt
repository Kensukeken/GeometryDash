package com.intellij.javaee.workspaceModel

import com.intellij.openapi.util.NlsSafe
import com.intellij.platform.workspace.storage.EntitySource
import com.intellij.platform.workspace.storage.GeneratedCodeApiVersion
import com.intellij.platform.workspace.storage.MutableEntityStorage
import com.intellij.platform.workspace.storage.WorkspaceEntity
import com.intellij.util.descriptors.ConfigFileItem
import com.intellij.platform.workspace.storage.*
import com.intellij.platform.workspace.jps.entities.ModuleEntity
import com.intellij.platform.workspace.jps.entities.ModuleId
import com.intellij.platform.workspace.jps.entities.ModuleSettingsBase
import com.intellij.platform.workspace.storage.impl.containers.toMutableWorkspaceList
import com.intellij.platform.workspace.storage.EntityType
import com.intellij.platform.workspace.storage.annotations.Child

interface JavaeeApplicationSettingsEntity: ModuleSettingsBase {
  val configFileItems: List<ConfigFileItem>
  val module: ModuleEntity
  override val symbolicId: JavaeeApplicationSettingsId
    get() = JavaeeApplicationSettingsId(name, moduleId)

  //region generated code
  @GeneratedCodeApiVersion(2)
  interface Builder : JavaeeApplicationSettingsEntity, ModuleSettingsBase.Builder<JavaeeApplicationSettingsEntity>, WorkspaceEntity.Builder<JavaeeApplicationSettingsEntity> {
    override var entitySource: EntitySource
    override var name: String
    override var moduleId: ModuleId
    override var configFileItems: MutableList<ConfigFileItem>
    override var module: ModuleEntity
  }

  companion object : EntityType<JavaeeApplicationSettingsEntity, Builder>(ModuleSettingsBase) {
    @JvmOverloads
    @JvmStatic
    @JvmName("create")
    operator fun invoke(name: String,
                        moduleId: ModuleId,
                        configFileItems: List<ConfigFileItem>,
                        entitySource: EntitySource,
                        init: (Builder.() -> Unit)? = null): JavaeeApplicationSettingsEntity {
      val builder = builder()
      builder.name = name
      builder.moduleId = moduleId
      builder.configFileItems = configFileItems.toMutableWorkspaceList()
      builder.entitySource = entitySource
      init?.invoke(builder)
      return builder
    }
  }
  //endregion
}

//region generated code
fun MutableEntityStorage.modifyEntity(entity: JavaeeApplicationSettingsEntity,
                                      modification: JavaeeApplicationSettingsEntity.Builder.() -> Unit): JavaeeApplicationSettingsEntity = modifyEntity(
  JavaeeApplicationSettingsEntity.Builder::class.java, entity, modification)

var ModuleEntity.Builder.javaeeApplicationSettings: @Child List<JavaeeApplicationSettingsEntity>
  by WorkspaceEntity.extension()
//endregion

val ModuleEntity.javaeeApplicationSettings: List<@Child JavaeeApplicationSettingsEntity>
  by WorkspaceEntity.extension()

data class JavaeeApplicationSettingsId(val name: @NlsSafe String, val parentId: ModuleId) : SymbolicEntityId<JavaeeApplicationSettingsEntity> {
  override val presentableName: String
    get() = name
}