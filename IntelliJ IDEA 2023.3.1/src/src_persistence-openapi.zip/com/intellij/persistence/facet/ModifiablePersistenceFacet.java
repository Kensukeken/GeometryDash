package com.intellij.persistence.facet;

import com.intellij.persistence.model.PersistencePackage;
import com.intellij.util.descriptors.ConfigFileContainer;
import org.jetbrains.annotations.NotNull;

public interface ModifiablePersistenceFacet extends PersistenceFacet {
  ConfigFileContainer getDescriptorsContainer();

  void setDataSourceId(@NotNull PersistencePackage unit, String dataSourceId);

  void setNamingStrategy(@NotNull PersistencePackage unit, String namingStrategy);
}
