/*
 * Copyright (c) 2000-2006 JetBrains s.r.o. All Rights Reserved.
 */

package com.intellij.persistence.model;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.NlsSafe;
import com.intellij.persistence.facet.PersistenceFacet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface PersistencePackagePointer {
  @NotNull String getPath();
  @NotNull String getPresentableUrl();

  @NotNull Project getProject();

  @NlsSafe String getElementName();
  @NlsSafe String getModuleName();

  @Nullable
  PersistencePackage findElement();

  @Nullable
  PersistenceFacet getPersistenceFacet();
}
