package com.intellij.persistence.extensions;

import com.intellij.openapi.extensions.ExtensionPointName;
import com.intellij.openapi.module.Module;
import com.intellij.persistence.facet.PersistenceFacet;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public interface PersistenceFacetProvider {
  ExtensionPointName<PersistenceFacetProvider> EP_NAME = ExtensionPointName.create("com.intellij.persistence.facetProvider");

  @Nullable PersistenceFacet getFacet(@NotNull Module module);
}
